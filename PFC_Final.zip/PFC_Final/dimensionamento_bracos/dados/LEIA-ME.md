# Dados da proxima etapa

Nenhum motor comercial foi cadastrado ainda. Dados sinteticos dos testes ficam
restritos aos testes e nao sao apresentados como modelos disponiveis para compra.

## Requisicao da tarefa

- Identificadores dos acionamentos permitidos e quantidades, quando houver estoque.
- Massa do objeto: 5 kg no escopo inicial, alem da garra.
- Posicao do centro de massa do objeto em relacao a garra e sua inercia, ou hipotese explicita.
- Posicoes de coleta e deposito no referencial da base, em metros.
- Orientacao compativel com os quatro graus de liberdade da familia escolhida.
- Altura/caminho de transporte, tempos de movimento, pega, espera e soltura.
- Numero de repeticoes, pausas e tempo total de operacao.
- Alimentacao disponivel e restricoes adicionais, quando aplicaveis.

## Cadastro de cada acionamento

- Identificacao do motor, redutor e drive, fabricante, fonte e data de consulta.
- Curvas de torque-velocidade sob uma tensao e condicao termica identificadas.
- Torques continuo e de pico, duracao de pico e limites de corrente.
- Relacao de reducao, eficiencia de motorizacao e reversa quando conhecida.
- Limites mecanicos do redutor e capacidade de sustentacao.
- Massa, local de instalacao, dimensoes, inercia do rotor e propriedades da carcaca.
- Condicoes de dissipacao, modelo termico ou regime permitido pelo fabricante.
- Custo e disponibilidade, se forem criterios de classificacao.

Dados nao informados sao desconhecidos; nunca devem ser convertidos em zero ou
em ausencia de limite para aprovar uma configuracao.

## Familia de bracos

Ficam definidos no projeto: disposicao das juntas, intervalos de comprimentos,
material, secoes, limites angulares, geometria da garra e regras de instalacao
dos acionamentos. A pessoa requisitante nao precisa fornecer um CAD completo.

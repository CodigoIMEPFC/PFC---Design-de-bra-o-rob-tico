function carga = carga_pontual(massa,pontoTCP)
%CARGA_PONTUAL Hipotese explicita: massa sem inercia propria de rotacao.
% O ponto e expresso no referencial do ultimo elo (TCP).
if nargin<2, pontoTCP=zeros(3,1); end
validateattributes(massa,{'numeric'},{'scalar','finite','nonnegative','real'});
validateattributes(pontoTCP,{'numeric'},{'vector','numel',3,'finite','real'});
carga.mass=massa; carga.com=pontoTCP(:);
carga.assumption='Massa pontual; nao representa dimensoes ou inercia propria do objeto.';
end

function r = resolver_posicao(p,alvo,q0,ativas)
%RESOLVER_POSICAO DLS de posicao; nao impõe orientacao de ferramenta.
% Retorna atingido=false se o ponto nao convergir. Nunca aprova esse caso.
braco.validar_modelo(p);
validateattributes(alvo,{'numeric'},{'vector','numel',3,'finite','real'});
validateattributes(q0,{'numeric'},{'vector','numel',p.n,'finite','real'});
validateattributes(ativas,{'numeric'},{'vector','integer','>=',1,'<=',p.n});
assert(numel(unique(ativas))==numel(ativas),'braco:JuntasInvalidas','Juntas repetidas.');
q=q0(:); alvo=alvo(:); tol=1e-5; lambda=1e-2;
limitesVerificados=isfield(p,'q_limits') && all(isfinite(p.q_limits(:)));
if isfield(p,'q_limits')
    conhecidos=all(isfinite(p.q_limits),2);
    assert(all(q(conhecidos)>=p.q_limits(conhecidos,1) & ...
        q(conhecidos)<=p.q_limits(conhecidos,2)), ...
        'braco:ConfiguracaoInicialInvalida','q0 viola limites posicionais.');
else
    conhecidos=false(p.n,1);
end
for k=1:1500
    [J,~,pos]=braco.jacobiana(q,p);
    erro=alvo-pos;
    if norm(erro)<=tol, break; end
    J=J(:,ativas);
    passo=0.8*((J.'*J+lambda^2*eye(numel(ativas)))\(J.'*erro));
    if norm(passo)>0.08, passo=passo*0.08/norm(passo); end
    if norm(passo)<1e-12, break; end
    q(ativas)=q(ativas)+passo;
    if any(conhecidos)
        q(conhecidos)=max(p.q_limits(conhecidos,1), ...
            min(p.q_limits(conhecidos,2),q(conhecidos)));
    end
end
[~,T]=braco.cinematica(q,p);
r.q=q; r.posicao=T(1:3,4); r.erro_m=norm(alvo-r.posicao);
r.atingido=r.erro_m<=tol; r.tolerancia_m=tol; r.iteracoes=k;
r.limites_posicionais_verificados=limitesVerificados;
r.orientacao_verificada=false;
end

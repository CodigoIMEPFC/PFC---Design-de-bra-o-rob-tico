function [Q,dQ,ddQ] = quintica(qi,qf,t,T)
%QUINTICA Mesma lei temporal do original, com entradas e intervalos validados.
validateattributes(T,{'numeric'},{'scalar','positive','finite','real'});
validateattributes(t,{'numeric'},{'vector','finite','real','nonnegative','<=',T});
validateattributes(qi,{'numeric'},{'vector','finite','real'});
validateattributes(qf,{'numeric'},{'vector','finite','real','numel',numel(qi)});
assert(all(diff(t)>0),'braco:TempoInvalido','Os tempos devem ser crescentes.');
u=t(:).'/T;
s=10*u.^3-15*u.^4+6*u.^5;
ds=(30*u.^2-60*u.^3+30*u.^4)/T;
dds=(60*u-180*u.^2+120*u.^3)/T^2;
delta=qf(:)-qi(:);
Q=qi(:)+delta*s; dQ=delta*ds; ddQ=delta*dds;
end

function p = modelo_ur5_cb3()
%MODELO_UR5_CB3 Reproduz os parametros do arquivo fornecido pelo usuario.
% A denominacao UR5e dos comentarios originais nao corresponde a estes DH.
% Este modelo e uma referencia numerica, com inercias rotacionais incompletas.
p.n = 6;
p.a = [0 -0.425 -0.39225 0 0 0];
p.d = [0.089159 0 0 0.10915 0.09465 0.0823];
p.alpha = [pi/2 0 0 pi/2 -pi/2 0];
p.m = [3.7 8.393 2.33 1.219 1.219 0.1879];
p.pc = [0 0.2125 0.15 0 0 0; ...
    -0.02561 0 0 -0.0018 0.0018 0; ...
    0.00193 0.11336 0.0265 0.01634 0.01634 -0.001159];
p.Icm = zeros(3,3,6);
p.Icm(3,3,6) = 0.000144;
p.gravity = [0;0;-9.81];
p.free_idx = [2 3 4 5];
p.q0 = [0;-pi/2;0;-pi/2;0;0];
p.q_limits = nan(6,2); % Nao foram especificados limites posicionais no original.
p.inertias_complete = false;
p.source = 'Dimensionamento_Motores_4_Juntas_Livres_Claude.m';
p.description = 'UR5 CB3 de referencia; quatro juntas ativas, seis elos';
braco.validar_modelo(p);
end

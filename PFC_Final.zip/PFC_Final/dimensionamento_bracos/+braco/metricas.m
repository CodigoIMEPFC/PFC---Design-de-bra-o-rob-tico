function r = metricas(t,dq,tauExigido)
%METRICAS Requisitos calculados na trajetoria; nao usar torque saturado aqui.
% dq e tauExigido: n juntas x N amostras. Integral usa os tempos efetivos.
t=t(:).';
assert(numel(t)>=2 && all(isfinite(t)) && all(diff(t)>0), ...
    'braco:TempoInvalido','O vetor de tempos deve ser finito e crescente.');
assert(isequal(size(dq),size(tauExigido)) && size(dq,2)==numel(t), ...
    'braco:HistoricoInvalido','Historicos devem ser n x N.');
assert(all(isfinite(dq(:))) && all(isfinite(tauExigido(:))), ...
    'braco:HistoricoInvalido','Historicos com dados nao finitos.');
duracao=t(end)-t(1);
potencia=tauExigido.*dq;
r.torque_pico_Nm=max(abs(tauExigido),[],2);
r.torque_rms_Nm=sqrt(trapz(t,tauExigido.^2,2)/duracao);
r.velocidade_pico_rad_s=max(abs(dq),[],2);
r.potencia_pico_W=max(abs(potencia),[],2);
r.energia_motora_J=trapz(t,max(potencia,0),2);
r.energia_regenerativa_mecanica_J=trapz(t,max(-potencia,0),2);
r.duracao_s=duracao;
end

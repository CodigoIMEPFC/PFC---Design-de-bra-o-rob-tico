function [tau,partes] = dinamica(q,dq,ddq,p,carga)
%DINAMICA Esforcos EXIGIDOS pela trajetoria, sem limitar o torque calculado.
% M(q)*ddq + h(q,dq) + G(q). Todas as unidades sao SI.
% Coriolis calculado por diferencas centrais, como na referencia recebida.
% Nao inclui rotores, redutores, atrito, drive ou controle nesta primeira etapa.
if nargin<5, carga=braco.carga_pontual(0); end
q=q(:); dq=dq(:); ddq=ddq(:);
validateattributes(dq,{'numeric'},{'numel',p.n,'finite','real'});
validateattributes(ddq,{'numeric'},{'numel',p.n,'finite','real'});
M=braco.massa(q,p,carga); G=braco.gravidade(q,p,carga);
h=zeros(p.n,1);
if any(dq~=0)
    delta=1e-6; dM=zeros(p.n,p.n,p.n);
    for k=1:p.n
        offset=zeros(p.n,1); offset(k)=delta;
        dM(:,:,k)=(braco.massa(q+offset,p,carga)- ...
            braco.massa(q-offset,p,carga))/(2*delta);
    end
    for i=1:p.n
        for j=1:p.n
            for k=1:p.n
                h(i)=h(i)+0.5*(dM(i,j,k)+dM(i,k,j)-dM(j,k,i))*dq(j)*dq(k);
            end
        end
    end
end
tau=M*ddq+h+G;
partes=struct('M',M,'h',h,'G',G,'inercial',M*ddq);
end

function validar_modelo(p)
%VALIDAR_MODELO Confere dimensoes, unidades SI implicitas e dados fisicos.
validateattributes(p.n,{'numeric'},{'scalar','integer','positive'});
n = p.n;
for nome = {'a','d','alpha','m'}
    validateattributes(p.(nome{1}),{'numeric'},{'vector','numel',n,'finite','real'});
end
assert(all(p.m >= 0),'braco:MassaInvalida','As massas nao podem ser negativas.');
validateattributes(p.pc,{'numeric'},{'size',[3 n],'finite','real'});
assert(size(p.Icm,1)==3 && size(p.Icm,2)==3 && size(p.Icm,3)==n, ...
    'braco:InerciaInvalida','Icm deve ter dimensao 3 x 3 x n.');
validateattributes(p.Icm,{'numeric'},{'finite','real'});
validateattributes(p.gravity,{'numeric'},{'vector','numel',3,'finite','real'});
for i=1:n
    I=p.Icm(:,:,i);
    assert(norm(I-I.','fro')<1e-10,'braco:InerciaInvalida','Tensor nao simetrico.');
    e=eig(I);
    assert(min(e)>=-1e-12,'braco:InerciaInvalida','Tensor com autovalor negativo.');
    % A referencia recebida mantem somente Izz no elo 6: ela nao constitui
    % um tensor fisico completo. Permitir sua REPRODUCAO exige flag explicito.
    referenciaIncompleta=isfield(p,'inertias_complete') && isequal(p.inertias_complete,false);
    if ~referenciaIncompleta
        assert(2*max(e)<=sum(e)+1e-10,'braco:InerciaInvalida', ...
            'Momentos principais fisicamente inconsistentes.');
    end
end
if isfield(p,'q_limits')
    assert(isequal(size(p.q_limits),[n 2]),'braco:LimitesInvalidos','Limites devem ser n x 2.');
    for i=1:n
        lim=p.q_limits(i,:);
        assert(all(isnan(lim)) || (all(isfinite(lim)) && lim(1)<lim(2)), ...
            'braco:LimitesInvalidos','Cada junta requer dois limites validos ou dois NaN.');
    end
end
end

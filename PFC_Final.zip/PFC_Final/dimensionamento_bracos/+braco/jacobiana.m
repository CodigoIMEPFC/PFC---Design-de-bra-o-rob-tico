function [Jv,Jw,posicao] = jacobiana(q,p,elo,pontoLocal)
%JACOBIANA Jacobianas de um ponto expresso no referencial do elo.
% Diferentemente do original, o numero de juntas nao esta fixado em seis.
if nargin<3, elo=p.n; end
if nargin<4, pontoLocal=zeros(3,1); end
validateattributes(elo,{'numeric'},{'scalar','integer','>=',1,'<=',p.n});
validateattributes(pontoLocal,{'numeric'},{'vector','numel',3,'finite','real'});
[T,~]=braco.cinematica(q,p);
point=T{elo+1}*[pontoLocal(:);1]; posicao=point(1:3);
Jv=zeros(3,p.n); Jw=Jv;
for j=1:elo
    z=T{j}(1:3,3); origem=T{j}(1:3,4);
    Jv(:,j)=cross(z,posicao-origem); Jw(:,j)=z;
end
end

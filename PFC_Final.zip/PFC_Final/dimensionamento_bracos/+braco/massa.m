function M = massa(q,p,carga)
%MASSA Matriz de massa por Jacobianas; inclui carga pontual uma unica vez.
if nargin<3, carga=braco.carga_pontual(0); end
[T,~]=braco.cinematica(q,p); M=zeros(p.n);
for i=1:p.n
    R=T{i+1}(1:3,1:3); point=T{i+1}*[p.pc(:,i);1];
    Jv=zeros(3,p.n); Jw=Jv;
    for j=1:i
        z=T{j}(1:3,3);
        Jv(:,j)=cross(z,point(1:3)-T{j}(1:3,4)); Jw(:,j)=z;
    end
    M=M+p.m(i)*(Jv.'*Jv)+Jw.'*R*p.Icm(:,:,i)*R.'*Jw;
end
if carga.mass>0
    Jv=braco.jacobiana(q,p,p.n,carga.com);
    M=M+carga.mass*(Jv.'*Jv);
end
end

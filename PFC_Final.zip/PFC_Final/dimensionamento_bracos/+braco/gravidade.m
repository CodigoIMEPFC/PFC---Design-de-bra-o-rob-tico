function G = gravidade(q,p,carga)
%GRAVIDADE Torque de sustentacao para a orientacao da gravidade fornecida.
if nargin<3, carga=braco.carga_pontual(0); end
G=zeros(p.n,1);
for i=1:p.n
    Jv=braco.jacobiana(q,p,i,p.pc(:,i));
    G=G-Jv.'*(p.m(i)*p.gravity(:));
end
if carga.mass>0
    Jv=braco.jacobiana(q,p,p.n,carga.com);
    G=G-Jv.'*(carga.mass*p.gravity(:));
end
end

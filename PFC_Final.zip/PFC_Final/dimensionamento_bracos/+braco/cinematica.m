function [T,Ttcp] = cinematica(q,p)
%CINEMATICA DH padrao para n juntas rotativas; T{1} e a base.
validateattributes(q,{'numeric'},{'vector','numel',p.n,'finite','real'});
T=cell(p.n+1,1); T{1}=eye(4);
for i=1:p.n
    c=cos(q(i)); s=sin(q(i)); ca=cos(p.alpha(i)); sa=sin(p.alpha(i));
    A=[c -s*ca s*sa p.a(i)*c; s c*ca -c*sa p.a(i)*s; ...
        0 sa ca p.d(i); 0 0 0 1];
    T{i+1}=T{i}*A;
end
Ttcp=T{end};
end

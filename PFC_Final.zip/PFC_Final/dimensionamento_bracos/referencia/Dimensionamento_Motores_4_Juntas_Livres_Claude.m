clear; clc; close all;

%% ============================================================
%  PRE-DIMENSIONAMENTO DE MOTORES, REDUTORES, DRIVES E FREIOS
%  UR5e COMO MODELO DE REFERENCIA - 4 JUNTAS LIVRES [q2 q3 q4 q5]
%
%  Este arquivo ESTENDE Controle_Robusto_4_Juntas_Livres.m sem
%  substitui-lo. Ele mantem:
%     - cinematica e dinamica espacial completas (6 juntas);
%     - juntas travadas q1 e q6 (posicao fixa, dq = ddq = 0);
%     - controle PD por torque calculado com compensacao dinamica:
%           e     = q_d - q
%           ed    = dq_d - dq
%           v     = ddq_d + Kd*ed + Kp*e
%           tau_f = Mff(q)*v + h_f(q,dq) + G_f(q) + tau_payload_f
%     - planta real integrada em malha fechada por RK4 passo fixo;
%     - trajetoria quintica de duas fases (ida sem carga / volta com
%       carga), saturacao de torque, potencia, energia e metricas.
%
%  E ACRESCENTA o pre-dimensionamento dos acionamentos:
%     - varredura de cenarios (Tf x payload x relacao de reducao);
%     - requisitos mecanicos por junta (torque pico/RMS, velocidade,
%       aceleracao, potencia motora/regenerativa, energia);
%     - conversao para o eixo do motor (reducao + eficiencia);
%     - fatores de seguranca configuraveis;
%     - inercia efetiva e inercia refletida;
%     - freio de estacionamento, parada de emergencia simplificada;
%     - opcionais: atrito, inercia do rotor, potencia eletrica,
%       modelo termico de 1a ordem, motor candidato;
%     - tabelas CSV/MAT e graficos PNG/EPS para consulta de catalogos.
%
%  IMPORTANTE - ESTE E UM CODIGO DE PRE-DIMENSIONAMENTO:
%     Os resultados servem para CONSULTAR catalogos de servomotores,
%     redutores, drives e freios, NAO para selecionar automaticamente
%     um modelo comercial nem para liberar operacao de um robo real.
%     Validacoes obrigatorias antes de compra estao listadas ao final
%     do arquivo e na documentacao da resposta.
%
%  LIMITACAO CONHECIDA DO MODELO (herdada do arquivo original):
%     params.Icm = zeros(3,3,6) com apenas um pequeno termo no elo 6.
%     Ou seja, os TENSORES DE INERCIA DOS ELOS ESTAO INCOMPLETOS.
%     Os torques inerciais podem estar SUBESTIMADOS. O flag
%     dados_inerciais_completos = false gera aviso explicito.
%     NAO invente tensores: obtenha-os de CAD/identificacao.
%% ============================================================

t_execucao_total = tic;

%% ============================================================
%  1) ENTRADA DO PROBLEMA (identica ao arquivo original)
%% ============================================================

% Pastas de saida
outDir  = 'resultados_dimensionamento';
imgDir  = fullfile(outDir, 'img');
if ~exist(outDir, 'dir'), mkdir(outDir); end
if ~exist(imgDir, 'dir'), mkdir(imgDir); end

% Posicao desejada do TCP em relacao a base {0} [m]
p_des = [0.2;
        -0.1;
         0.30];

% Configuracao inicial [rad]
q0 = [0;
     -pi/2;
      0;
     -pi/2;
      0;
      0];

% Juntas livres e travadas
free_idx  = [2 3 4 5];
fixed_idx = setdiff(1:6, free_idx);
nJ = length(free_idx);

% Gravidade [m/s^2] e vetor gravidade na base (z para cima)
gval  = 9.81;
grav0 = [0; 0; -gval];  %#ok<NASGU> % documentacao do referencial

%% ============================================================
%  2) CENARIOS DE DIMENSIONAMENTO (CONFIGURAVEL)
%% ============================================================
%
% O programa executa TODAS as combinacoes de:
%   - Tf_list      : tempo de cada fase [s] (ciclo completo = 2*Tf);
%   - payload_list : carga no TCP durante a FASE 2 (retorno) [kg];
%   - Nred_options : opcoes de relacao de reducao por junta.
%
% Observacao de eficiencia computacional: sem a inercia do rotor na
% planta (incluir_inercia_rotor_na_planta = false), a DINAMICA DA
% JUNTA nao depende da reducao. Nesse caso a simulacao e feita uma
% unica vez por (Tf, payload) e as reducoes sao avaliadas apenas na
% conversao junta -> motor, evitando simulacoes repetidas identicas.

Tf_list      = [2 5 10];        % [s]  tempos de fase a comparar
payload_list = [0 1 3 5];       % [kg] payloads no retorno a comparar

% Opcoes de reducao: cada LINHA e uma alternativa [N_q2 N_q3 N_q4 N_q5]
Nred_options = [
    50  50  50  50;
    80  80  60  60;
    100 100 80  80
];

% Eficiencia mecanica de cada redutor (ordem [q2 q3 q4 q5])
eta_red = [0.75; 0.75; 0.70; 0.70];   % [-] 0 < eta <= 1

% Reducao de REFERENCIA usada nas avaliacoes que exigem UM valor de N
% (motor candidato: corrente/tensao, razao de inercia, termico).
idx_reducao_referencia = 1;

%% ============================================================
%  3) CONTROLADOR (PRESERVADO DO ARQUIVO ORIGINAL)
%% ============================================================
%
% Classificacao tecnica (NAO alterar a estrategia):
%     Controle PD por torque calculado com compensacao dinamica
% Malha fechada ideal por junta livre: e_dd + Kd*e_d + Kp*e = 0
%     Kp = wn^2 ,  Kd = 2*zeta*wn

wn   = 10*ones(nJ,1);      % [rad/s] frequencia natural por junta livre
zeta = 1.0*ones(nJ,1);     % [-] amortecimento por junta livre

Kp = diag(wn.^2);          % ganho proporcional
Kd = diag(2*zeta.*wn);     % ganho derivativo

% O controlador conhece a carga? (feedforward exato da carga)
controlador_compensa_carga = true;

%% ============================================================
%  4) SATURACAO DE TORQUE (PARAMETROS PROVISORIOS)
%% ============================================================
%
% ATENCAO: valores PROVISORIOS de simulacao (ordem [q2 q3 q4 q5]).
% Devem ser substituidos pelos limites reais do conjunto
% motor + redutor + drive assim que esses componentes forem definidos.

tau_max = [150; 150; 28; 28];   % [N.m] por junta livre (PROVISORIO)

% Tolerancia de saturacao admissivel no pre-dimensionamento
percentual_saturacao_max_admissivel = 0.1;   % [% do tempo de ciclo]

%% ============================================================
%  5) FATORES DE SEGURANCA (PARAMETROS DE PROJETO, NAO UNIVERSAIS)
%% ============================================================
%
% Estes fatores sao ESCOLHAS DE PROJETO configuraveis. Ajuste-os
% conforme normas internas, criticidade da aplicacao, incertezas do
% modelo (aqui aumentadas pelos tensores de inercia incompletos) e
% recomendacoes dos fabricantes. NAO sao valores universais.

FS_tau_peak = 1.5;    % sobre o torque de pico no motor
FS_tau_rms  = 1.25;   % sobre o torque RMS no motor
FS_vel      = 1.10;   % sobre a velocidade maxima do motor
FS_acc      = 1.10;   % sobre a aceleracao maxima do motor
FS_pot      = 1.25;   % sobre a potencia mecanica de pico
FS_freio    = 1.5;    % sobre o torque gravitacional de retencao

%% ============================================================
%  6) MOTOR CANDIDATO (OPCIONAL - NAO INVENTAR VALORES)
%% ============================================================
%
% Preencha SOMENTE com dados reais de catalogo. Todos os vetores tem
% 4 elementos na ordem das juntas livres [q2 q3 q4 q5].
% Com avaliar_motor_candidato = false, os campos ficam NaN e todas as
% verificacoes dependentes de motor sao puladas.

avaliar_motor_candidato = false;

if avaliar_motor_candidato
    % ----- PREENCHER COM DADOS DE CATALOGO (exemplo de formato) -----
    Kt            = nan(nJ,1);   % [N.m/A]   constante de torque
    Ke            = nan(nJ,1);   % [V.s/rad] constante de FCEM (fase-fase, coerente com Kt)
    Rmotor        = nan(nJ,1);   % [ohm]     resistencia de enrolamento
    I_cont_motor  = nan(nJ,1);   % [A]       corrente continua
    I_peak_motor  = nan(nJ,1);   % [A]       corrente de pico
    V_bus         = nan(nJ,1);   % [V]       tensao do barramento CC
    J_motor       = nan(nJ,1);   % [kg.m^2]  inercia do rotor
    rpm_nom_motor = nan(nJ,1);   % [rpm]     velocidade nominal
    rpm_max_motor = nan(nJ,1);   % [rpm]     velocidade maxima
    tau_cont_motor= nan(nJ,1);   % [N.m]     torque continuo
    tau_peak_motor= nan(nJ,1);   % [N.m]     torque de pico
    P_nom_motor   = nan(nJ,1);   % [W]       potencia nominal
else
    Kt=nan(nJ,1); Ke=nan(nJ,1); Rmotor=nan(nJ,1); I_cont_motor=nan(nJ,1);
    I_peak_motor=nan(nJ,1); V_bus=nan(nJ,1); J_motor=nan(nJ,1);
    rpm_nom_motor=nan(nJ,1); rpm_max_motor=nan(nJ,1);
    tau_cont_motor=nan(nJ,1); tau_peak_motor=nan(nJ,1); P_nom_motor=nan(nJ,1);
end

% Incluir a inercia do rotor refletida na planta?
%   Mff_tot = Mff_tot + diag(J_motor .* Nred.^2)
% So faz sentido quando J_motor (catalogo) e a reducao ja estiverem
% definidos; exige avaliar_motor_candidato = true. Com este flag ativo
% a dinamica da junta passa a depender da reducao e a simulacao e
% repetida para cada opcao de Nred_options.
incluir_inercia_rotor_na_planta = false;

%% ============================================================
%  7) ATRITO (OPCIONAL)
%% ============================================================
%
% Modelo viscoso + Coulomb suavizado (tanh), aplicado na PLANTA:
%   tau_atrito = Bv.*dq_f + Fc.*tanh(dq_f/vel_suavizacao)
%   ddq_f = Mff \ (tau_cmd - hf - Gf - tau_atrito)
% O controlador NAO compensa atrito (permanece o PD por torque
% calculado original); o atrito atua como perturbacao realista.
% Preencha Bv e Fc com valores identificados/estimados; zeros = sem atrito.

incluir_atrito  = false;
Bv              = zeros(nJ,1);   % [N.m.s/rad] atrito viscoso por junta livre
Fc              = zeros(nJ,1);   % [N.m]       atrito de Coulomb por junta livre
vel_suavizacao  = 0.01;          % [rad/s]     suavizacao do sinal de dq

%% ============================================================
%  8) POTENCIA ELETRICA APROXIMADA (OPCIONAL)
%% ============================================================
%
% CONVENCAO DE SINAIS (documentada):
%   P_joint = tau*dq  -> mecanica na junta;
%   P_pos = max(P,0)  -> quadrante MOTOR  (motor entrega energia);
%   P_neg = max(-P,0) -> quadrante GERADOR (energia volta ao drive).
%   Eletrica consumida do barramento:  P_ele_mot = P_pos ./ eta_motor
%   Eletrica devolvida ao barramento:  P_ele_reg = P_neg .* eta_regen
% Potencia MECANICA e potencia ELETRICA nao se confundem: as
% eficiencias so entram nesta secao.

calcular_potencia_eletrica = false;
eta_motor = [0.90; 0.90; 0.85; 0.85];   % [-] eficiencia no quadrante motor
eta_regen = [0.70; 0.70; 0.65; 0.65];   % [-] eficiencia na regeneracao

%% ============================================================
%  9) MODELO TERMICO DE 1a ORDEM (OPCIONAL - EXIGE MOTOR CANDIDATO)
%% ============================================================
%
%   Cth*dT/dt = P_perdas - (T - Tamb)/Rth ,  P_perdas ~ P_Cu = I^2 * R
% Executado apenas com dados validos de motor (Rth, Cth, Rmotor, Kt).
% O ciclo pode ser repetido varias vezes para observar o regime.

calcular_modelo_termico = false;
Rth  = nan(nJ,1);      % [K/W]  resistencia termica enrolamento->ambiente
Cth  = nan(nJ,1);      % [J/K]  capacitancia termica
Tamb = 25;             % [degC] temperatura ambiente
Tmax_motor = nan(nJ,1);% [degC] temperatura maxima admissivel
numero_ciclos_termicos   = 10;
tempo_pausa_entre_ciclos = 0;   % [s] pausa (I=0) entre ciclos

%% ============================================================
%  10) PARADA DE EMERGENCIA SIMPLIFICADA
%% ============================================================
%
% Estimativa: no instante de MAIOR VELOCIDADE de cada junta, impoe-se
% desaceleracao constante ddq_emerg = -dq_atual/tempo_parada em TODAS
% as juntas livres simultaneamente e calcula-se
%   tau_emerg = Mff*ddq_emerg + hf + Gf (+ atrito, se habilitado)
% AVISO: estimativa SIMPLIFICADA para pre-dimensionamento. NAO
% substitui a analise de seguranca funcional (ISO 10218/13849, perfis
% de parada reais do drive, freios, etc).

avaliar_parada_emergencia = true;
tempo_parada_emergencia   = 0.2;   % [s]

%% ============================================================
%  11) SIMULACAO DINAMICA E DESEMPENHO COMPUTACIONAL
%% ============================================================

dt            = 1e-3;    % [s] passo RK4 (1 kHz, compativel com e-Series)
usar_coriolis = true;    % Coriolis numerico (fiel, porem lento)
modo_rapido   = false;   % true: desativa Coriolis e usa dt maior
                         % (resultados PRELIMINARES)

if modo_rapido
    usar_coriolis = false;
    dt = 2e-3;
    fprintf(['MODO RAPIDO ATIVO: Coriolis numerico desativado e ', ...
             'dt = %.1e s.\nOs resultados sao PRELIMINARES.\n\n'], dt);
end

% Amostragem das verificacoes numericas e decimacao dos historicos
verif_stride     = 200;    % amostras entre verificacoes de Mff
store_max_pontos = 4000;   % pontos maximos armazenados por cenario
                           % (metricas usam SEMPRE a resolucao cheia)

%% ============================================================
%  12) PARAMETROS DH E DINAMICOS DO UR5e (MODELO DE REFERENCIA)
%% ============================================================

params.n = 6;
params.a = [0, -0.425, -0.39225, 0, 0, 0];

params.d = [0.089159, 0, 0, 0.10915, 0.09465, 0.0823];

params.alpha = [pi/2, 0, 0, pi/2, -pi/2, 0];

params.m = [3.7, 8.393, 2.33, 1.219, 1.219, 0.1879];

params.pc = [ ...
     0,        0.2125,  0.15,     0,        0,        0;
    -0.02561,  0,       0,       -0.0018,   0.0018,   0;
     0.00193,  0.11336, 0.0265,   0.01634,  0.01634, -0.001159 ];

% Dados herdados do arquivo-base: incompletos.
params.Icm = zeros(3,3,6);

params.Icm(:,:,6) = [
    0, 0, 0;
    0, 0, 0;
    0, 0, 0.000144
];

% Flag de qualidade dos dados inerciais (req. 19)
dados_inerciais_completos = false;
if ~dados_inerciais_completos
    warning(['ATENCAO: os torques inerciais podem estar SUBESTIMADOS ', ...
             'porque os tensores de inercia dos elos nao estao completos ', ...
             '(params.Icm quase nulo). Complete-os com dados de CAD ou ', ...
             'identificacao antes de decisoes finais de compra.']);
end

%% ============================================================
%  13) VALIDACAO DAS CONFIGURACOES (req. 18, parte 1)
%% ============================================================

assert(all(Tf_list > 0), 'Tf_list deve conter tempos positivos.');
assert(all(payload_list >= 0), 'payload_list nao pode ter valores negativos.');
assert(size(Nred_options,2) == nJ, ...
    'Nred_options deve ter %d colunas (uma por junta livre).', nJ);
assert(all(Nred_options(:) > 0), 'Relacoes de reducao devem ser positivas.');
assert(all(eta_red > 0 & eta_red <= 1), 'eta_red deve estar em (0, 1].');
assert(numel(eta_red) == nJ, 'eta_red deve ter %d elementos.', nJ);
assert(all([FS_tau_peak FS_tau_rms FS_vel FS_acc FS_pot FS_freio] > 0), ...
    'Todos os fatores de seguranca devem ser positivos.');
assert(idx_reducao_referencia >= 1 && idx_reducao_referencia <= size(Nred_options,1), ...
    'idx_reducao_referencia fora do intervalo de Nred_options.');
assert(isequal(size(Kp),[nJ nJ]) && isequal(size(Kd),[nJ nJ]), ...
    'Kp e Kd devem ser %d x %d.', nJ, nJ);
assert(all(tau_max > 0) && numel(tau_max) == nJ, ...
    'tau_max deve ser vetor positivo de %d elementos.', nJ);
assert(numel(Bv)==nJ && numel(Fc)==nJ && vel_suavizacao > 0, ...
    'Parametros de atrito com dimensao/valor invalidos.');
assert(all(eta_motor > 0 & eta_motor <= 1) && all(eta_regen > 0 & eta_regen <= 1), ...
    'eta_motor e eta_regen devem estar em (0, 1].');

if avaliar_motor_candidato
    dadosMotor = {Kt,Ke,Rmotor,I_cont_motor,I_peak_motor,V_bus,J_motor, ...
                  rpm_nom_motor,rpm_max_motor,tau_cont_motor, ...
                  tau_peak_motor,P_nom_motor};
    for ii = 1:numel(dadosMotor)
        assert(numel(dadosMotor{ii}) == nJ, ...
            'Dados do motor candidato devem ser vetores de %d elementos.', nJ);
    end
    assert(all(isfinite(Kt) & Kt > 0), ...
        'Preencha Kt com valores reais de catalogo (sem NaN).');
end

if incluir_inercia_rotor_na_planta && ...
        (~avaliar_motor_candidato || any(~isfinite(J_motor)))
    warning(['incluir_inercia_rotor_na_planta exige dados validos de ', ...
             'J_motor (motor candidato). Opcao DESATIVADA.']);
    incluir_inercia_rotor_na_planta = false;
end

if calcular_modelo_termico && (~avaliar_motor_candidato || ...
        any(~isfinite(Rth)) || any(~isfinite(Cth)) || ...
        any(~isfinite(Rmotor)) || any(~isfinite(Kt)))
    warning(['Modelo termico exige Rth, Cth, Rmotor e Kt validos do ', ...
             'motor candidato. Opcao DESATIVADA.']);
    calcular_modelo_termico = false;
end

%% ============================================================
%  14) CINEMATICA INVERSA REDUZIDA (uma unica vez: nao depende
%      de Tf, payload ou reducao)
%% ============================================================

[q_goal, ik] = ik_reduzida(q0, p_des, free_idx, params);

fprintf('\n============================================================\n');
fprintf('CINEMATICA INVERSA REDUZIDA (4 juntas livres)\n');
fprintf('============================================================\n');
fprintf('Erro absoluto da IK [m]: %.3e   (iteracoes: %d)\n', ...
        ik.erro_abs, ik.iters);
fprintf('q_goal [graus]: '); fprintf('%8.3f ', rad2deg(q_goal)); fprintf('\n');

ponto_alcancavel = (ik.erro_abs <= 5e-3);
if ~ponto_alcancavel
    warning(['Erro final da IK maior que 5 mm: o ponto desejado pode nao ', ...
             'pertencer ao espaco alcancavel das juntas livres. A varredura ', ...
             'prossegue rastreando o q_goal obtido.']);
end

%% ============================================================
%  15) VARREDURA DE CENARIOS (simulacao em malha fechada)
%% ============================================================

nTf  = numel(Tf_list);
nPay = numel(payload_list);
nRed = size(Nred_options,1);

% Sem inercia de rotor na planta, a dinamica da junta independe de N:
% simula-se 1x por (Tf, payload) e as reducoes entram so na conversao.
if incluir_inercia_rotor_na_planta
    nRedSim = nRed;
else
    nRedSim = 1;
end

% Estrutura de configuracao passada as funcoes (evita variaveis globais)
cfg = struct();
cfg.free_idx = free_idx;       cfg.gval = gval;
cfg.dt = dt;                   cfg.usar_coriolis = usar_coriolis;
cfg.Kp = Kp;                   cfg.Kd = Kd;
cfg.tau_max = tau_max;
cfg.controlador_compensa_carga = controlador_compensa_carga;
cfg.incluir_atrito = incluir_atrito;
cfg.Bv = Bv; cfg.Fc = Fc; cfg.vel_suav = vel_suavizacao;
cfg.avaliar_emerg = avaliar_parada_emergencia;
cfg.tp_emerg = tempo_parada_emergencia;
cfg.verif_stride = verif_stride;
cfg.store_max_pontos = store_max_pontos;

Scen = cell(nTf, nPay, nRedSim);

% Estimativa de custo: numero de passos ~ 2*Tf/dt por cenario
custo_por_cenario = 2*repmat(Tf_list(:), 1, nPay*nRedSim)/dt;
custo_total = sum(custo_por_cenario(:));
custo_feito = 0;
total_cen   = nTf*nPay*nRedSim;
cont_cen    = 0;

fprintf('\n============================================================\n');
fprintf('VARREDURA: %d cenarios (%d Tf x %d payloads x %d simul. de reducao)\n', ...
        total_cen, nTf, nPay, nRedSim);
fprintf('============================================================\n');

t_varredura = tic;
for iTf = 1:nTf
    for iPay = 1:nPay
        for iRs = 1:nRedSim

            % Inercia do rotor refletida (se habilitada)
            if incluir_inercia_rotor_na_planta
                cfg.J_rotor_add = J_motor .* (Nred_options(iRs,:)'.^2);
            else
                cfg.J_rotor_add = zeros(nJ,1);
            end

            cont_cen = cont_cen + 1;
            fprintf(['[%2d/%2d] Tf = %5.2f s | payload = %4.1f kg', ...
                     ' | sim.reducao = %d ... '], ...
                    cont_cen, total_cen, Tf_list(iTf), ...
                    payload_list(iPay), iRs);

            t_cen = tic;
            S = simular_cenario(q0, q_goal, Tf_list(iTf), ...
                                payload_list(iPay), cfg, params);
            S.Tf      = Tf_list(iTf);
            S.payload = payload_list(iPay);
            S.iRedSim = iRs;

            % Potencia/energia ELETRICA aproximada (opcional, escalares)
            if calcular_potencia_eletrica
                S.P_eletrica_motora_peak = S.P_motora_peak ./ eta_motor;
                S.P_eletrica_regen_peak  = S.P_regen_peak  .* eta_regen;
                S.E_eletrica_consumida   = S.E_motora      ./ eta_motor;
                S.E_eletrica_regenerada  = S.E_regenerativa .* eta_regen;
            end

            Scen{iTf, iPay, iRs} = S;

            % Progresso e estimativa de tempo restante
            custo_feito = custo_feito + 2*Tf_list(iTf)/dt;
            taxa = toc(t_varredura)/custo_feito;      % [s por passo]
            eta_restante = taxa*(custo_total - custo_feito);
            fprintf('ok em %6.1f s | restante ~ %6.1f s\n', ...
                    toc(t_cen), eta_restante);
        end
    end
end
fprintf('Varredura concluida em %.1f s.\n', toc(t_varredura));

% Acesso uniforme: cenario (iTf,iPay) valido para a reducao r
get_scen = @(iTf, iPay, r) Scen{iTf, iPay, min(r, nRedSim)};

%% ============================================================
%  16) TABELA 1 - RESULTADOS DA JUNTA POR CENARIO
%% ============================================================
%
% OpcaoReducao = 0 indica que os resultados da JUNTA independem da
% reducao (inercia do rotor fora da planta). Com a inercia do rotor
% na planta, cada linha refere-se a opcao simulada correspondente.

nLin1 = total_cen*nJ;
T1 = struct();
c1n = {'Tf_s','Payload_kg','OpcaoReducao','Junta', ...
  'TorquePicoJunta_Nm','TorqueRMSJunta_Nm','TorqueGravidadePico_Nm', ...
  'TorqueInerciaPico_Nm','TorqueCargaPico_Nm','TorqueCoriolisPico_Nm', ...
  'TorqueFeedbackPico_Nm','TorqueAtritoPico_Nm', ...
  'VelocidadePicoJunta_rad_s','AceleracaoPicoJunta_rad_s2', ...
  'PotenciaPicoJunta_W','PotenciaMotoraPico_W','PotenciaRegenerativaPico_W', ...
  'EnergiaMotora_J','EnergiaRegenerativa_J', ...
  'TempoSaturado_s','PercentualSaturado', ...
  'ErroMaxJunta_rad','ErroRMSJunta_rad','ErroFinalJunta_rad'};
for cc = 1:numel(c1n), T1.(c1n{cc}) = zeros(nLin1,1); end

lin = 0;
for iTf = 1:nTf
  for iPay = 1:nPay
    for iRs = 1:nRedSim
      S = Scen{iTf,iPay,iRs};
      if incluir_inercia_rotor_na_planta, opRed = iRs; else, opRed = 0; end
      for jj = 1:nJ
        lin = lin + 1;
        T1.Tf_s(lin)         = S.Tf;
        T1.Payload_kg(lin)   = S.payload;
        T1.OpcaoReducao(lin) = opRed;
        T1.Junta(lin)        = free_idx(jj);
        T1.TorquePicoJunta_Nm(lin)      = S.tau_peak_junta(jj);
        T1.TorqueRMSJunta_Nm(lin)       = S.tau_rms_junta(jj);
        T1.TorqueGravidadePico_Nm(lin)  = S.tau_grav_peak(jj);
        T1.TorqueInerciaPico_Nm(lin)    = S.tau_inercia_peak(jj);
        T1.TorqueCargaPico_Nm(lin)      = S.tau_carga_peak(jj);
        T1.TorqueCoriolisPico_Nm(lin)   = S.tau_coriolis_peak(jj);
        T1.TorqueFeedbackPico_Nm(lin)   = S.tau_feedback_peak(jj);
        T1.TorqueAtritoPico_Nm(lin)     = S.tau_atrito_peak(jj);
        T1.VelocidadePicoJunta_rad_s(lin)  = S.omega_peak_junta(jj);
        T1.AceleracaoPicoJunta_rad_s2(lin) = S.alpha_peak_junta(jj);
        T1.PotenciaPicoJunta_W(lin)        = S.P_peak_junta(jj);
        T1.PotenciaMotoraPico_W(lin)       = S.P_motora_peak(jj);
        T1.PotenciaRegenerativaPico_W(lin) = S.P_regen_peak(jj);
        T1.EnergiaMotora_J(lin)            = S.E_motora(jj);
        T1.EnergiaRegenerativa_J(lin)      = S.E_regenerativa(jj);
        T1.TempoSaturado_s(lin)            = S.tempo_saturado(jj);
        T1.PercentualSaturado(lin)         = S.percentual_saturado(jj);
        T1.ErroMaxJunta_rad(lin)           = S.erro_max_junta(jj);
        T1.ErroRMSJunta_rad(lin)           = S.erro_rms_junta(jj);
        T1.ErroFinalJunta_rad(lin)         = S.erro_final_junta(jj);
      end
    end
  end
end
TabelaCenariosJunta = struct2table(T1);
fprintf('\nTabela 1 (TabelaCenariosJunta): %d linhas construidas.\n', ...
        height(TabelaCenariosJunta));

%% ============================================================
%  17) TABELA 2 - REQUISITOS NO MOTOR (JUNTA -> MOTOR)
%% ============================================================
%
% Conversao junta -> motor (redutor de relacao N, eficiencia eta):
%   tau_motor   = tau_junta / (eta*N)     (torque cai com N)
%   omega_motor = N * omega_junta         (velocidade sobe com N)
%   alpha_motor = N * alpha_junta
% A REDUCAO TROCA TORQUE POR VELOCIDADE, MAS NAO CRIA POTENCIA:
%   P_motor_mecanica = P_junta / eta   (apenas a eficiencia entra;
%   multiplicar potencia por N seria um erro fisico).
% O freio de estacionamento e dimensionado para SUSTENTAR a carga
% gravitacional (robo + payload) parada:
%   tau_freio_req = FS_freio * tau_grav_hold_peak   [lado da JUNTA]
% Se o freio ficar no eixo do MOTOR, divida por (eta*N) - mas cuidado:
% redutores pouco reversiveis mudam essa conta; confirme com o
% fabricante do redutor.

nLin2 = nTf*nPay*nRed*nJ;
T2 = struct();
c2n = {'Tf_s','Payload_kg','OpcaoReducao','Junta','RelacaoReducao', ...
  'EficienciaRedutor','TorqueMotorPico_Nm','TorqueMotorRMS_Nm', ...
  'TorqueMotorPicoReq_Nm','TorqueMotorRMSReq_Nm', ...
  'VelocidadeMotor_rpm','VelocidadeMotorReq_rpm', ...
  'AceleracaoMotor_rad_s2','PotenciaMotorReq_W', ...
  'InerciaCargaRefletida_kgm2','TorqueFreioReq_Nm'};
for cc = 1:numel(c2n), T2.(c2n{cc}) = zeros(nLin2,1); end

lin = 0;
for iTf = 1:nTf
  for iPay = 1:nPay
    for r = 1:nRed
      S = get_scen(iTf, iPay, r);
      Nv = Nred_options(r,:)';                      % [nJ x 1]

      tau_motor_peak = S.tau_peak_junta ./ (eta_red .* Nv);
      tau_motor_rms  = S.tau_rms_junta  ./ (eta_red .* Nv);
      omega_motor_peak = Nv .* S.omega_peak_junta;   % [rad/s]
      rpm_motor_peak   = omega_motor_peak * 60/(2*pi);
      alpha_motor_peak = Nv .* S.alpha_peak_junta;   % [rad/s^2]
      P_motor_peak_mecanica = S.P_peak_junta ./ eta_red;  % potencia nao escala com N

      tau_motor_peak_req = FS_tau_peak * tau_motor_peak;
      tau_motor_rms_req  = FS_tau_rms  * tau_motor_rms;
      rpm_motor_req      = FS_vel * rpm_motor_peak;
      alpha_motor_req    = FS_acc * alpha_motor_peak;
      P_motor_req        = FS_pot * P_motor_peak_mecanica;
      tau_freio_req      = FS_freio * S.tau_grav_hold_peak;  % lado da junta

      J_load_ref_max = S.J_junta_max ./ (Nv.^2);

      for jj = 1:nJ
        lin = lin + 1;
        T2.Tf_s(lin) = S.Tf;  T2.Payload_kg(lin) = S.payload;
        T2.OpcaoReducao(lin) = r;  T2.Junta(lin) = free_idx(jj);
        T2.RelacaoReducao(lin)    = Nv(jj);
        T2.EficienciaRedutor(lin) = eta_red(jj);
        T2.TorqueMotorPico_Nm(lin)    = tau_motor_peak(jj);
        T2.TorqueMotorRMS_Nm(lin)     = tau_motor_rms(jj);
        T2.TorqueMotorPicoReq_Nm(lin) = tau_motor_peak_req(jj);
        T2.TorqueMotorRMSReq_Nm(lin)  = tau_motor_rms_req(jj);
        T2.VelocidadeMotor_rpm(lin)    = rpm_motor_peak(jj);
        T2.VelocidadeMotorReq_rpm(lin) = rpm_motor_req(jj);
        T2.AceleracaoMotor_rad_s2(lin) = alpha_motor_req(jj);
        T2.PotenciaMotorReq_W(lin)     = P_motor_req(jj);
        T2.InerciaCargaRefletida_kgm2(lin) = J_load_ref_max(jj);
        T2.TorqueFreioReq_Nm(lin)          = tau_freio_req(jj);
      end
    end
  end
end
TabelaRequisitosMotor = struct2table(T2);
fprintf('Tabela 2 (TabelaRequisitosMotor): %d linhas construidas.\n', ...
        height(TabelaRequisitosMotor));

%% ============================================================
%  18) TABELA 3 - PIOR CASO GLOBAL POR JUNTA
%% ============================================================

WC = struct();
WC.Junta = free_idx(:);
WC.TorquePicoGlobal_Nm     = -inf(nJ,1);
WC.Tf_TorquePico_s         = zeros(nJ,1);
WC.Payload_TorquePico_kg   = zeros(nJ,1);
WC.Reducao_TorquePico      = zeros(nJ,1);
WC.TorqueRMSGlobal_Nm      = -inf(nJ,1);
WC.VelocidadeMotorMax_rpm  = -inf(nJ,1);
WC.PotenciaMotorMax_W      = -inf(nJ,1);
WC.EnergiaRegenerativaMax_J= -inf(nJ,1);
WC.TorqueEmergenciaMax_Nm  = zeros(nJ,1);
q_critico_global = zeros(6,nJ);          % configuracao no maior torque
scen_critico = zeros(nJ,3);              % [iTf iPay iRs] do pior torque

for iTf = 1:nTf
  for iPay = 1:nPay
    for iRs = 1:nRedSim
      S = Scen{iTf,iPay,iRs};
      for jj = 1:nJ
        % ----- pior torque de pico (lado da junta) -----
        if S.tau_peak_junta(jj) > WC.TorquePicoGlobal_Nm(jj)
            WC.TorquePicoGlobal_Nm(jj)   = S.tau_peak_junta(jj);
            WC.Tf_TorquePico_s(jj)       = S.Tf;
            WC.Payload_TorquePico_kg(jj) = S.payload;
            if incluir_inercia_rotor_na_planta
                WC.Reducao_TorquePico(jj) = iRs;
            else
                WC.Reducao_TorquePico(jj) = 0;  % independe da reducao
            end
            q_critico_global(:,jj) = S.q_tau_peak(:,jj);
            scen_critico(jj,:) = [iTf iPay iRs];
        end
        WC.TorqueRMSGlobal_Nm(jj) = ...
            max(WC.TorqueRMSGlobal_Nm(jj), S.tau_rms_junta(jj));
        WC.EnergiaRegenerativaMax_J(jj) = ...
            max(WC.EnergiaRegenerativaMax_J(jj), S.E_regenerativa(jj));
        if avaliar_parada_emergencia
            WC.TorqueEmergenciaMax_Nm(jj) = ...
                max(WC.TorqueEmergenciaMax_Nm(jj), S.tau_emergencia_peak(jj));
        end
        % ----- lado do motor: varre todas as opcoes de reducao -----
        for r = 1:nRed
          if nRedSim > 1 && r ~= iRs, continue; end
          Nv = Nred_options(r,:)';
          rpm_j = Nv(jj)*S.omega_peak_junta(jj)*60/(2*pi);
          P_j   = FS_pot*S.P_peak_junta(jj)/eta_red(jj);
          WC.VelocidadeMotorMax_rpm(jj) = max(WC.VelocidadeMotorMax_rpm(jj), rpm_j);
          WC.PotenciaMotorMax_W(jj)     = max(WC.PotenciaMotorMax_W(jj), P_j);
        end
      end
    end
  end
end

TabelaPiorCasoJunta = table(WC.Junta, WC.TorquePicoGlobal_Nm, ...
    WC.Tf_TorquePico_s, WC.Payload_TorquePico_kg, WC.Reducao_TorquePico, ...
    WC.TorqueRMSGlobal_Nm, WC.VelocidadeMotorMax_rpm, WC.PotenciaMotorMax_W, ...
    WC.EnergiaRegenerativaMax_J, WC.TorqueEmergenciaMax_Nm, ...
    q_critico_global(1,:).', q_critico_global(2,:).', q_critico_global(3,:).', ...
    q_critico_global(4,:).', q_critico_global(5,:).', q_critico_global(6,:).', ...
    'VariableNames', {'Junta','TorquePicoGlobal_Nm','Tf_TorquePico_s', ...
    'Payload_TorquePico_kg','Reducao_TorquePico','TorqueRMSGlobal_Nm', ...
    'VelocidadeMotorMax_rpm','PotenciaMotorMax_W','EnergiaRegenerativaMax_J', ...
    'TorqueEmergenciaMax_Nm', ...
    'ConfiguracaoCritica_q1_rad','ConfiguracaoCritica_q2_rad', ...
    'ConfiguracaoCritica_q3_rad','ConfiguracaoCritica_q4_rad', ...
    'ConfiguracaoCritica_q5_rad','ConfiguracaoCritica_q6_rad'});

fprintf('\n============================================================\n');
fprintf('TABELA 3 - PIOR CASO GLOBAL POR JUNTA\n');
fprintf('(Reducao_TorquePico = 0 => resultado independe da reducao)\n');
fprintf('============================================================\n');
disp(TabelaPiorCasoJunta);

%% ============================================================
%  19) MOTOR CANDIDATO: CORRENTE, TENSAO, INERCIA E VERIFICACOES
%% ============================================================
%
% Avaliado no PIOR CASO de cada junta, com a reducao de referencia
% idx_reducao_referencia. Modelo eletrico simplificado (regime
% permanente por fase equivalente):
%   I = tau_motor/Kt ;  V_emf = Ke*omega_motor ;  V ~ Ke*w + R*I

Nref = Nred_options(idx_reducao_referencia,:)';

% Requisitos no motor para o pior caso global (com FS ja aplicados)
tau_motor_peak_wc = FS_tau_peak * WC.TorquePicoGlobal_Nm ./ (eta_red .* Nref);
tau_motor_rms_wc  = FS_tau_rms  * WC.TorqueRMSGlobal_Nm  ./ (eta_red .* Nref);
% (VelocidadeMotorMax_rpm ja varreu todas as reducoes; para a checagem
%  com o motor candidato, recalcula-se na reducao de referencia:)
omega_peak_wc = zeros(nJ,1);
for jj = 1:nJ
    Swc = Scen{scen_critico(jj,1), scen_critico(jj,2), scen_critico(jj,3)};
    omega_peak_wc(jj) = Swc.omega_peak_junta(jj);
end
rpm_motor_ref_req = FS_vel * Nref .* omega_peak_wc * 60/(2*pi);

if avaliar_motor_candidato
    I_peak_req = tau_motor_peak_wc ./ Kt;            % [A]
    I_rms_req  = tau_motor_rms_wc  ./ Kt;            % [A]
    omega_motor_ref = Nref .* omega_peak_wc;         % [rad/s]
    V_emf_peak      = Ke .* omega_motor_ref;         % [V]
    V_resistiva_peak= Rmotor .* I_peak_req;          % [V]
    V_motor_est     = V_emf_peak + V_resistiva_peak; % [V] estimativa

    fprintf('\n============================================================\n');
    fprintf('MOTOR CANDIDATO (reducao de referencia = opcao %d)\n', ...
            idx_reducao_referencia);
    fprintf('============================================================\n');
    for jj = 1:nJ
        fprintf(['Junta %d: I_pico_req = %6.2f A | I_rms_req = %6.2f A | ', ...
                 'V_est = %6.1f V\n'], free_idx(jj), I_peak_req(jj), ...
                 I_rms_req(jj), V_motor_est(jj));
    end

    % Verificacoes motor/drive (req. 18)
    check_aviso(all(V_motor_est < V_bus | ~isfinite(V_bus)), ...
        'OK: tensao estimada abaixo de V_bus em todas as juntas.', ...
        'ATENCAO: tensao estimada >= V_bus em alguma junta (falta margem de campo/PWM).');
    check_aviso(all(I_rms_req <= I_cont_motor | ~isfinite(I_cont_motor)), ...
        'OK: corrente RMS <= corrente continua do motor.', ...
        'ATENCAO: corrente RMS acima da corrente continua do motor.');
    check_aviso(all(I_peak_req <= I_peak_motor | ~isfinite(I_peak_motor)), ...
        'OK: corrente de pico <= corrente de pico do motor.', ...
        'ATENCAO: corrente de pico acima do limite do motor.');
    check_aviso(all(rpm_motor_ref_req <= rpm_max_motor | ~isfinite(rpm_max_motor)), ...
        'OK: velocidade requerida <= velocidade maxima do motor.', ...
        'ATENCAO: velocidade requerida acima da maxima do motor.');
    check_aviso(all(tau_motor_rms_wc <= tau_cont_motor | ~isfinite(tau_cont_motor)), ...
        'OK: torque RMS <= torque continuo do motor.', ...
        'ATENCAO: torque RMS acima do torque continuo do motor.');
    check_aviso(all(tau_motor_peak_wc <= tau_peak_motor | ~isfinite(tau_peak_motor)), ...
        'OK: torque de pico <= torque de pico admissivel do motor.', ...
        'ATENCAO: torque de pico acima do admissivel do motor.');
else
    I_peak_req = nan(nJ,1); I_rms_req = nan(nJ,1);
    V_emf_peak = nan(nJ,1); V_resistiva_peak = nan(nJ,1);
    V_motor_est = nan(nJ,1);
end

% Inercia refletida e razao de inercia (reducao de referencia)
J_junta_max_wc   = zeros(nJ,1);
J_junta_min_wc   =  inf(nJ,1);
J_junta_media_wc = zeros(nJ,1);
for jj = 1:nJ
    Swc = Scen{scen_critico(jj,1), scen_critico(jj,2), scen_critico(jj,3)};
    J_junta_max_wc(jj)   = Swc.J_junta_max(jj);
    J_junta_min_wc(jj)   = Swc.J_junta_min(jj);
    J_junta_media_wc(jj) = Swc.J_junta_media(jj);
end
J_load_ref_max   = J_junta_max_wc   ./ (Nref.^2);
J_load_ref_media = J_junta_media_wc ./ (Nref.^2);

if avaliar_motor_candidato && all(isfinite(J_motor))
    razao_inercia_max   = J_load_ref_max   ./ J_motor;
    razao_inercia_media = J_load_ref_media ./ J_motor;
    J_rotor_junta       = J_motor .* (Nref.^2);   % rotor refletido a junta
    fprintf('\nRazao de inercia (J_load_ref/J_motor):\n');
    for jj = 1:nJ
        fprintf('  Junta %d: max = %6.2f | media = %6.2f\n', ...
                free_idx(jj), razao_inercia_max(jj), razao_inercia_media(jj));
    end
else
    razao_inercia_max = nan(nJ,1); razao_inercia_media = nan(nJ,1);
    J_rotor_junta = nan(nJ,1);
end

%% ============================================================
%  20) MODELO TERMICO DE 1a ORDEM (OPCIONAL)
%% ============================================================

if calcular_modelo_termico
    T_peak_motor   = zeros(nJ,1);
    margem_termica = zeros(nJ,1);
    Termico = cell(nJ,1);
    for jj = 1:nJ
        % cenario de pior torque RMS desta junta (mais severo termicamente)
        [~, idxLin] = max(TabelaCenariosJunta.TorqueRMSJunta_Nm .* ...
                          (TabelaCenariosJunta.Junta == free_idx(jj)));
        iTfw  = find(Tf_list == TabelaCenariosJunta.Tf_s(idxLin), 1);
        iPayw = find(payload_list == TabelaCenariosJunta.Payload_kg(idxLin), 1);
        Sw = get_scen(iTfw, iPayw, idx_reducao_referencia);

        tau_m_t = Sw.hist.Tau_cmd(jj,:) ./ (eta_red(jj)*Nref(jj));  % [N.m]
        I_t     = abs(tau_m_t) ./ Kt(jj);                            % [A]
        P_cu    = (I_t.^2) * Rmotor(jj);                             % [W]
        td      = Sw.hist.t;  dtd = mean(diff(td));

        % repete o ciclo numero_ciclos_termicos vezes (+ pausas)
        n_pausa = round(tempo_pausa_entre_ciclos/dtd);
        P_ciclo = [P_cu, zeros(1, n_pausa)];
        P_seq   = repmat(P_ciclo, 1, numero_ciclos_termicos);
        Tm      = zeros(1, numel(P_seq)); Tm(1) = Tamb;
        for k = 2:numel(P_seq)   % Euler explicito (tau_term >> dtd)
            Tm(k) = Tm(k-1) + dtd*(P_seq(k-1) - (Tm(k-1)-Tamb)/Rth(jj))/Cth(jj);
        end
        T_peak_motor(jj)   = max(Tm);
        margem_termica(jj) = Tmax_motor(jj) - T_peak_motor(jj);
        Termico{jj} = struct('t', (0:numel(Tm)-1)*dtd, 'T', Tm);
        if margem_termica(jj) <= 0
            warning('Junta %d: temperatura estimada excede Tmax do motor.', ...
                    free_idx(jj));
        end
    end
    fprintf('\nModelo termico (perdas de cobre, %d ciclos):\n', ...
            numero_ciclos_termicos);
    for jj = 1:nJ
        fprintf('  Junta %d: T_pico = %6.1f C | margem = %6.1f C\n', ...
                free_idx(jj), T_peak_motor(jj), margem_termica(jj));
    end
else
    T_peak_motor = nan(nJ,1); margem_termica = nan(nJ,1); Termico = {};
end

%% ============================================================
%  21) EXPORTACAO (CSV + MAT)
%% ============================================================

writetable(TabelaCenariosJunta,  fullfile(outDir, 'TabelaCenariosJunta.csv'));
writetable(TabelaRequisitosMotor,fullfile(outDir, 'TabelaRequisitosMotor.csv'));
writetable(TabelaPiorCasoJunta,  fullfile(outDir, 'TabelaPiorCasoJunta.csv'));

Dados = struct();
Dados.TabelaCenariosJunta   = TabelaCenariosJunta;
Dados.TabelaRequisitosMotor = TabelaRequisitosMotor;
Dados.TabelaPiorCasoJunta   = TabelaPiorCasoJunta;
Dados.parametros = struct('params',params,'q0',q0,'p_des',p_des, ...
    'q_goal',q_goal,'free_idx',free_idx,'fixed_idx',fixed_idx, ...
    'Kp',Kp,'Kd',Kd,'wn',wn,'zeta',zeta,'tau_max',tau_max,'dt',dt, ...
    'usar_coriolis',usar_coriolis,'modo_rapido',modo_rapido, ...
    'controlador_compensa_carga',controlador_compensa_carga, ...
    'dados_inerciais_completos',dados_inerciais_completos);
Dados.cenarios = struct('Tf_list',Tf_list,'payload_list',payload_list, ...
    'Nred_options',Nred_options,'eta_red',eta_red, ...
    'idx_reducao_referencia',idx_reducao_referencia);
Dados.fatores_seguranca = struct('FS_tau_peak',FS_tau_peak, ...
    'FS_tau_rms',FS_tau_rms,'FS_vel',FS_vel,'FS_acc',FS_acc, ...
    'FS_pot',FS_pot,'FS_freio',FS_freio);
Dados.historico_cenarios = Scen;       % historicos decimados + metricas
Dados.pior_caso = WC;
Dados.q_critico_global = q_critico_global;
Dados.scen_critico = scen_critico;
Dados.motor_candidato = struct('avaliar',avaliar_motor_candidato, ...
    'Kt',Kt,'Ke',Ke,'Rmotor',Rmotor,'I_cont_motor',I_cont_motor, ...
    'I_peak_motor',I_peak_motor,'V_bus',V_bus,'J_motor',J_motor, ...
    'rpm_nom_motor',rpm_nom_motor,'rpm_max_motor',rpm_max_motor, ...
    'tau_cont_motor',tau_cont_motor,'tau_peak_motor',tau_peak_motor, ...
    'P_nom_motor',P_nom_motor, ...
    'I_peak_req',I_peak_req,'I_rms_req',I_rms_req, ...
    'V_emf_peak',V_emf_peak,'V_resistiva_peak',V_resistiva_peak, ...
    'V_motor_est',V_motor_est, ...
    'razao_inercia_max',razao_inercia_max, ...
    'razao_inercia_media',razao_inercia_media, ...
    'J_rotor_junta',J_rotor_junta, ...
    'T_peak_motor',T_peak_motor,'margem_termica',margem_termica);
Dados.opcoes = struct('incluir_atrito',incluir_atrito,'Bv',Bv,'Fc',Fc, ...
    'vel_suavizacao',vel_suavizacao, ...
    'incluir_inercia_rotor_na_planta',incluir_inercia_rotor_na_planta, ...
    'calcular_potencia_eletrica',calcular_potencia_eletrica, ...
    'eta_motor',eta_motor,'eta_regen',eta_regen, ...
    'calcular_modelo_termico',calcular_modelo_termico, ...
    'avaliar_parada_emergencia',avaliar_parada_emergencia, ...
    'tempo_parada_emergencia',tempo_parada_emergencia);

save(fullfile(outDir, 'resultados_dimensionamento.mat'), 'Dados', '-v7.3');
fprintf('\nTabelas CSV e resultados_dimensionamento.mat salvos em: %s\n', outDir);

%% ============================================================
%  22) GRAFICOS (A ate J) - salvos em PNG e EPS
%% ============================================================
%
% Os graficos A-G usam, para cada junta, o CENARIO CRITICO daquela
% junta (maior torque de pico global); o titulo de cada painel indica
% Tf e payload do cenario. H compara reducoes; I compara tempos de
% trajetoria (payload fixo no maximo); J compara payloads (Tf fixo no
% minimo).

if nJ <= 2, nLin = nJ; nCol = 1; else, nLin = 2; nCol = ceil(nJ/2); end
corLim = [0.85 0.1 0.1];

% ---------- Grafico A: torque x tempo (cenario critico) ----------
figA = figure('Color','w','Name','A - Torque x tempo');
tiledlayout(nLin,nCol,'TileSpacing','compact','Padding','compact');
for jj = 1:nJ
    S = Scen{scen_critico(jj,1),scen_critico(jj,2),scen_critico(jj,3)};
    nexttile; hold on; grid on;
    plot(S.hist.t, S.hist.Tau_cmd(jj,:), 'b-', 'LineWidth', 1.3);
    yline( S.tau_rms_junta(jj), 'g-.', 'RMS', 'LineWidth', 1.2);
    yline(-S.tau_rms_junta(jj), 'g-.', 'HandleVisibility','off');
    yline( tau_max(jj), '--', 'Color', corLim, 'LineWidth', 1.2);
    yline(-tau_max(jj), '--', 'Color', corLim, 'HandleVisibility','off');
    plot(S.t_tau_peak(jj), S.tau_no_pico(jj), 'rp', ...
         'MarkerSize', 11, 'MarkerFaceColor','r');
    xline(S.Tf, 'k:', 'Carga', 'HandleVisibility','off');
    xlabel('Tempo [s]'); ylabel(sprintf('\\tau_%d [N.m]', free_idx(jj)));
    title(sprintf('J%d | Tf=%.1fs, payload=%.0fkg', ...
          free_idx(jj), S.Tf, S.payload));
end
save_fig(figA, imgDir, 'A_torque_tempo');

% ---------- Grafico B: torque x velocidade na JUNTA ----------
figB = figure('Color','w','Name','B - Torque x velocidade (junta)');
tiledlayout(nLin,nCol,'TileSpacing','compact','Padding','compact');
for jj = 1:nJ
    S = Scen{scen_critico(jj,1),scen_critico(jj,2),scen_critico(jj,3)};
    nexttile; hold on; grid on;
    plot(abs(S.hist.dq_free(jj,:)), abs(S.hist.Tau_cmd(jj,:)), ...
         'b.', 'MarkerSize', 4);
    xlabel(sprintf('|\\omega_%d| [rad/s]', free_idx(jj)));
    ylabel(sprintf('|\\tau_%d| [N.m]', free_idx(jj)));
    title(sprintf('Junta %d (plano torque-velocidade)', free_idx(jj)));
end
save_fig(figB, imgDir, 'B_torque_vs_vel_junta');

% ---------- Grafico C: torque x velocidade no MOTOR ----------
figC = figure('Color','w','Name','C - Torque x velocidade (motor)');
tiledlayout(nLin,nCol,'TileSpacing','compact','Padding','compact');
NrefPlot = Nred_options(idx_reducao_referencia,:)';
for jj = 1:nJ
    S = Scen{scen_critico(jj,1),scen_critico(jj,2),scen_critico(jj,3)};
    nexttile; hold on; grid on;
    rpm_m = abs(S.hist.dq_free(jj,:))*NrefPlot(jj)*60/(2*pi);
    tau_m = abs(S.hist.Tau_cmd(jj,:))/(eta_red(jj)*NrefPlot(jj));
    plot(rpm_m, tau_m, 'b.', 'MarkerSize', 4);
    if avaliar_motor_candidato
        if isfinite(tau_cont_motor(jj))
            yline(tau_cont_motor(jj), 'g--', '\tau_{cont}', 'LineWidth', 1.2);
        end
        if isfinite(tau_peak_motor(jj))
            yline(tau_peak_motor(jj), 'r--', '\tau_{pico}', 'LineWidth', 1.2);
        end
        if isfinite(rpm_nom_motor(jj))
            xline(rpm_nom_motor(jj), 'g:', 'rpm_{nom}', 'LineWidth', 1.2);
        end
        if isfinite(rpm_max_motor(jj))
            xline(rpm_max_motor(jj), 'r:', 'rpm_{max}', 'LineWidth', 1.2);
        end
    end
    xlabel('rpm do motor'); ylabel('|\tau_{motor}| [N.m]');
    title(sprintf('Junta %d | N=%g, \\eta=%.2f', ...
          free_idx(jj), NrefPlot(jj), eta_red(jj)));
end
save_fig(figC, imgDir, 'C_torque_vs_vel_motor');

% ---------- Grafico D: potencia mecanica ----------
figD = figure('Color','w','Name','D - Potencia mecanica');
tiledlayout(nLin,nCol,'TileSpacing','compact','Padding','compact');
for jj = 1:nJ
    S = Scen{scen_critico(jj,1),scen_critico(jj,2),scen_critico(jj,3)};
    P = S.hist.P_joint(jj,:);
    nexttile; hold on; grid on;
    plot(S.hist.t, max(P,0),  'b-', 'LineWidth', 1.2);
    plot(S.hist.t, -max(-P,0),'r-', 'LineWidth', 1.2);
    plot(S.hist.t, P, 'k:', 'LineWidth', 0.8);
    xline(S.Tf, 'k:', 'Carga', 'HandleVisibility','off');
    xlabel('Tempo [s]'); ylabel(sprintf('P_%d [W]', free_idx(jj)));
    legend({'Motora (+)','Regenerativa (-)','Total'}, 'Location','best');
end
save_fig(figD, imgDir, 'D_potencia_mecanica');

% ---------- Grafico E: energia acumulada ----------
figE = figure('Color','w','Name','E - Energia acumulada');
tiledlayout(nLin,nCol,'TileSpacing','compact','Padding','compact');
for jj = 1:nJ
    S = Scen{scen_critico(jj,1),scen_critico(jj,2),scen_critico(jj,3)};
    P = S.hist.P_joint(jj,:);
    nexttile; hold on; grid on;
    plot(S.hist.t, cumtrapz(S.hist.t, max(P,0)),  'b-', 'LineWidth', 1.4);
    plot(S.hist.t, cumtrapz(S.hist.t, max(-P,0)), 'r-', 'LineWidth', 1.4);
    xline(S.Tf, 'k:', 'Carga', 'HandleVisibility','off');
    xlabel('Tempo [s]'); ylabel(sprintf('E_%d [J]', free_idx(jj)));
    legend({'Motora acumulada','Regenerativa acumulada'}, 'Location','best');
end
save_fig(figE, imgDir, 'E_energia_acumulada');

% ---------- Grafico F: decomposicao do torque ----------
figF = figure('Color','w','Name','F - Decomposicao do torque');
tiledlayout(nLin,nCol,'TileSpacing','compact','Padding','compact');
for jj = 1:nJ
    S = Scen{scen_critico(jj,1),scen_critico(jj,2),scen_critico(jj,3)};
    nexttile; hold on; grid on;
    plot(S.hist.t, S.hist.Tau_inercia(jj,:),  'LineWidth', 1.1);
    plot(S.hist.t, S.hist.Tau_coriolis(jj,:), 'LineWidth', 1.1);
    plot(S.hist.t, S.hist.Tau_grav(jj,:),     'LineWidth', 1.1);
    plot(S.hist.t, S.hist.Tau_carga(jj,:),    'LineWidth', 1.1);
    plot(S.hist.t, S.hist.Tau_atrito(jj,:),   'LineWidth', 1.1);
    plot(S.hist.t, S.hist.Tau_feedback(jj,:), 'LineWidth', 1.1);
    xline(S.Tf, 'k:', 'Carga', 'HandleVisibility','off');
    xlabel('Tempo [s]'); ylabel(sprintf('\\tau_%d [N.m]', free_idx(jj)));
    legend({'Inercia (FF)','Coriolis','Gravidade','Carga','Atrito', ...
            'Realimentacao'}, 'Location','best');
end
save_fig(figF, imgDir, 'F_decomposicao_torque');

% ---------- Grafico G: inercia efetiva e refletida ----------
figG = figure('Color','w','Name','G - Inercias');
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
nexttile; hold on; grid on;
bar(categorical("J"+string(free_idx)), ...
    [J_junta_min_wc, J_junta_media_wc, J_junta_max_wc]);
ylabel('Inercia efetiva da junta [kg.m^2]');
legend({'min','media','max'}, 'Location','best');
title('Lado da junta (diag de M_{ff})');
nexttile; hold on; grid on;
if avaliar_motor_candidato && all(isfinite(J_motor))
    bar(categorical("J"+string(free_idx)), ...
        [J_load_ref_media, J_load_ref_max, J_motor]);
    legend({'refletida media','refletida max','rotor J_{motor}'}, ...
           'Location','best');
else
    bar(categorical("J"+string(free_idx)), [J_load_ref_media, J_load_ref_max]);
    legend({'refletida media','refletida max'}, 'Location','best');
end
set(gca,'YScale','log');
ylabel('Inercia no eixo do motor [kg.m^2]');
title(sprintf('Refletida: J_{junta}/N^2 (opcao %d)', idx_reducao_referencia));
save_fig(figG, imgDir, 'G_inercia_refletida');

% ---------- Grafico H: comparacao entre reducoes ----------
figH = figure('Color','w','Name','H - Comparacao entre reducoes');
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
tauH = zeros(nJ,nRed); rpmH = zeros(nJ,nRed);
potH = zeros(nJ,nRed); jH = zeros(nJ,nRed);
for jj = 1:nJ
    Swc = Scen{scen_critico(jj,1),scen_critico(jj,2),scen_critico(jj,3)};
    for r = 1:nRed
        Nv = Nred_options(r,:)';
        tauH(jj,r) = FS_tau_peak*Swc.tau_peak_junta(jj)/(eta_red(jj)*Nv(jj));
        rpmH(jj,r) = FS_vel*Nv(jj)*Swc.omega_peak_junta(jj)*60/(2*pi);
        potH(jj,r) = FS_pot*Swc.P_peak_junta(jj)/eta_red(jj);
        if avaliar_motor_candidato && isfinite(J_motor(jj))
            jH(jj,r) = (Swc.J_junta_max(jj)/Nv(jj)^2)/J_motor(jj);
        else
            jH(jj,r) = Swc.J_junta_max(jj)/Nv(jj)^2;
        end
    end
end
catJ = categorical("J"+string(free_idx));
legRed = compose('Opcao %d', 1:nRed);
nexttile; bar(catJ, tauH); grid on;
ylabel('\tau_{motor,pico,req} [N.m]'); legend(legRed); title('Torque requerido');
nexttile; bar(catJ, rpmH); grid on;
ylabel('rpm_{req}'); legend(legRed); title('Velocidade requerida');
nexttile; bar(catJ, potH); grid on;
ylabel('P_{req} [W]'); legend(legRed); title('Potencia requerida (nao muda com N)');
nexttile; bar(catJ, jH); grid on;
if avaliar_motor_candidato && all(isfinite(J_motor))
    ylabel('J_{ref}/J_{motor} [-]'); title('Razao de inercia');
else
    ylabel('J_{ref} [kg.m^2]'); title('Inercia refletida (sem motor definido)');
end
legend(legRed);
save_fig(figH, imgDir, 'H_comparacao_reducoes');

% ---------- Grafico I: comparacao entre tempos de trajetoria ----------
iPayI = nPay;   % payload fixo no MAIOR valor da lista
figI = figure('Color','w','Name','I - Comparacao entre Tf');
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
mI = zeros(nTf, nJ, 4);
for iTf = 1:nTf
    S = get_scen(iTf, iPayI, 1);
    mI(iTf,:,1) = S.tau_peak_junta;   mI(iTf,:,2) = S.tau_rms_junta;
    mI(iTf,:,3) = S.omega_peak_junta; mI(iTf,:,4) = S.P_peak_junta;
end
tituloI = {'Torque de pico [N.m]','Torque RMS [N.m]', ...
           'Velocidade de pico [rad/s]','Potencia de pico [W]'};
for pp = 1:4
    nexttile; hold on; grid on;
    plot(Tf_list, mI(:,:,pp), '-o', 'LineWidth', 1.4);
    xlabel('Tf [s]'); ylabel(tituloI{pp});
    legend(compose('J%d', free_idx), 'Location','best');
    title(sprintf('%s | payload = %.0f kg', tituloI{pp}, payload_list(iPayI)));
end
save_fig(figI, imgDir, 'I_comparacao_Tf');

% ---------- Grafico J: comparacao entre payloads ----------
iTfJ = 1;   % Tf fixo no MENOR valor da lista (caso dinamicamente pior)
figJ = figure('Color','w','Name','J - Comparacao entre payloads');
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
mJ = zeros(nPay, nJ, 4);
for iPay = 1:nPay
    S = get_scen(iTfJ, iPay, 1);
    mJ(iPay,:,1) = S.tau_peak_junta;   mJ(iPay,:,2) = S.tau_rms_junta;
    mJ(iPay,:,3) = S.omega_peak_junta; mJ(iPay,:,4) = S.P_peak_junta;
end
for pp = 1:4
    nexttile; hold on; grid on;
    plot(payload_list, mJ(:,:,pp), '-s', 'LineWidth', 1.4);
    xlabel('Payload [kg]'); ylabel(tituloI{pp});
    legend(compose('J%d', free_idx), 'Location','best');
    title(sprintf('%s | Tf = %.1f s', tituloI{pp}, Tf_list(iTfJ)));
end
save_fig(figJ, imgDir, 'J_comparacao_payload');

% =============================================================
% GRAFICOS COMPACTOS PARA O RELATORIO
% =============================================================
%
% Usa um unico cenario para todas as juntas:
%   - menor Tf: movimento mais rapido;
%   - maior payload: maior carga adicional.
%
% Isso evita sobrepor curvas provenientes de cenarios diferentes.

[~, iTfCompacto]  = min(Tf_list);
[~, iPayCompacto] = max(payload_list);

Scomp = get_scen(iTfCompacto, iPayCompacto, ...
                 idx_reducao_referencia);

tc          = Scomp.hist.t;
coresJ      = lines(nJ);
rotulosJ    = compose('J%d', free_idx);

%% -------------------------------------------------------------
% GRAFICO K: CINEMATICA SOBREPOSTA
% --------------------------------------------------------------

figK = figure( ...
    'Color','w', ...
    'Name','K - Cinematica sobreposta', ...
    'Position',[100 100 950 750]);

tK = tiledlayout(figK,3,1, ...
    'TileSpacing','compact', ...
    'Padding','compact');

dadosK = {
    Scomp.hist.Q_free
    Scomp.hist.dq_free
    Scomp.hist.ddq_free
};

titulosK = {
    'Posicao articular'
    'Velocidade articular'
    'Aceleracao articular'
};

rotulosYK = {
    'q_i [rad]'
    '\omega_i [rad/s]'
    '\alpha_i [rad/s^2]'
};

for pp = 1:3

    ax = nexttile(tK);
    hold(ax,'on');
    grid(ax,'on');
    box(ax,'on');

    hJ = gobjects(nJ,1);

    for jj = 1:nJ

        % Resultado real
        hJ(jj) = plot(ax,tc,dadosK{pp}(jj,:), ...
            'Color',coresJ(jj,:), ...
            'LineWidth',1.4);

        % Na posicao, mostra tambem a referencia desejada
        if pp == 1
            plot(ax,tc,Scomp.hist.Qd_free(jj,:), ...
                '--', ...
                'Color',coresJ(jj,:), ...
                'LineWidth',0.9, ...
                'HandleVisibility','off');
        end
    end

    % Instante de mudanca entre ida e retorno com carga
    xline(ax,Scomp.Tf,'k:', ...
        'LineWidth',1.0, ...
        'HandleVisibility','off');

    xlabel(ax,'Tempo [s]');
    ylabel(ax,rotulosYK{pp});
    title(ax,titulosK{pp});

    if pp == 1
        legend(ax,hJ,cellstr(rotulosJ), ...
            'Location','best');
        title(ax, ...
            'Posicao: real (continua) e referencia (tracejada)');
    end
end

title(tK,sprintf([ ...
    'Cinematica das juntas - Tf = %.1f s | ', ...
    'carga adicional = %.1f kg'], ...
    Scomp.Tf,Scomp.payload));

save_fig(figK,imgDir,'K_cinematica_sobreposta');


%% -------------------------------------------------------------
% GRAFICO L: DINAMICA E ENERGIA SOBREPOSTAS
% -------------------------------------------------------------

Pcomp = Scomp.hist.P_joint;

% Energia fornecida no modo motor
E_motora = cumtrapz(tc,max(Pcomp,0),2);

% Energia potencialmente regeneravel
E_regen = cumtrapz(tc,max(-Pcomp,0),2);

dadosL = {
    Scomp.hist.Tau_cmd
    Pcomp
    E_motora
    E_regen
};

titulosL = {
    'Torque nas juntas'
    'Potencia mecanica: positiva motora e negativa regenerativa'
    'Energia motora acumulada'
    'Energia regenerativa acumulada'
};

rotulosYL = {
    '\tau_i [N.m]'
    'P_i [W]'
    'E_{mot,i} [J]'
    'E_{reg,i} [J]'
};

figL = figure( ...
    'Color','w', ...
    'Name','L - Dinamica sobreposta', ...
    'Position',[100 100 1050 700]);

tL = tiledlayout(figL,2,2, ...
    'TileSpacing','compact', ...
    'Padding','compact');

for pp = 1:4

    ax = nexttile(tL);
    hold(ax,'on');
    grid(ax,'on');
    box(ax,'on');

    hJ = gobjects(nJ,1);

    for jj = 1:nJ
        hJ(jj) = plot(ax,tc,dadosL{pp}(jj,:), ...
            'Color',coresJ(jj,:), ...
            'LineWidth',1.4);
    end

    xline(ax,Scomp.Tf,'k:', ...
        'LineWidth',1.0, ...
        'HandleVisibility','off');

    xlabel(ax,'Tempo [s]');
    ylabel(ax,rotulosYL{pp});
    title(ax,titulosL{pp});

    % Uma unica legenda, pois as cores sao iguais nos quatro paineis
    if pp == 1
        legend(ax,hJ,cellstr(rotulosJ), ...
            'Location','best');
    end
end

title(tL,sprintf([ ...
    'Desempenho dinamico - Tf = %.1f s | ', ...
    'carga adicional = %.1f kg'], ...
    Scomp.Tf,Scomp.payload));

save_fig(figL,imgDir,'L_dinamica_sobreposta');

fprintf('Figuras PNG e EPS salvas em: %s\n', imgDir);

%% ============================================================
%  23) VERIFICACOES FINAIS (req. 18, parte 2)
%% ============================================================

fprintf('\n============================================================\n');
fprintf('VERIFICACOES FINAIS\n');
fprintf('============================================================\n');

houve_alerta = false;
for iTf = 1:nTf
  for iPay = 1:nPay
    for iRs = 1:nRedSim
      S = Scen{iTf,iPay,iRs};
      tag = sprintf('Tf=%.1fs, payload=%.0fkg', S.Tf, S.payload);

      % dimensoes ja garantidas por assert dentro de simular_cenario
      if S.tem_nan_inf
          warning('NaN/Inf detectado no cenario %s.', tag);
          houve_alerta = true;
      end
      if S.max_sym_err >= 1e-9
          warning('Mff assimetrica (%.2e) no cenario %s.', S.max_sym_err, tag);
          houve_alerta = true;
      end
      if S.min_eig_Mff <= 0
          warning('Mff nao definida positiva no cenario %s.', tag);
          houve_alerta = true;
      end
      if S.desvio_fixas_q >= 1e-12 || S.desvio_fixas_dq >= 1e-12
          warning('Juntas travadas com desvio no cenario %s.', tag);
          houve_alerta = true;
      end
      if ~S.ref_continua
          % salto de referencia incompativel com dt => descontinuidade
          warning('Trajetoria de referencia descontinua no cenario %s.', tag);
          houve_alerta = true;
      end
      if S.max_vel_extremos > 1e-9 || S.max_acc_extremos > 1e-9
          warning('Velocidade/aceleracao nao nulas nos extremos (%s).', tag);
          houve_alerta = true;
      end
      idxSat = find(S.percentual_saturado > percentual_saturacao_max_admissivel);
      for jj = idxSat(:).'
          warning(['Junta %d saturou %.2f%% do tempo no cenario %s ', ...
                   '(tolerancia: %.2f%%). Reveja tau_max/reducao/Tf.'], ...
                  free_idx(jj), S.percentual_saturado(jj), tag, ...
                  percentual_saturacao_max_admissivel);
          houve_alerta = true;
      end
    end
  end
end
if ~houve_alerta
    fprintf('OK: todas as verificacoes numericas passaram em todos os cenarios.\n');
end
fprintf(['Lembretes: tau_max e PROVISORIO; tensores de inercia dos elos ', ...
         'INCOMPLETOS;\nfatores de seguranca sao parametros de projeto ', ...
         'configuraveis.\n']);

fprintf('\nTempo total de execucao: %.1f s\n', toc(t_execucao_total));

%% ============================================================
%  FUNCOES LOCAIS
%% ============================================================

function S = simular_cenario(q0, q_goal, Tf, m_pay2, cfg, params)
% Simula UM cenario (Tf, payload de retorno) em malha fechada com o
% controle PD por torque calculado original e devolve metricas de
% dimensionamento + historicos decimados.
%
% Fase 1 (0..Tf):    q0 -> q_goal, SEM carga.
% Fase 2 (Tf..2Tf):  q_goal -> q0, COM carga m_pay2 no TCP.

    fi = cfg.free_idx;  nJ = numel(fi);
    fx = setdiff(1:params.n, fi);
    dt = cfg.dt;  Kp = cfg.Kp;  Kd = cfg.Kd;

    % ---- referencia quintica de duas fases (amostrada no grid de dt) ----
    Nfase = round(Tf/dt) + 1;
    tl = linspace(0, Tf, Nfase);
    [Q1, dQ1, ddQ1] = traj_quintica(q0,     q_goal, tl, Tf);
    [Q2, dQ2, ddQ2] = traj_quintica(q_goal, q0,     tl, Tf);

    t   = [tl, Tf + tl(2:end)];
    Qd  = [Q1,   Q2(:,2:end)];
    dQd = [dQ1,  dQ2(:,2:end)];
    ddQd= [ddQ1, ddQ2(:,2:end)];
    phase_id = [ones(1,Nfase), 2*ones(1,Nfase-1)];

    Qd(fx,:)  = repmat(q0(fx), 1, size(Qd,2));
    dQd(fx,:) = 0;  ddQd(fx,:) = 0;
    N = length(t);

    % checagens da referencia (continuidade e extremos)
    max_salto_ref    = max(max(abs(diff(Qd,1,2))));
    max_vel_extremos = max(abs([dQd(fi,1); dQd(fi,end)]));
    max_acc_extremos = max(abs([ddQd(fi,1); ddQd(fi,end)]));
    ref_continua     = max_salto_ref <= max(abs(dQd(:)))*dt*1.5 + 1e-9;

    % ---- pre-alocacao ----
    Qreal = zeros(6,N);  dQreal = zeros(6,N);  ddQreal = zeros(6,N);
    Tau_cmd = zeros(nJ,N);  Tau_unsat = zeros(nJ,N);
    Tau_inercia = zeros(nJ,N);  Tau_coriolis = zeros(nJ,N);
    Tau_grav = zeros(nJ,N);  Tau_carga = zeros(nJ,N);
    Tau_feedback = zeros(nJ,N);  Tau_atrito = zeros(nJ,N);
    Gp_hist = zeros(nJ,N);      % gravidade da carga (p/ freio)
    J_hist  = zeros(nJ,N);      % inercia efetiva: diag(Mff_tot)
    sat_flag = false(nJ,N);

    nVer = ceil(N/cfg.verif_stride);
    sym_err = zeros(1,nVer);  min_eig = zeros(1,nVer);  vcount = 0;

    q = q0;  dq = zeros(6,1);

    for k = 1:N
        q(fx) = q0(fx);  dq(fx) = 0;

        if phase_id(k) == 2, m_pay = m_pay2; else, m_pay = 0; end

        % modelo completo avaliado no estado medido
        [Mff_tot, hf_tot, Gf_tot, tau_atr, comp] = ...
            modelo_reduzido(q, dq, params, cfg, m_pay);

        % ----- lei de controle PD por torque calculado (PRESERVADA) -----
        e_f  = Qd(fi,k)  - q(fi);
        ed_f = dQd(fi,k) - dq(fi);
        v    = ddQd(fi,k) + Kd*ed_f + Kp*e_f;

        if cfg.controlador_compensa_carga
            Mff_ctrl = Mff_tot;  hf_ctrl = hf_tot;  Gf_ctrl = Gf_tot;
        else
            Mff_ctrl = comp.M_rob(fi,fi) + diag(cfg.J_rotor_add);
            hf_ctrl  = comp.h_rob(fi);
            Gf_ctrl  = comp.G_rob(fi);
        end
        % Obs.: o atrito (se habilitado) NAO e compensado - e perturbacao.
        tau_f = Mff_ctrl*v + hf_ctrl + Gf_ctrl;

        % ----- decomposicao para analise -----
        ddqd_f = ddQd(fi,k);
        Tau_inercia(:,k)  = comp.M_rob(fi,fi)*ddqd_f;
        Tau_coriolis(:,k) = comp.h_rob(fi);
        Tau_grav(:,k)     = comp.G_rob(fi);
        Gp_hist(:,k)      = comp.Gp(fi);
        if cfg.controlador_compensa_carga
            Tau_carga(:,k) = comp.Mp(fi,fi)*ddqd_f + comp.hp(fi) + comp.Gp(fi);
        end
        Tau_feedback(:,k) = Mff_ctrl*(Kd*ed_f + Kp*e_f);
        Tau_atrito(:,k)   = tau_atr;

        % ----- saturacao -----
        Tau_unsat(:,k) = tau_f;
        tau_cmd = min(max(tau_f, -cfg.tau_max), cfg.tau_max);
        sat_flag(:,k) = (abs(tau_f) > cfg.tau_max);
        Tau_cmd(:,k) = tau_cmd;

        % ----- planta: aceleracao real (sem inv, com \) -----
        ddq_f = Mff_tot \ (tau_cmd - hf_tot - Gf_tot - tau_atr);

        Qreal(:,k) = q;  dQreal(:,k) = dq;
        ddQreal(fi,k) = ddq_f;  ddQreal(fx,k) = 0;
        J_hist(:,k) = diag(Mff_tot);

        % verificacoes amostradas de Mff
        if mod(k-1, cfg.verif_stride) == 0
            vcount = vcount + 1;
            sym_err(vcount) = norm(Mff_tot - Mff_tot.', 'fro');
            min_eig(vcount) = min(eig(0.5*(Mff_tot + Mff_tot.')));
        end

        % ----- integracao RK4 com ZOH no torque -----
        if k < N
            y = [q(fi); dq(fi)];
            k1 = rhs_reduzida(y,             tau_cmd, q0, params, cfg, m_pay, ddq_f);
            k2 = rhs_reduzida(y + 0.5*dt*k1, tau_cmd, q0, params, cfg, m_pay, []);
            k3 = rhs_reduzida(y + 0.5*dt*k2, tau_cmd, q0, params, cfg, m_pay, []);
            k4 = rhs_reduzida(y + dt*k3,     tau_cmd, q0, params, cfg, m_pay, []);
            y = y + (dt/6)*(k1 + 2*k2 + 2*k3 + k4);
            q(fi)  = y(1:nJ);
            dq(fi) = y(nJ+1:end);
        end
    end

    % ================= METRICAS (resolucao cheia) =================
    Ttot = t(end) - t(1);
    dq_f  = dQreal(fi,:);
    ddq_f = ddQreal(fi,:);

    [S.tau_peak_junta, idx_tau_peak] = max(abs(Tau_cmd), [], 2);
    S.tau_rms_junta = sqrt(trapz(t, Tau_cmd.^2, 2)/Ttot);
    S.idx_tau_peak = idx_tau_peak;
    S.t_tau_peak   = t(idx_tau_peak).';
    S.tau_no_pico  = Tau_cmd(sub2ind(size(Tau_cmd), (1:nJ).', idx_tau_peak));

    S.tau_grav_peak     = max(abs(Tau_grav), [], 2);       % robo (decomposicao)
    S.tau_inercia_peak  = max(abs(Tau_inercia), [], 2);
    S.tau_carga_peak    = max(abs(Tau_carga), [], 2);
    S.tau_coriolis_peak = max(abs(Tau_coriolis), [], 2);
    S.tau_feedback_peak = max(abs(Tau_feedback), [], 2);
    S.tau_atrito_peak   = max(abs(Tau_atrito), [], 2);

    % gravidade de RETENCAO (robo + carga) -> dimensionamento do freio
    grav_tot = Tau_grav + Gp_hist;
    [S.tau_grav_hold_peak, idx_grav] = max(abs(grav_tot), [], 2);
    S.t_grav_peak = t(idx_grav).';

    [S.omega_peak_junta, idx_om] = max(abs(dq_f), [], 2);
    S.idx_omega_peak = idx_om;
    S.t_omega_peak = t(idx_om).';
    S.alpha_peak_junta = max(abs(ddq_f), [], 2);

    P_joint = Tau_cmd .* dq_f;
    P_pos = max(P_joint, 0);
    P_neg = max(-P_joint, 0);
    S.P_peak_junta = max(abs(P_joint), [], 2);
    [S.P_motora_peak, idx_pm] = max(P_pos, [], 2);
    [S.P_regen_peak,  idx_pr] = max(P_neg, [], 2);
    S.t_P_motora_peak = t(idx_pm).';
    S.t_P_regen_peak  = t(idx_pr).';
    S.P_media_abs = trapz(t, abs(P_joint), 2)/Ttot;
    S.P_rms = sqrt(trapz(t, P_joint.^2, 2)/Ttot);
    S.E_motora       = trapz(t, P_pos, 2);
    S.E_regenerativa = trapz(t, P_neg, 2);
    S.E_total_junta  = trapz(t, abs(P_joint), 2);

    S.tempo_saturado = sum(sat_flag, 2)*dt;
    S.percentual_saturado = 100*S.tempo_saturado/Ttot;

    E_junta = Qd(fi,:) - Qreal(fi,:);
    S.erro_max_junta   = max(abs(E_junta), [], 2);
    S.erro_rms_junta   = sqrt(mean(E_junta.^2, 2));
    S.erro_final_junta = abs(E_junta(:,end));

    S.J_junta_max   = max(J_hist, [], 2);
    S.J_junta_min   = min(J_hist, [], 2);
    S.J_junta_media = mean(J_hist, 2);

    % configuracao completa do robo nos instantes criticos
    S.q_tau_peak   = Qreal(:, idx_tau_peak);    % 6 x nJ
    S.dq_tau_peak  = dQreal(:, idx_tau_peak);
    S.ddq_tau_peak = ddQreal(:, idx_tau_peak);
    S.payload_tau_peak = (phase_id(idx_tau_peak).' == 2)*m_pay2;
    S.Tf_tau_peak = Tf*ones(nJ,1);
    S.q_critico = S.q_tau_peak;                 % alias requerido

    % ----- parada de emergencia simplificada -----
    if cfg.avaliar_emerg
        TauE = zeros(nJ, nJ);
        for jj = 1:nJ
            kke = idx_om(jj);
            qe  = Qreal(:,kke);  dqe = dQreal(:,kke);
            if phase_id(kke) == 2, m_e = m_pay2; else, m_e = 0; end
            [Mffe, hfe, Gfe, tatr_e] = modelo_reduzida_wrap(qe, dqe, params, cfg, m_e);
            ddq_e = -dqe(fi)/cfg.tp_emerg;
            TauE(:,jj) = Mffe*ddq_e + hfe + Gfe + tatr_e;
        end
        S.tau_emergencia = diag(TauE);              % junta no seu instante
        S.tau_emergencia_peak = max(abs(TauE), [], 2);
    else
        S.tau_emergencia = nan(nJ,1);
        S.tau_emergencia_peak = nan(nJ,1);
    end

    % ----- verificacoes internas -----
    assert(isequal(size(Qd), [6 N]) && isequal(size(Qreal), [6 N]), ...
        'Dimensoes de referencia/estado incompativeis.');
    assert(isequal(size(Tau_cmd), [nJ N]), 'Dimensao de Tau_cmd incompativel.');
    S.tem_nan_inf = ~all(isfinite(Qreal(:))) || ~all(isfinite(dQreal(:))) || ...
                    ~all(isfinite(Tau_cmd(:)));
    S.max_sym_err = max(sym_err(1:vcount));
    S.min_eig_Mff = min(min_eig(1:vcount));
    S.desvio_fixas_q  = max(max(abs(Qreal(fx,:) - repmat(q0(fx),1,N))));
    S.desvio_fixas_dq = max(max(abs(dQreal(fx,:))));
    S.max_salto_ref = max_salto_ref;
    S.ref_continua = ref_continua;
    S.max_vel_extremos = max_vel_extremos;
    S.max_acc_extremos = max_acc_extremos;

    % ----- historicos decimados (para graficos, termico e MAT) -----
    stride = max(1, ceil(N/cfg.store_max_pontos));
    id = unique([1:stride:N, N]);
    S.hist.t = t(id);
    S.hist.Tau_cmd      = Tau_cmd(:,id);
    S.hist.Tau_unsat    = Tau_unsat(:,id);
    S.hist.Tau_inercia  = Tau_inercia(:,id);
    S.hist.Tau_coriolis = Tau_coriolis(:,id);
    S.hist.Tau_grav     = Tau_grav(:,id);
    S.hist.Tau_carga    = Tau_carga(:,id);
    S.hist.Tau_feedback = Tau_feedback(:,id);
    S.hist.Tau_atrito   = Tau_atrito(:,id);
    S.hist.dq_free  = dq_f(:,id);
    S.hist.ddq_free = ddq_f(:,id);
    S.hist.P_joint  = P_joint(:,id);
    S.hist.J_junta  = J_hist(:,id);
    S.hist.Q_free   = Qreal(fi,id);
    S.hist.Qd_free  = Qd(fi,id);
    S.hist.sat_flag = sat_flag(:,id);
end

function [Mff, hf, Gf, tau_atr] = modelo_reduzida_wrap(q, dq, params, cfg, m_pay)
% Interface enxuta de modelo_reduzido para reavaliacoes pontuais.
    [Mff, hf, Gf, tau_atr] = modelo_reduzido(q, dq, params, cfg, m_pay);
end

function [Mff_tot, hf_tot, Gf_tot, tau_atr, comp] = ...
                          modelo_reduzido(q, dq, params, cfg, m_pay)
% Modelo dinamico total (robo + carga + rotor opcional) reduzido as
% juntas livres, mais o torque de atrito da planta (opcional).
% Evita repeticao de codigo entre controlador, planta e pos-analise.

    fi = cfg.free_idx;

    M_rob = mass_matrix_numeric(q, params);
    G_rob = gravity_torque_required_numeric(q, params, cfg.gval);
    if cfg.usar_coriolis
        h_rob = coriolis_vector_numeric(q, dq, params);
    else
        h_rob = zeros(params.n, 1);
    end

    [Mp, hp, Gp] = payload_terms(q, dq, params, m_pay, cfg.gval);

    Mff_tot = M_rob(fi,fi) + Mp(fi,fi) + diag(cfg.J_rotor_add);
    hf_tot  = h_rob(fi) + hp(fi);
    Gf_tot  = G_rob(fi) + Gp(fi);

    if cfg.incluir_atrito
        tau_atr = cfg.Bv.*dq(fi) + cfg.Fc.*tanh(dq(fi)/cfg.vel_suav);
    else
        tau_atr = zeros(numel(fi), 1);
    end

    if nargout > 4
        comp = struct('M_rob',M_rob,'h_rob',h_rob,'G_rob',G_rob, ...
                      'Mp',Mp,'hp',hp,'Gp',Gp);
    end
end

function dydt = rhs_reduzida(y, tau_f, q0, params, cfg, m_pay, ddq_f_pronto)
% Derivada do estado reduzido y = [q_f; dq_f] para o RK4.
% ddq_f_pronto: reaproveita a aceleracao do estagio 1 (ja calculada
% pelo controlador) para nao repetir a dinamica.

    fi = cfg.free_idx;  nJ = numel(fi);
    fx = setdiff(1:params.n, fi);

    q = q0;  q(fi) = y(1:nJ);  q(fx) = q0(fx);
    dq = zeros(params.n,1);  dq(fi) = y(nJ+1:end);

    if ~isempty(ddq_f_pronto)
        ddq_f = ddq_f_pronto;
    else
        [Mff, hf, Gf, tau_atr] = modelo_reduzido(q, dq, params, cfg, m_pay);
        ddq_f = Mff \ (tau_f - hf - Gf - tau_atr);
    end

    dydt = [dq(fi); ddq_f];
end

function [Mp, hp, Gp] = payload_terms(q, dq, params, m_pay, gval)
% Carga pontual m_pay no TCP decomposta em inercia (Mp),
% Coriolis/centrifuga (hp) e gravidade (Gp), evitando dupla
% contabilizacao (ver arquivo original):
%   tau_payload = Mp*ddq + hp + Gp = Jv'*m*(a_tcp - grav0)

    n = params.n;
    Mp = zeros(n,n);  hp = zeros(n,1);  Gp = zeros(n,1);
    if m_pay <= 0, return; end

    [T0, ~] = fkine_ur5e(q, params);
    Jv = jacobiana_posicao(T0);

    if norm(dq) > 0
        delta = 1e-6;
        [T0p, ~] = fkine_ur5e(q + delta*dq, params);
        [T0m, ~] = fkine_ur5e(q - delta*dq, params);
        Jdot = (jacobiana_posicao(T0p) - jacobiana_posicao(T0m))/(2*delta);
        Jdot_dq = Jdot*dq;
    else
        Jdot_dq = zeros(3,1);
    end

    Mp = m_pay*(Jv.'*Jv);
    hp = m_pay*(Jv.'*Jdot_dq);
    Gp = Jv.'*[0; 0; m_pay*gval];
end

function [q_goal, info] = ik_reduzida(q0, p_des, free_idx, params)
% Cinematica inversa por DLS nas 4 juntas livres, com resolucao de
% redundancia no espaco nulo puxando para q0 (identica ao original).

    maxIter = 1000;  tol_abs = 1e-5;  lambda = 1e-2;
    ganho = 0.8;  maxStep = 0.08;
    usar_espaco_nulo = true;  k_null = 0.05;

    fixed_idx = setdiff(1:params.n, free_idx);
    nJ = numel(free_idx);
    q = q0;

    for k = 1:maxIter
        q(fixed_idx) = q0(fixed_idx);
        [T0, T_ee] = fkine_ur5e(q, params);
        erro = p_des - T_ee(1:3,4);
        if norm(erro) < tol_abs, break; end

        Jv = jacobiana_posicao(T0);
        J_free = Jv(:,free_idx);
        A_dls = J_free.'*J_free + lambda^2*eye(nJ);
        dq_free = ganho*(A_dls \ (J_free.'*erro));

        if usar_espaco_nulo
            J_pinv_dls = A_dls \ J_free.';
            Nproj = eye(nJ) - J_pinv_dls*J_free;
            dq_free = dq_free + Nproj*(k_null*(q0(free_idx) - q(free_idx)));
        end
        if norm(dq_free) > maxStep
            dq_free = maxStep*dq_free/norm(dq_free);
        end
        q(free_idx) = q(free_idx) + dq_free;
        q = wrapToPi_local(q);
    end

    q_goal = q;  q_goal(fixed_idx) = q0(fixed_idx);
    [~, T_goal] = fkine_ur5e(q_goal, params);
    info.p_final  = T_goal(1:3,4);
    info.erro_abs = norm(p_des - info.p_final);
    info.iters    = k;
end

function [Q, Qdot, Qddot] = traj_quintica(qi, qf, t_local, Tf)
% Polinomio quintico com velocidade e aceleracao nulas nos extremos.
    tau = t_local/Tf;
    s   = 10*tau.^3 - 15*tau.^4 + 6*tau.^5;
    ds  = 30*tau.^2 - 60*tau.^3 + 30*tau.^4;
    dds = 60*tau - 180*tau.^2 + 120*tau.^3;

    n = length(qi);  N = length(t_local);
    Q = zeros(n,N);  Qdot = zeros(n,N);  Qddot = zeros(n,N);
    delta_q = qf - qi;
    for i = 1:N
        Q(:,i)     = qi + s(i)*delta_q;
        Qdot(:,i)  = (ds(i)/Tf)*delta_q;
        Qddot(:,i) = (dds(i)/Tf^2)*delta_q;
    end
end

function [T0, T_ee] = fkine_ur5e(q, params)
    n = params.n;
    T0 = cell(n+1,1);  T0{1} = eye(4);
    for i = 1:n
        T0{i+1} = T0{i} * dh_standard_num(params.a(i), params.alpha(i), ...
                                          params.d(i), q(i));
    end
    T_ee = T0{n+1};
end

function A = dh_standard_num(a, alpha, d, theta)
    A = [ cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta);
          sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta);
          0,           sin(alpha),             cos(alpha),            d;
          0,           0,                      0,                     1 ];
end

function Jv = jacobiana_posicao(T0)
    n = 6;
    p_ee = T0{n+1}(1:3,4);
    Jv = zeros(3,n);
    for j = 1:n
        z = T0{j}(1:3,3);  o = T0{j}(1:3,4);
        Jv(:,j) = cross(z, p_ee - o);
    end
end

function M = mass_matrix_numeric(q, params)
    n = params.n;
    [T0, ~] = fkine_ur5e(q, params);
    M = zeros(n,n);
    for i = 1:n
        Ti = T0{i+1};  Ri = Ti(1:3,1:3);
        pc_h = Ti*[params.pc(:,i); 1];  pc0 = pc_h(1:3);
        Jv = zeros(3,n);  Jw = zeros(3,n);
        for j = 1:i
            z = T0{j}(1:3,3);  o = T0{j}(1:3,4);
            Jv(:,j) = cross(z, pc0 - o);
            Jw(:,j) = z;
        end
        M = M + params.m(i)*(Jv.'*Jv) + Jw.'*Ri*params.Icm(:,:,i)*Ri.'*Jw;
    end
end

function G = gravity_torque_required_numeric(q, params, gval)
% Torque necessario para SUSTENTAR os elos (tau = M*ddq + h + G).
    n = params.n;
    [T0, ~] = fkine_ur5e(q, params);
    G = zeros(n,1);
    for i = 1:n
        Ti = T0{i+1};
        pc_h = Ti*[params.pc(:,i); 1];  pc0 = pc_h(1:3);
        Jv = zeros(3,n);
        for j = 1:i
            z = T0{j}(1:3,3);  o = T0{j}(1:3,4);
            Jv(:,j) = cross(z, pc0 - o);
        end
        G = G + Jv.'*[0; 0; params.m(i)*gval];
    end
end

function h = coriolis_vector_numeric(q, dq, params)
% Simbolos de Christoffel por diferencas centrais sobre M(q).
    n = params.n;  hstep = 1e-6;
    dM = zeros(n,n,n);
    for r = 1:n
        qp = q;  qm = q;
        qp(r) = qp(r) + hstep;  qm(r) = qm(r) - hstep;
        dM(:,:,r) = (mass_matrix_numeric(qp, params) - ...
                     mass_matrix_numeric(qm, params))/(2*hstep);
    end
    h = zeros(n,1);
    for k = 1:n
        soma = 0;
        for s = 1:n
            for r = 1:n
                gamma = 0.5*(dM(k,s,r) + dM(k,r,s) - dM(r,s,k));
                soma = soma + gamma*dq(s)*dq(r);
            end
        end
        h(k) = soma;
    end
end

function q = wrapToPi_local(q)
    q = mod(q + pi, 2*pi) - pi;
end

function check_aviso(cond, msgOK, msgNOK)
% Imprime OK ou gera warning conforme a condicao de verificacao.
    if cond
        fprintf('%s\n', msgOK);
    else
        warning('%s', msgNOK);
    end
end

function save_fig(figHandle, outDir, baseName)
% Salva a figura em PNG (visualizacao rapida) e EPS (publicacao).
    if ~exist(outDir, 'dir'), mkdir(outDir); end
    set(figHandle, 'Color', 'w', 'PaperPositionMode', 'auto', ...
        'InvertHardcopy', 'off');
    print(figHandle, fullfile(outDir, [baseName '.png']), '-dpng', '-r200');
    set(figHandle, 'Renderer', 'painters');
    print(figHandle, fullfile(outDir, [baseName '.eps']), '-depsc', '-painters');
end

# Dimensionamento de bracos a partir de atuadores disponiveis

Este projeto inicia o desenvolvimento do metodo discutido no TCC:
**colecao de acionamentos + tarefa de pick and place de 5 kg -> configuracoes de braco possiveis**.

## O que ja esta implementado

- Copia integral do programa fornecido, em `referencia/`.
- Cinematica DH padrao e dinamica para um numero variavel de juntas rotativas.
- Carga pontual, gravidade com orientacao configuravel e trajetorias quinticas.
- Cinematica inversa de posicao com preservacao das juntas fixas e verificacao de convergencia.
- Calculo dos torques exigidos, torque RMS, velocidade, potencia e energia.
- Execucao curta da referencia UR5 CB3: ida sem carga e retorno com 5 kg.
- Testes contra funcoes extraidas do original, casos analiticos e Robotics System Toolbox.

Esta entrega e a **base numerica verificada**. Ainda nao gera novos bracos, nao possui
catalogo comercial preenchido e nao aprova motores. A execucao de referencia permanece
com os parametros fisicos incompletos recebidos e identifica essa limitacao nos resultados.

## Como executar

No MATLAB, abra esta pasta como pasta atual e execute:

```matlab
iniciar
```

O resultado fica na variavel `resultado` e em `resultados/referencia/`:

- `requisitos_referencia.csv`: requisitos nas juntas ativas.
- `referencia.mat`: parametros, historicos e resultados numericos.
- `status.json`: hipoteses e estado da avaliacao.

Para verificar a base:

```matlab
executar_testes
```

Os testes que usam a implementacao independente requerem Robotics System Toolbox.
O nucleo de calculo e a execucao de referencia usam MATLAB base. A verificacao de
integridade da copia do original utiliza .NET no Windows.

## Diferencas deliberadas em relacao ao programa recebido

1. A matematica foi separada da simulacao de controle, das tabelas e das figuras.
2. O numero de juntas deixou de estar fixado em seis no nucleo generico.
3. Um alvo nao atingido pela IK interrompe a execucao de referencia.
4. Os requisitos vem da dinamica inversa na trajetoria desejada, sem cortar o torque
   por um limite provisorio. Torque aplicado e erro de controle serao avaliados em etapa separada.
5. A referencia e chamada UR5 CB3, de acordo com os parametros presentes no arquivo.
6. A IK nesta etapa verifica posicao, nao orientacao da garra nem colisoes.
   Ela usa DLS sem o objetivo secundario do original; a solucao articular pode diferir.
7. A referencia usa 41 amostras por fase de 2 s para verificacao inicial. Os valores
   nao sao uma reproducao da simulacao RK4 de 1 kHz do original. O controle nao foi portado.
8. As metricas de cada fase sao integradas separadamente; a mudanca de massa entre
   as fases nao e interpolada como uma variacao gradual de carga.

## Proximas etapas do desenvolvimento

1. Definir a nova familia 4R (base, ombro, cotovelo e punho), distinta das quatro
   juntas ativas do UR5 de referencia, e sua convencao de coordenadas.
2. Criar o gerador de geometria e propriedades fisicas: comprimentos variaveis,
   secoes e material definidos, garra e massas/inercia dos acionamentos em seus locais.
3. Definir um ciclo de coleta, elevacao, transporte, deposito e retorno, com pausas.
4. Cadastrar conjuntos motor-redutor-drive com fontes e limites verificaveis.
5. Implementar o avaliador integrado de uma configuracao. Informacoes ausentes
   devem produzir resultado indeterminado, nunca aprovacao implicita.
6. Acrescentar busca pelas dimensoes e distribuicao dos acionamentos, verificacao
   de estrutura e transmissao, refinamento temporal e classificacao das alternativas.
7. Construir a interface depois da verificacao do avaliador e da busca.

## Rastreabilidade

Consulte `ANALISE_DO_ORIGINAL.md` para os pontos de reaproveitamento e as limitacoes
identificadas no arquivo recebido. A copia em `referencia/` e preservada para comparacao.
As funcoes extraidas para testes nao executam a rotina principal nem o controlador.

Documentacao de apoio para a comparacao independente:

- [Dinamica inversa no MATLAB](https://www.mathworks.com/help/robotics/ref/rigidbodytree.inversedynamics.html)
- [Propriedades de corpos rigidos](https://www.mathworks.com/help/robotics/ref/rigidbody.html)
- [Convencao DH no MATLAB](https://www.mathworks.com/help/robotics/ref/rigidbodyjoint.setfixedtransform.html)

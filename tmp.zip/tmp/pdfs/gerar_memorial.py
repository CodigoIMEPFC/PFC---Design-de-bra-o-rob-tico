from pathlib import Path
import json, csv, html, re
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, Image
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'output/pdf'; OUT.mkdir(parents=True,exist_ok=True)
PDF=OUT/'Guia_e_Memorial_de_Calculo_Braco_4R.pdf'
RUN=ROOT/'resultados/projeto_integrado/20260913_163801_796'
FONT=Path('C:/Users/davin/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/share/fonts/DejaVuSans.ttf')
pdfmetrics.registerFont(TTFont('DV',str(FONT)))
pdfmetrics.registerFont(TTFont('ArialB','C:/Windows/Fonts/arialbd.ttf'))
pdfmetrics.registerFont(TTFont('Mono','C:/Windows/Fonts/consola.ttf'))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='ArialB',italic='DV',boldItalic='ArialB')
NAVY=colors.HexColor('#14354B'); TEAL=colors.HexColor('#127A7A'); GRAY=colors.HexColor('#556572')
LIGHT=colors.HexColor('#EEF5F7'); BORDER=colors.HexColor('#D7E4E8')
W,H=A4; WIDTH=W-88
S={
 'body':ParagraphStyle('body',fontName='DV',fontSize=10,leading=14.5,textColor=NAVY,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='DV',fontSize=8.4,leading=11.8,textColor=GRAY,spaceAfter=6),
 'title':ParagraphStyle('title',fontName='ArialB',fontSize=24,leading=29,textColor=NAVY,spaceAfter=14),
 'h2':ParagraphStyle('h2',fontName='ArialB',fontSize=12.2,leading=16,textColor=TEAL,spaceBefore=9,spaceAfter=7),
 'eq':ParagraphStyle('eq',fontName='DV',fontSize=10.2,leading=17,textColor=NAVY),
 'cell':ParagraphStyle('cell',fontName='DV',fontSize=8.7,leading=12,textColor=NAVY),
 'head':ParagraphStyle('head',fontName='ArialB',fontSize=8.7,leading=12,textColor=colors.white),
 'code':ParagraphStyle('code',fontName='Mono',fontSize=9,leading=13,textColor=NAVY),
}
story=[]; eqno=0; page_titles=[]
def para(t,style='body'): return Paragraph(t,S[style])
def P(t,style='body'): story.append(para(t,style))
def H2(t): P(t,'h2')
def page(n,title,sub):
    if story: story.append(PageBreak())
    page_titles.append(title)
    P(f'{n:02d} / {sub.upper()}','small'); P(title,'title')
def table(headers,rows,widths=None):
    dat=[[para(str(x),'head') for x in headers]]+[[para(str(x),'cell') for x in r] for r in rows]
    t=Table(dat,colWidths=widths or [WIDTH/len(headers)]*len(headers),hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,LIGHT]),
        ('LINEBELOW',(0,-1),(-1,-1),.5,BORDER)]))
    story.extend([t,Spacer(1,10)])
def eq(t):
    global eqno
    eqno+=1
    box=Table([[para(t,'eq'),para(f'({eqno})','small')]],colWidths=[WIDTH-36,36])
    box.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('LEFTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
    story.extend([box,Spacer(1,7)])
def code(lines):
    t=Table([[para(html.escape(lines).replace('\n','<br/>'),'code')]],colWidths=[WIDTH])
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.5,BORDER),
        ('LEFTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),10)]))
    story.extend([t,Spacer(1,10)])
def note(t): P('<b>Leitura do resultado.</b> '+t,'small')
def source(t): P('No código: '+t+'<br/>As equações descrevem a implementação [11].','small')
def ref(n,author,title,url,detail=''):
    P(f'<b>[{n}] {author}</b> {title} '+detail,'body')
    if url: P(f'<link href="{html.escape(url,quote=True)}" color="#127A7A">{html.escape(url)}</link>','small')
def matrix(rows):
    dat=[[para(x,'eq') for x in row] for row in rows]
    t=Table(dat,colWidths=[WIDTH/4]*4,hAlign='LEFT')
    t.setStyle(TableStyle([('ALIGN',(0,0),(-1,-1),'CENTER'),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
      ('LINEBEFORE',(0,0),(0,-1),1.4,TEAL),('LINEAFTER',(-1,0),(-1,-1),1.4,TEAL),
      ('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
    story.extend([t,Spacer(1,12)])

page(1,'Braço robótico a partir<br/>de motores disponíveis','Guia de uso e memorial de cálculo')
P('<b>Estudo de pick and place de uma esfera de 5 kg.</b><br/>Versão do programa e resultados conferidos em 13/09/2026.')
P('O programa compara braços com base fixa e quatro juntas, inspiradas em J2-J5 do UR5 CB3. Os motores são a entrada; os comprimentos dos segmentos, as reduções e a viabilidade da tarefa são avaliados pelo programa. A geometria pertence a uma família definida, com dois comprimentos variáveis.')
H2('Como executar')
P('No MATLAB, abra como <b>Pasta atual</b> a pasta <b>dimensionamento_bracos</b> que contém <b>projetar_braco.m</b>. Então execute:')
code('projeto = projetar_braco;\nvisualizar_projeto(projeto);')
P('O primeiro comando executa todas as etapas. O segundo abre a figura de resumo. A execução completa pode levar alguns minutos. Não é necessário executar cada etapa separadamente.')
H2('O que você precisa editar')
table(['Local','O que informar'],[
 ['dados/<br/>cadastro_motores_simplificado.xlsx','Aba Motores, a partir da linha 6: ID, modelo, torque contínuo, massa, inércia do rotor, quantidade e fonte.'],
 ['entrada_projeto.m','Pontos de coleta e depósito, elevação, tempos de ida, comprimentos pesquisados e número de geometrias com controle.'],
 ['hipoteses_construcao.m','Hipóteses de seção dos tubos, massas, centros, altura da base e limites articulares. Manter os valores atuais para reproduzir a apresentação.']
],[190,WIDTH-190])
P('<b>Leitura sugerida:</b> páginas 1-3 para operação e hipóteses; páginas 4-14 para os cálculos; página 15 para os resultados; páginas 16-17 para referências e rastreabilidade.','small')
note('“Qualificado” significa que o candidato passou nos critérios numéricos definidos. Não equivale a um braço fabricado, ensaiado ou validado estruturalmente.')

page(2,'O que faz cada processo','Operação')
table(['Etapa','Função e resultado'],[
 ['1. Cadastro','Lê os motores e verifica unidades, dados válidos e quantidade suficiente. Enumera atribuições de quatro motores respeitando o estoque.'],
 ['2. Geometrias','Combina L1 e L2. No padrão, são 8 × 8 = 64 geometrias. Mantém quatro juntas, base fixa e afastamentos de punho.'],
 ['3. Região de coleta','Amostra pontos no plano do centro da esfera apoiada no piso. Busca posturas e confere sustentação estática. Produz uma área estimada.'],
 ['4. Caminho e estática','Procura um ramo contínuo para elevar, transportar e baixar. Exige sustentação com margem ao longo da rota carregada.'],
 ['5. Dinâmica','Calcula os torques da referência com massas, inércias, acelerações e rotores para cada redução e tempo.'],
 ['6. Seleção','Prioriza maior área, menor tempo, menor utilização de torque e menor massa móvel. Seleciona uma variante por geometria; padrão: três geometrias.'],
 ['7. Controle','Simula PD e MPC com o mesmo braço, motores, caminho e tempo. Testa construção nominal e 20% mais pesada.'],
 ['8. Qualificação','Exige aprovação na triagem e no MPC em todos os cenários solicitados. Salva razões de falha e pendências.']
],[105,WIDTH-105])
H2('Como consultar e salvar a apresentação')
code('projeto.qualificados    % candidatos que passaram\nprojeto.candidatos      % todas as variantes e seus motivos\nprojeto.pasta_saida     % pasta desta execucao')
P('Cada execução recebe uma pasta datada em <b>resultados/projeto_integrado/</b>. Comece por <b>LEIA_RESULTADOS.md</b> e <b>resumo_projeto.png</b>. Os arquivos <b>candidatos.csv</b> e <b>qualificados.csv</b> abrem como tabelas. O arquivo <b>projeto.mat</b> permite reabrir a execução sem recalcular.')
P('Para reabrir: use <b>load</b> no arquivo projeto.mat da execução escolhida e depois <b>visualizar_projeto(projeto)</b>. A planilha utilizada e as entradas também são copiadas para a pasta de resultados.','small')

page(3,'Entradas, hipóteses e unidades','Base do estudo')
table(['Grandeza','Valor utilizado / natureza'],[
 ['Carga e tarefa','Esfera de 5 kg; raio de 0,10 m; orientação livre. Preensão estável idealizada.'],
 ['Motores','4 unidades hipotéticas do Oriental Motor NXM640A. Cada uma: 1,27 N·m, 1,5 kg e J<sub>r</sub> = 2,91 × 10<super>-5</super> kg·m². Dados [2,3]; quantidade assumida.'],
 ['Reduções J1-J4','R1 = [50, 50, 50, 50]; R2 = [80, 80, 60, 60]; R3 = [100, 100, 80, 80]. Cada linha é uma alternativa completa.'],
 ['Rendimento e margem','η = 0,75 por junta; fator F<sub>s</sub> = 1,5 na referência nominal. Escolhas do estudo, sem origem normativa.'],
 ['Segmentos','L1, L2 = 0,15:0,05:0,50 m. Tubo quadrado ideal: lado externo 60 mm e parede 3 mm.'],
 ['Material','Alumínio 6061, ρ = 2700 kg/m³ [4]. A seção dos tubos é hipótese do estudo.'],
 ['Montagem e punhos','Altura H = 0,30 m; d4 = 0,10915 m; d5 = 0,09465 m; d6 = 0,0823 m. Afastamentos de referência UR5 [1].'],
 ['Massas adicionais','Garra 0,50 kg; suporte 0,20 kg/junta; redutor central 1,00 kg/junta. Hipóteses; cenários estáticos alternativos de redutor: 0,50 e 1,50 kg.'],
 ['Ferramenta','Centro da garra a 0,05 m e centro da esfera a 0,15 m da flange, na direção +z local.'],
 ['Tarefa padrão','Coleta (-0,40; -0,18; 0,10) m; depósito (-0,20; -0,05; 0,10) m; elevação 0,15 m. Ida em 2, 4 ou 8 s.']
],[115,WIDTH-115])
H2('Notação usada nas equações')
P('<b>q</b> ∈ R⁴: ângulos, em rad; <b>v = dq/dt</b>: velocidades, em rad/s; <b>a<sub>q</sub> = d²q/dt²</b>: acelerações, em rad/s². <b>τ</b>: torque na junta; <b>u</b>: torque do motor, ambos em N·m. <b>N</b>: relação de redução, adimensional. <b>g</b> = [0, 0, -9,81]<super>T</super> m/s² no mundo.')
P('Os índices i e j identificam juntas ou elos; k identifica componentes ou instantes, conforme indicado. I<sub>n</sub> é a matriz identidade n × n; diag(·) forma uma matriz diagonal. Produtos entre matrizes seguem a álgebra matricial; as expressões com índice i são escalares.','small')

page(4,'Geometria e cinemática direta','Cálculos / posição')
P('Usa-se Denavit-Hartenberg (DH) padrão. Cada transformação leva coordenadas do referencial i para o referencial i-1. A convenção e os afastamentos são compatíveis com as referências [1,10]; os comprimentos principais são variáveis do estudo.')
table(['Junta do modelo','a<sub>i</sub> (m)','d<sub>i</sub> (m)','α<sub>i</sub>','θ<sub>i</sub>'],[
 ['1 (ref. J2)','-L1','0','0','q1'],['2 (ref. J3)','-L2','0','0','q2'],
 ['3 (ref. J4)','0','d4','π/2','q3'],['4 (ref. J5)','0','d5','-π/2','q4']
],[120,90,100,90,WIDTH-400])
eq('A<sub>i</sub> = R<sub>z</sub>(q<sub>i</sub>) T<sub>z</sub>(d<sub>i</sub>) T<sub>x</sub>(a<sub>i</sub>) R<sub>x</sub>(α<sub>i</sub>)')
P('Explicitamente, com c = cos(q<sub>i</sub>), s = sin(q<sub>i</sub>), cα = cos(α<sub>i</sub>) e sα = sin(α<sub>i</sub>):')
matrix([['c','-s cα','s sα','a<sub>i</sub> c'],['s','c cα','-c sα','a<sub>i</sub> s'],['0','sα','cα','d<sub>i</sub>'],['0','0','0','1']])
eq('T<sub>B</sub> = T<sub>z</sub>(H) R<sub>x</sub>(π/2)<br/>T<sub>F</sub>(q) = T<sub>B</sub> A<sub>1</sub> A<sub>2</sub> A<sub>3</sub> A<sub>4</sub> T<sub>z</sub>(d6)')
P('T<sub>B</sub> fixa o ombro a 0,30 m do chão e orienta os eixos iniciais horizontalmente. Não existe uma junta móvel que gire a base em torno da vertical. Os três primeiros eixos móveis são paralelos e o quarto é perpendicular a eles.')
eq('p<sub>esfera</sub> = p<sub>F</sub> + 0,15 R<sub>F</sub> e<sub>z</sub><br/>p<sub>garra</sub> = p<sub>F</sub> + 0,05 R<sub>F</sub> e<sub>z</sub>, &nbsp; e<sub>z</sub> = [0, 0, 1]<super>T</super>')
P('R<sub>F</sub> e p<sub>F</sub> são a rotação e a posição extraídas de T<sub>F</sub>. A posição que define a tarefa é o centro da esfera, e não a flange. O domínio angular assumido é -π ≤ q<sub>i</sub> ≤ π.')
source('modelo_geometrico_4r, cinematica e cinematica_4r.')

page(5,'Cinemática inversa e espaço de trabalho','Cálculos / alcance')
P('Para uma posição desejada (x, y, z), a orientação da esfera é livre. O programa amostra s = q1 + q2 + q3 e dois sinais para punho e cotovelo. Define D = d6 + 0,15 = 0,2323 m.')
eq('c4 = -(y + d4)/D; &nbsp; q4 = σ<sub>p</sub> arccos(c4), &nbsp; σ<sub>p</sub> ∈ {-1, +1}')
eq('X = -[x - d5 sin(s) + D sin(q4) cos(s)]<br/>Z = -[z - H + d5 cos(s) + D sin(q4) sin(s)]')
eq('c2 = (X² + Z² - L1² - L2²)/(2 L1 L2)<br/>q2 = σ<sub>c</sub> arccos(c2), &nbsp; σ<sub>c</sub> ∈ {-1, +1}')
eq('q1 = atan2(Z, X) - atan2(L2 sin(q2), L1 + L2 cos(q2))<br/>q3 = s - q1 - q2')
P('É necessário que |c4| ≤ 1 e |c2| ≤ 1. Os ângulos são representados dentro dos limites. Para transporte, o código exclui também a vizinhança singular |c| ≥ 1 - 10<super>-8</super> e verifica continuidade entre amostras. No mapa estático, admite-se a fronteira geométrica.')
H2('Como a área é estimada')
P('No piso z = 0, o centro da esfera fica em z = 0,10 m. A malha padrão usa espaçamento Δ = 0,02 m e s em passos de 15°. Para cada centro de célula, procura-se ao menos uma postura que alcance a posição e passe no torque estático.')
eq('A<sub>coleta</sub> ≈ n<sub>células aceitas</sub> Δ²')
P('O melhor caso possui 1572 células aceitas: 1572 × 0,02² = <b>0,6288 m²</b>. A avaliação é comparada com Δ = 0,04 m e passo angular de 30° para observar sensibilidade à resolução.')
note('A área é de sustentação estática amostrada. Não garante passagem entre todos os pontos, ausência de colisão ou uma fronteira exata de alcance. Uma célula sem solução encontrada não prova impossibilidade.')
source('ik_transporte_4r, posturas_coleta_4r e mapear_coleta_4r.')

page(6,'Massas, centros e inércias','Cálculos / construção')
P('O modelo usa 19 componentes: cinco tubos (dois segmentos e três trechos de punho), quatro motores, quatro redutores, quatro suportes, uma garra e uma esfera. A massa de cada componente é contabilizada uma única vez.')
eq('a<sub>int</sub> = b - 2t; &nbsp; A<sub>sec</sub> = b² - a<sub>int</sub>²; &nbsp; m = ρ A<sub>sec</sub> L')
P('Com b = 0,060 m e t = 0,003 m: a<sub>int</sub> = 0,054 m, A<sub>sec</sub> = 0,000684 m² e ρA<sub>sec</sub> = 1,8468 kg/m. O tubo de 0,30 m pesa 0,55404 kg; o de 0,45 m pesa 0,83106 kg. São massas dos tubos, sem acessórios.')
eq('I<sub>axial</sub> = m(b² + a<sub>int</sub>²)/6<br/>I<sub>transversal</sub> = m(L² + b² + a<sub>int</sub>²)/12')
P('Essas expressões vêm de integrar a inércia de um prisma externo menos o vazio interno. O centro do tubo uniforme é seu ponto médio. Para seu eixo unitário e no mundo:')
eq('I<sub>tubo</sub> = I<sub>transversal</sub> I<sub>3</sub> + (I<sub>axial</sub> - I<sub>transversal</sub>) ee<super>T</super>')
P('Motor, redutor, suporte e garra são corpos esféricos equivalentes, com raios assumidos de 0,040; 0,045; 0,030 e 0,050 m. A carga é uma esfera maciça uniforme de raio 0,10 m.')
eq('I<sub>esférico</sub> = (2/5) m r² I<sub>3</sub>; &nbsp; I<sub>carga</sub> = 0,020 I<sub>3</sub> kg·m²')
P('Motores, redutores e suportes ficam no eixo da junta, presos ao elo anterior. O primeiro conjunto permanece na base e não integra a massa móvel. Para agregar os componentes k de um elo j, expressam-se os centros e tensores no mesmo referencial:')
eq('m<sub>j</sub> = Σ<sub>k</sub> m<sub>k</sub>; &nbsp; c<sub>j</sub> = (Σ<sub>k</sub> m<sub>k</sub> r<sub>k</sub>)/m<sub>j</sub><br/>I<sub>j</sub> = Σ<sub>k</sub> [R<sub>k</sub>I<sub>k</sub>R<sub>k</sub><super>T</super> + m<sub>k</sub>((d<sub>k</sub><super>T</super>d<sub>k</sub>)I<sub>3</sub> - d<sub>k</sub>d<sub>k</sub><super>T</super>)]')
P('Aqui d<sub>k</sub> = r<sub>k</sub> - c<sub>j</sub>. O segundo termo aplica o teorema dos eixos paralelos. As inércias equivalentes são hipóteses de construção; a inércia do rotor cadastrada será usada separadamente na transmissão.','small')
source('massas_estaticas_4r e modelo_dinamico_4r. Densidade: [4].')

page(7,'Equilíbrio estático e margem','Cálculos / sustentação')
P('Cada componente exerce a força peso F<sub>k</sub> = m<sub>k</sub>g no seu centro r<sub>k</sub>. Seu momento é projetado sobre o eixo unitário z<sub>j</sub> da junta j. Só contribuem os componentes movidos por essa junta.')
eq('τ<sub>g,j</sub> = -Σ<sub>k movido por j</sub> z<sub>j</sub><super>T</super> [(r<sub>k</sub> - o<sub>j</sub>) × m<sub>k</sub>g]')
P('o<sub>j</sub> é a origem do eixo. O sinal negativo fornece o torque do atuador que equilibra a gravidade. Para comparação com capacidade usa-se o módulo; um torque negativo não significa esforço nulo.')
eq('τ<sub>cap,j</sub> = η<sub>j</sub>N<sub>j</sub>T<sub>c,j</sub><br/>U<sub>est</sub> = max<sub>j, amostras</sub> [F<sub>s</sub>|τ<sub>g,j</sub>| / τ<sub>cap,j</sub>]')
P('T<sub>c,j</sub> é o torque contínuo cadastrado no motor. Exige-se U<sub>est</sub> ≤ 1. A margem F<sub>s</sub> = 1,5 multiplica o torque exigido e é aplicada uma única vez. A capacidade estática ηNT<sub>c</sub> é uma aproximação; não caracteriza freio ou autotravamento.')
H2('Exemplo numérico para explicar na apresentação')
P('Uma carga de 5 kg a uma distância perpendicular de 0,40 m de um eixo horizontal exige, somente pela carga:')
eq('τ = 5 × 9,81 × 0,40 = 19,62 N·m<br/>F<sub>s</sub> τ = 1,5 × 19,62 = 29,43 N·m')
table(['Redução','η N T<sub>c</sub>','Torque de junta admissível com F<sub>s</sub> = 1,5'],[
 ['50','47,625 N·m','31,75 N·m'],['80','76,20 N·m','50,80 N·m'],['100','95,25 N·m','63,50 N·m']
],[85,130,WIDTH-215])
P('O programa soma também os pesos dos tubos, da garra e dos conjuntos de junta. Portanto, o cálculo isolado de 19,62 N·m não dimensiona sozinho o braço.')
P('Na rota, escolhe-se o ramo com menor pico de utilização estática entre os ramos pesquisados em 21 amostras por trecho. Depois, confirma-se a rota em 201 amostras por trecho e exige-se sustentação com margem em todas elas.','small')
source('torques_estaticos_4r, escolher_trajetoria_4r e triar_projeto.')

page(8,'Dinâmica inversa do braço','Cálculos / movimento')
P('A dinâmica inversa determina o torque necessário para executar uma referência de posição, velocidade e aceleração. Nesta etapa, a contribuição de aceleração relativa dos rotores ainda é acrescentada fora do modelo dos elos. A formulação de corpos rígidos segue a estrutura de [5,10].')
eq('τ = M(q)a<sub>q</sub> + h(q,v) + G(q)')
P('<b>M(q)</b> é a matriz de massa 4 × 4; <b>h(q,v)</b> reúne termos centrífugos e de Coriolis; <b>G(q)</b> é o torque gravitacional. τ, h e G são vetores de quatro torques. Não há termo adicional de contato: a esfera já pertence ao corpo final no modo carregado.')
H2('Jacobianas e matriz de massa')
eq('J<sub>v,j</sub><sup>(i)</sup> = z<sub>j</sub> × (r<sub>c,i</sub> - o<sub>j</sub>); &nbsp; J<sub>ω,j</sub><sup>(i)</sup> = z<sub>j</sub>, &nbsp; j ≤ i')
P('Para j &gt; i, a coluna é zero. J<sub>v</sub> relaciona velocidades articulares à velocidade linear do centro; J<sub>ω</sub>, à velocidade angular do elo. Centros, eixos e tensores devem estar no mesmo referencial.')
eq('M(q) = Σ<sub>i</sub> [m<sub>i</sub>J<sub>v</sub><sup>(i)T</sup>J<sub>v</sub><sup>(i)</sup> + J<sub>ω</sub><sup>(i)T</sup> R<sub>i</sub>I<sub>i</sub>R<sub>i</sub><super>T</super> J<sub>ω</sub><sup>(i)</sup>]')
eq('G(q) = -Σ<sub>i</sub> J<sub>v</sub><sup>(i)T</sup> m<sub>i</sub> g')
H2('Termos de velocidade')
eq('h<sub>i</sub> = Σ<sub>j=1..4</sub> Σ<sub>k=1..4</sub> c<sub>ijk</sub> v<sub>j</sub>v<sub>k</sub><br/>c<sub>ijk</sub> = (1/2)[∂M<sub>ij</sub>/∂q<sub>k</sub> + ∂M<sub>ik</sub>/∂q<sub>j</sub> - ∂M<sub>jk</sub>/∂q<sub>i</sub>]')
eq('∂M/∂q<sub>k</sub> ≈ [M(q + δe<sub>k</sub>) - M(q - δe<sub>k</sub>)]/(2δ), &nbsp; δ = 10<super>-6</super> rad')
P('e<sub>k</sub> seleciona a coordenada k. O código usa diferenças centrais para obter as derivadas. A mesma matriz permite calcular a energia cinética K = v<super>T</super>Mv/2. A gravidade é rotacionada para o referencial do ombro quando se usa o núcleo DH.','small')
source('massa, gravidade e dinamica. Os testes incluem comparação com inverseDynamics do MATLAB.')

page(9,'Caminho, tempo e derivadas','Cálculos / referência')
P('O trajeto cartesiano possui três retas: elevar, deslocar horizontalmente no caso padrão e baixar. Os pontos são P0 = coleta, P1 = coleta + [0,0,h], P2 = depósito + [0,0,h] e P3 = depósito. Não se procura desviar de obstáculos.')
eq('T = T<sub>ida</sub>/3; &nbsp; ξ = t<sub>local</sub>/T; &nbsp; 0 ≤ ξ ≤ 1<br/>β(ξ) = 10ξ³ - 15ξ⁴ + 6ξ⁵')
eq('p(ξ) = P<sub>a</sub> + β(ξ)(P<sub>b</sub> - P<sub>a</sub>)')
eq('dp/dt = (30ξ² - 60ξ³ + 30ξ⁴)(P<sub>b</sub> - P<sub>a</sub>)/T<br/>d²p/dt² = (60ξ - 180ξ² + 120ξ³)(P<sub>b</sub> - P<sub>a</sub>)/T²')
P('A escala quíntica zera velocidade e aceleração no começo e no fim de cada trecho [7]. O braço para nos pontos intermediários. As posições articulares q(ξ) vêm da cinemática inversa da página 5, mantendo s e os sinais do ramo escolhidos.')
H2('Derivadas articulares usadas pelo programa')
P('As derivadas de q em relação a ξ são calculadas por fórmulas centrais de cinco pontos, com ε = 10<super>-4</super>. Antes de derivar, alinha-se a representação angular para evitar saltos artificiais de 2π.')
eq('q′(ξ) ≈ [q(ξ-2ε) - 8q(ξ-ε) + 8q(ξ+ε) - q(ξ+2ε)]/(12ε)')
eq('q″(ξ) ≈ [-q(ξ+2ε) + 16q(ξ+ε) - 30q(ξ)<br/> + 16q(ξ-ε) - q(ξ-2ε)]/(12ε²)')
eq('v = q′(ξ)/T; &nbsp; a<sub>q</sub> = q″(ξ)/T²')
P('São usadas 201 amostras por trecho. Nos extremos, v e a<sub>q</sub> são definidos como zero. Confere-se continuidade entre trechos e domínio articular. A escolha de 2, 4 ou 8 s muda velocidades e acelerações, sem mudar o caminho geométrico.')
eq('τ(ξ,T) = G(q(ξ)) + A<sub>din</sub>(ξ)/T²<br/>A<sub>din</sub>(ξ) = M(q(ξ))q″(ξ) + h(q(ξ),q′(ξ))')
P('Essa separação permite reaproveitar os cálculos dinâmicos de um ramo para diversos tempos, pois h é quadrático nas velocidades. A letra A<sub>din</sub> aqui não é a matriz A do MPC.','small')
source('trajetoria_transporte_4r e base_dinamica_transporte.')

page(10,'Referência contínua e ciclo completo','Cálculos / interpolação')
P('O controlador trabalha entre as amostras da trajetória. Para que posição, velocidade e aceleração sejam coerentes, o programa constrói polinômios quínticos de Hermite, um por intervalo e por junta.')
eq('λ = (t - t<sub>k</sub>)/Δt; &nbsp; q(λ) = a0 + a1λ + a2λ² + a3λ³ + a4λ⁴ + a5λ⁵')
P('Nos extremos do intervalo são conhecidos q0, v0, a<sub>q0</sub> e q1, v1, a<sub>q1</sub>. Os símbolos a0 a a5 são coeficientes do polinômio, não os parâmetros DH.')
eq('a0 = q0; &nbsp; a1 = v0 Δt; &nbsp; a2 = a<sub>q0</sub> Δt²/2<br/>d = q1 - a0 - a1 - a2<br/>w = v1 Δt - a1 - 2a2; &nbsp; b = a<sub>q1</sub> Δt² - 2a2')
eq('a3 = 10d - 4w + b/2<br/>a4 = -15d + 7w - b<br/>a5 = 6d - 3w + b/2')
eq('v(t) = (a1 + 2a2λ + 3a3λ² + 4a4λ³ + 5a5λ⁴)/Δt<br/>a<sub>q</sub>(t) = (2a2 + 6a3λ + 12a4λ² + 20a5λ³)/Δt²')
P('As derivadas vêm do mesmo polinômio. Isso evita interpolar três sinais independentes que poderiam deixar de representar o mesmo movimento.')
H2('Sequência de carga')
table(['Fase','Carga modelada','Duração'],[
 ['Pausa na coleta, esfera já presa','5 kg','0,5 s'],
 ['Elevar, transportar, baixar','5 kg','T<sub>ida</sub>'],
 ['Pausa no depósito, esfera já liberada','0 kg','0,5 s'],
 ['Retorno pela rota inversa','0 kg','T<sub>ida</sub>']
],[255,110,WIDTH-365])
eq('T<sub>ciclo</sub> = 2T<sub>ida</sub> + 1 s')
P('O retorno inverte a ordem das posições e o sinal das velocidades; as acelerações são invertidas na ordem temporal, sem troca adicional de sinal. A gravidade e a inércia são recalculadas para carga zero. A troca de carga é idealizada e não reinicia o estado real.')
source('interpolante_controle, referencia_mpc e avaliar_ciclo_transporte.')

page(11,'Reduções, rotores e requisitos do motor','Cálculos / acionamento')
P('N<sub>i</sub> é a razão velocidade do motor/velocidade da junta. Aumentar a redução amplia a capacidade de torque na junta, mas também aumenta a rotação e a contribuição de inércia do rotor. O efeito N² é discutido em [6].')
eq('ω<sub>m,i</sub> = N<sub>i</sub>v<sub>i</sub>; &nbsp; α<sub>m,i</sub> = N<sub>i</sub>a<sub>q,i</sub><br/>n<sub>m,i</sub> = (60/2π)N<sub>i</sub>v<sub>i</sub> &nbsp; [rpm]')
eq('u<sub>req,i</sub> = τ<sub>i</sub>/(η<sub>i</sub>N<sub>i</sub>) + J<sub>r,i</sub>N<sub>i</sub>a<sub>q,i</sub>')
P('A primeira parcela atende aos elos e à carga através da transmissão. A segunda acelera o rotor em relação ao motor. Para a triagem usa-se um envelope conservador, somando módulos para impedir cancelamento entre parcelas:')
eq('E<sub>i</sub>(t) = |τ<sub>i</sub>(t)|/(η<sub>i</sub>N<sub>i</sub>) + |J<sub>r,i</sub>N<sub>i</sub>a<sub>q,i</sub>(t)|<br/>U<sub>din</sub> = max<sub>i,t</sub> [F<sub>s</sub>E<sub>i</sub>(t)/T<sub>c,i</sub>] ≤ 1')
eq('E<sub>RMS,i</sub> = √[(1/T<sub>ciclo</sub>) ∫<sub>0..T_ciclo</sub> E<sub>i</sub>(t)² dt]')
P('O pico decide a aprovação de torque nesta versão. O RMS do envelope é calculado como informação complementar, por integração trapezoidal em cada fase, incluindo as pausas:')
eq('∫ E²dt ≈ Σ<sub>k</sub> [(E<sub>k</sub>² + E<sub>k+1</sub>²)/2](t<sub>k+1</sub> - t<sub>k</sub>)')
H2('Inércia refletida e aproximação de rendimento')
eq('J<sub>ref,i</sub> = N<sub>i</sub>² J<sub>r,i</sub><br/>[M(q) + diag(η<sub>i</sub>N<sub>i</sub>²J<sub>r,i</sub>)]a<sub>q</sub> + h + G = diag(η<sub>i</sub>N<sub>i</sub>)u')
P('A segunda equação é a planta implementada: resulta de multiplicar a expressão assinada de u<sub>req</sub> por ηN. Para N = 100, J<sub>ref</sub> = 0,291 kg·m²; o termo adicionado à matriz nessa aproximação é ηJ<sub>ref</sub> = 0,21825 kg·m².')
note('O ganho ηN é aplicado nos dois sentidos. Trata-se de uma aproximação de torque, não de um modelo energético completo da transmissão. Não há atrito detalhado, inércia interna das engrenagens nem acoplamentos do giro do rotor com o corpo anterior. RPM e RMS não validam curva torque-velocidade ou aquecimento.')
source('requisitos_motor, avaliar_ciclo_transporte, termos_controle e planta_mpc.')

page(12,'PD com compensação e simulação da planta','Cálculos / controle')
P('O PD implementado inclui compensação do modelo dinâmico, da classe de controle por torque calculado [8]. Defina M<sub>e</sub> = M + diag(ηN²J<sub>r</sub>), b = h + G e B<sub>τ</sub> = diag(ηN). O subscrito d indica referência e o chapéu indica modelo nominal do controlador.')
eq('e = q<sub>d</sub> - q; &nbsp; e<sub>v</sub> = v<sub>d</sub> - v<br/>a<sub>cmd</sub> = a<sub>q,d</sub> + K<sub>p</sub>e + K<sub>d</sub>e<sub>v</sub>')
eq('u<sub>pedido</sub> = B<sub>τ</sub><super>-1</super>[M̂<sub>e</sub>(q)a<sub>cmd</sub> + b̂(q,v)]<br/>u<sub>i</sub> = min[T<sub>c,i</sub>, max(-T<sub>c,i</sub>, u<sub>pedido,i</sub>)]')
P('Os ganhos são K<sub>p</sub> = diag(ω<sub>n</sub>²) e K<sub>d</sub> = diag(2ζω<sub>n</sub>), com ω<sub>n</sub> = 12 rad/s e ζ = 1 em todas as juntas: K<sub>p</sub> = 144 I<sub>4</sub> e K<sub>d</sub> = 24 I<sub>4</sub>. Com modelo perfeito, atuação contínua e sem saturação, resulta e″ + K<sub>d</sub>e′ + K<sub>p</sub>e = 0.')
P('Na simulação há amostragem, limite de torque e possibilidade de massas diferentes das previstas. Portanto, ângulos, velocidades e acelerações realizados podem diferir da referência. O limite físico usado é T<sub>c</sub>, sem dividir novamente por 1,5.')
H2('Integração do movimento realizado')
eq('x = [q<super>T</super>, v<super>T</super>]<super>T</super><br/>dx/dt = f(x,u) = [v<super>T</super>, {M<sub>e</sub><super>-1</super>(B<sub>τ</sub>u - b)}<super>T</super>]<super>T</super>')
P('O comando permanece constante entre atualizações de aproximadamente 20 ms. A planta não linear usa Runge-Kutta de quarta ordem (RK4), com subpassos δt ≤ 0,002 s:')
eq('k1 = f(x,u); &nbsp; k2 = f(x + δt k1/2,u)<br/>k3 = f(x + δt k2/2,u); &nbsp; k4 = f(x + δt k3,u)<br/>x<sub>novo</sub> = x + (δt/6)(k1 + 2k2 + 2k3 + k4)')
P('O estado inicial é q da coleta mais [1; -1; 0,5; -0,5] graus, e v = 0. Não começa necessariamente esticado. O cenário alterado multiplica por 1,2 as massas dos tubos, suportes, redutores e garra; mantém motores e esfera. O controlador continua usando o modelo nominal.')
source('ensaio_mpc, planta_mpc, termos_controle e hipoteses_controle.')

page(13,'MPC: modelo de previsão','Cálculos / controle preditivo')
P('O MPC escolhe uma sequência futura de torques, aplica somente o primeiro comando e repete a otimização após observar o novo estado. Usa-se um MPC <b>linear variante no tempo (LTV)</b>, aplicado à planta não linear. A classe de modelos é descrita em [9]; a implementação e o otimizador são próprios.')
H2('Linearização em torno da referência')
eq('dx/dt ≈ A<sub>c</sub>x + B<sub>c</sub>u + c<sub>c</sub><br/>A<sub>c</sub> = ∂f/∂x; &nbsp; B<sub>c</sub> = ∂f/∂u<br/>c<sub>c</sub> = f(x̄,ū) - A<sub>c</sub>x̄ - B<sub>c</sub>ū')
P('x̄ e ū são o estado e o torque nominais no ponto médio do intervalo. Cada coluna de A<sub>c</sub> é obtida por diferenças centrais de passo 10<super>-5</super> na respectiva coordenada de estado. A matriz de entrada é calculada diretamente:')
eq('B<sub>c</sub> = [0<sub>4×4</sub>; &nbsp; M<sub>e</sub><super>-1</super>B<sub>τ</sub>]')
P('A notação [A; B] representa empilhamento vertical. O termo c<sub>c</sub> preserva o valor de f no ponto de linearização. A sequência de modelos nominais é preparada antes do ensaio e inclui a troca programada de carga.')
H2('Discretização com retenção de ordem zero')
eq('exp(Δt [A<sub>c</sub> &nbsp; B<sub>c</sub> &nbsp; c<sub>c</sub>; &nbsp; 0<sub>5×13</sub>])<br/>= [A<sub>d</sub> &nbsp; B<sub>d</sub> &nbsp; c<sub>d</sub>; &nbsp; 0<sub>5×8</sub> &nbsp; I<sub>5</sub>]')
eq('x<sub>k+1</sub> = A<sub>d,k</sub>x<sub>k</sub> + B<sub>d,k</sub>u<sub>k</sub> + c<sub>d,k</sub>')
P('A exponencial de matriz produz a discretização exata para o modelo afim congelado naquele intervalo. A aproximação em relação ao braço real continua existindo, pois a planta é não linear.')
table(['Parâmetro','Valor'],[
 ['Estado / entrada','8 estados (4 ângulos e 4 velocidades) / 4 torques de motor'],
 ['Período / horizonte','20 ms / 15 passos, aproximadamente 0,30 s'],
 ['Fronteiras de fase','Inseridas na malha; alguns intervalos ficam menores que 20 ms'],
 ['Atualização','Novo estado real inicia cada previsão; massas nominais não são identificadas online']
],[150,WIDTH-150])
note('Não é NMPC completo nem MPC adaptativo. Não há filtro de estado: posição e velocidade são consideradas medidas ideais. O horizonte após o fim do ciclo mantém referência parada e carga zero.')
source('modelo_local_mpc, preparar_mpc e referencia_mpc.')

page(14,'MPC: custo, restrições e solução','Cálculos / otimização')
P('Defina D<sub>T</sub> = diag(T<sub>c</sub>) e z<sub>j</sub> = D<sub>T</sub><super>-1</super>u<sub>j</sub>. O vetor Z empilha os 15 comandos normalizados e possui 60 variáveis. A previsão começa no estado medido x<sub>0</sub>.')
eq('J = Σ<sub>j=1..15</sub> [e<sub>j</sub><super>T</super>Q<sub>j</sub>e<sub>j</sub> + R ‖z<sub>j</sub> - z<sub>ref,j</sub>‖²]<br/> + λ Σ<sub>j=1..15</sub> ‖z<sub>j</sub> - z<sub>j-1</sub>‖²; &nbsp; -1 ≤ Z ≤ 1')
P('e<sub>j</sub> = x<sub>j</sub> - x<sub>d,j</sub>; z<sub>0</sub> é o último torque aplicado normalizado. Q = diag(40000 I<sub>4</sub>, 25 I<sub>4</sub>), Q<sub>15</sub> = 2Q, R = 0,01 e λ = 0,05. O torque de referência vem da dinâmica nominal. Os pesos são escolhas de sintonia.')
H2('Condensação em um problema quadrático')
P('Escreva x<sub>j</sub> = a<sub>j</sub> + P<sub>j</sub>Z, com a<sub>0</sub> = x<sub>0</sub> e P<sub>0</sub> = 0. E<sub>j</sub> seleciona os quatro elementos do comando j em Z.')
eq('a<sub>j</sub> = A<sub>d,j</sub>a<sub>j-1</sub> + c<sub>d,j</sub><br/>P<sub>j</sub> = A<sub>d,j</sub>P<sub>j-1</sub> + B<sub>d,j</sub>D<sub>T</sub>E<sub>j</sub>')
P('Se D<sub>Δ</sub>Z = [z1; z2-z1; ...; z15-z14] e z<sub>ant</sub> = [z0; 0; ...; 0], a expansão do custo fornece:')
eq('min<sub>-1≤Z≤1</sub> (1/2)Z<super>T</super>H<sub>QP</sub>Z + f<sub>QP</sub><super>T</super>Z<br/>H<sub>QP</sub> = 2Σ P<sub>j</sub><super>T</super>Q<sub>j</sub>P<sub>j</sub> + 2R I<sub>60</sub> + 2λ D<sub>Δ</sub><super>T</super>D<sub>Δ</sub><br/>f<sub>QP</sub> = 2Σ P<sub>j</sub><super>T</super>Q<sub>j</sub>(a<sub>j</sub>-x<sub>d,j</sub>) - 2R Z<sub>ref</sub> - 2λD<sub>Δ</sub><super>T</super>z<sub>ant</sub>')
P('O código resolve esse QP convexo por conjunto ativo: minimiza nas variáveis livres, limita o passo para permanecer na caixa e libera restrições incompatíveis com a condição de ótimo. O termo R &gt; 0 torna a Hessiana positiva definida.')
eq('r<sub>proj</sub> = ‖Z - proj<sub>[-1,1]</sub>(Z - (H<sub>QP</sub>Z+f<sub>QP</sub>)/s<sub>H</sub>)‖<sub>∞</sub><br/>s<sub>H</sub> = max(1, ‖H<sub>QP</sub>‖<sub>∞</sub>); &nbsp; r<sub>proj</sub> ≤ 10<super>-7</super>')
P('São permitidas até 200 iterações. Falha de convergência interrompe o ensaio. O torque tem limite rígido; sua variação é apenas penalizada. Limites articulares são monitorados na planta, mas não são restrições do QP. Não se impõem limites de velocidade ou colisão.','small')
source('comando_mpc, qp_caixa e hipoteses_mpc.')

page(15,'Critérios e resultados já obtidos','Verificação')
eq('e<sub>p,max</sub> = max<sub>t≥0,5 s</sub> ‖p(q(t)) - p(q<sub>d</sub>(t))‖<sub>2</sub> ≤ 0,005 m<br/>e<sub>q,max</sub> = max<sub>t≥0,5 s, i</sub> |q<sub>i</sub>(t)-q<sub>d,i</sub>(t)| ≤ π/180 rad')
P('A qualificação exige área mínima, caminho encontrado, estática e dinâmica com margem, e MPC concluído dentro das tolerâncias em todos os cenários de massa. O PD serve de comparação. O erro inicial é registrado, mas a aprovação usa o movimento após a pausa de 0,5 s.')
P('<b>Execução 13/09/2026:</b> 64 geometrias × 3 reduções × 3 tempos = 576 variantes. Dessas, 315 passaram na triagem; 3 receberam controle e foram qualificadas; 312 permanecem pendentes. As outras 261 falharam na triagem.')
table(['L1 / L2','Área estática','Uso de torque¹','Pior erro MPC²'],[
 ['0,30 / 0,45 m','0,6288 m²','85,5%','0,806 mm'],
 ['0,35 / 0,45 m','0,6256 m²','85,2%','0,891 mm'],
 ['0,25 / 0,45 m','0,6256 m²','87,7%','0,707 mm']
],[130,120,125,WIDTH-375])
P('¹ Utilização dinâmica nominal, já com margem 1,5. ² Maior erro entre os cenários nominal e com construção 20% mais pesada. Todas usam R3 = [100,100,80,80], ida de 2 s e ciclo de 5 s.','small')
H2('Evidências numéricas')
P('Os <b>60 testes automatizados passaram</b>, incluindo cinemática, gravidade, dinâmica comparada com outra implementação, otimizador e decisões da integração. Nos seis ensaios principais de MPC foram registrados 1524 comandos, todos com convergência e sem violação do limite de torque normalizado.')
P('No candidato 0,30/0,45 m, repetir o último MPC com passo de planta de 1 ms alterou o pico de erro em aproximadamente 7,56 × 10<super>-6</super> mm e preservou a classificação. O cálculo de picos dinâmicos também compara 201 com 101 amostras por trecho.')
eq('δ<sub>pico</sub> = max<sub>i</sub> [(E<sub>pico,fino,i</sub> - E<sub>pico,grosso,i</sub>)/max(E<sub>pico,fino,i</sub>, ε<sub>maq</sub>)]')
H2('O que estes resultados permitem afirmar')
P('Foram encontradas configurações numericamente viáveis para <b>um ciclo especificado</b>, dentro da família e hipóteses estudadas. Não foi provado ótimo global, estabilidade geral do MPC ou viabilidade recursiva. Os testes são evidências numéricas, não validação experimental.')
P('Permanecem fora do escopo: colisões, curva torque-velocidade, aquecimento, estrutura, folgas, dinâmica elétrica, contato e dimensionamento da garra. A comparação PD/MPC usa a mesma tarefa e amostragem; não demonstra superioridade geral de uma classe de controle.','small')

page(16,'Referências utilizadas','Fontes / dados e formulação')
P('As equações foram reconstruídas e descritas a partir da implementação MATLAB [11]. As fontes externas abaixo fundamentam a geometria, os dados físicos e as classes de métodos. Os parâmetros assumidos e os resultados da simulação não são especificações fornecidas por essas fontes. Acesso às fontes online: 13 set. 2026.','small')
ref(1,'UNIVERSAL ROBOTS.','DH Parameters for calculations of kinematics and dynamics.',
'https://www.universal-robots.com/articles/ur/application-installation/dh-parameters-for-calculations-of-kinematics-and-dynamics',
'Tabela UR5: referência dos afastamentos d4, d5 e d6. Não se adotam as massas originais dos elos no braço candidato.')
ref(2,'ORIENTAL MOTOR.','NXM640A, 400 W NX Series Servo Motor.',
'https://catalog.orientalmotor.com/item/l-categories-servo-motors-tuning-free-servo-motors/400w-nx-series-servo-motors/nxm640a',
'Torque nominal de 1,27 N·m e inércia de rotor de 0,291 × 10<super>-4</super> kg·m².')
ref(3,'ORIENTAL MOTOR.','General Catalog 2012/2013: Servo Motors, NX Series.',
'https://www.orientalmotor.com/products/pdfs/2012-2013/B/usa_sv_nx_series.pdf',
'Página impressa B-26: massa de 1,5 kg do NXM640A sem freio. A página B-16 apresenta especificações/características da família.')
ref(4,'THYSSENKRUPP MATERIALS SERVICES.','Material Data Sheet EN AW-6061. Jun. 2018, p. 3.',
'https://ucpcdn.thyssenkrupp.com/_legacy/UCPthyssenkruppBAMXUK/assets.files/material-data-sheets/aluminium/aluminium-6061.pdf',
'Densidade de referência a 20 °C: 2,70 kg/dm³.')
ref(5,'LYNCH, Kevin M.; PARK, Frank C.','Modern Robotics: Mechanics, Planning, and Control. Cambridge University Press, 2017.',
'https://modernrobotics.northwestern.edu/nu-gm-book-resource/8-1-lagrangian-formulation-of-dynamics-part-2-of-2/',
'Material complementar do capítulo 8.1: estrutura da dinâmica Lagrangiana, matriz de massa, termos de velocidade e gravidade.')
ref(6,'LYNCH, Kevin M.; PARK, Frank C.','Modern Robotics, seção 8.9: Actuation, Gearing, and Friction.',
'https://modernrobotics.northwestern.edu/nu-gm-book-resource/8-9-actuation-gearing-and-friction/',
'Material complementar: relação de transmissão e inércia de rotor refletida. A aproximação específica com rendimento adotada no programa está explicitada na página 11 deste memorial.')

page(17,'Referências e rastreabilidade','Fontes / controle e implementação')
ref(7,'LYNCH, Kevin M.; PARK, Frank C.','Modern Robotics, seções 9.1 e 9.2: Point-to-Point Trajectories, parte 2.',
'https://modernrobotics.northwestern.edu/nu-gm-book-resource/9-1-and-9-2-point-to-point-trajectories-part-2-of-2/',
'Escala temporal polinomial de quinta ordem.')
ref(8,'LYNCH, Kevin M.; PARK, Frank C.','Modern Robotics, seção 11.4: Motion Control with Torque or Force Inputs, parte 3.',
'https://modernrobotics.northwestern.edu/nu-gm-book-resource/11-4-motion-control-with-torque-or-force-inputs-part-3-of-3/',
'Controle por torque calculado e compensação do modelo dinâmico.')
ref(9,'MATHWORKS.','Time-Varying MPC. Documentação online.',
'https://www.mathworks.com/help/mpc/ug/time-varying-mpc.html',
'Fundamenta a classe LTV: modelos variáveis ao longo do horizonte. O projeto não usa o produto MPC Toolbox nem o estimador de estado nele descrito.')
ref(10,'MATHWORKS.','inverseDynamics; setFixedTransform. Documentação online.',
'https://www.mathworks.com/help/robotics/ref/rigidbodytree.inversedynamics.html',
'Equação de dinâmica de corpos rígidos e função usada como comparação independente nos testes.')
P('<link href="https://www.mathworks.com/help/robotics/ref/rigidbodyjoint.setfixedtransform.html" color="#127A7A">https://www.mathworks.com/help/robotics/ref/rigidbodyjoint.setfixedtransform.html</link>','small')
ref(11,'PROJETO LOCAL DO TCC.','dimensionamento_bracos: código-fonte MATLAB e resultados. Versão conferida em 13 set. 2026.',None,
'Fontes diretas: entrada_projeto.m, projetar_braco.m, pasta +braco, hipóteses e testes. Resultados: execução 20260913_163801_796; arquivo projeto.mat e tabelas exportadas.')
H2('Onde está o material apresentado')
P('A pasta do programa nesta máquina é:','small')
P(html.escape(str(ROOT)).replace('\\','/'),'small')
P('O caso usado neste memorial está em <b>resultados/projeto_integrado/20260913_163801_796/</b>. O registro dos testes está em <b>resultados/testes.json</b>. O programa principal foi executado em MATLAB R2025b Update 3.','small')
P('<b>Para reproduzir:</b> manter a planilha e as hipóteses atuais e executar <b>projeto = projetar_braco;</b>. O fluxo de simulação usa MATLAB base. Os testes de comparação independente de dinâmica requerem Robotics System Toolbox.','small')

class NumberedCanvas(canvas.Canvas):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.saved=[]
    def showPage(self):
        self.saved.append(dict(self.__dict__)); self._startPage()
    def save(self):
        n=len(self.saved)
        for state in self.saved:
            self.__dict__.update(state)
            self.setStrokeColor(BORDER); self.setLineWidth(.6); self.line(44,43,W-44,43)
            self.setFont('DV',8); self.setFillColor(GRAY)
            self.drawString(44,29,'BRAÇO 4R • GUIA E MEMORIAL DE CÁLCULO • 13/09/2026')
            self.drawRightString(W-44,29,f'{self._pageNumber} / {n}')
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

doc=SimpleDocTemplate(str(PDF),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=38,bottomMargin=58,
 title='Guia de uso e memorial de cálculo - Braço robótico 4R',
 author='Projeto TCC - Dimensionamento de braços',subject='Motores disponíveis, geometria, dinâmica e controle PD/MPC',pageCompression=1)
doc.build(story,canvasmaker=NumberedCanvas)
reader=PdfReader(str(PDF))
texts=[x.extract_text() for x in reader.pages]
qa={'pages':len(texts),'expected_pages':17,'equations':eqno,'characters':[len(t) for t in texts],
    'pdf':str(PDF),'page_starts':[t[:110] for t in texts]}
(ROOT/'tmp/pdfs/qa_texto.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
assert len(texts)==17,qa
assert all(len(t)>500 for t in texts),qa
assert not any('\ufffd' in t or '\u25a0' in t for t in texts),'Caractere inválido'
print(json.dumps(qa,ensure_ascii=True,indent=2))

function tests=test_geometria_4r
tests=functiontests(localfunctions);
end
function setupOnce(tc)
addpath(fileparts(fileparts(mfilename('fullpath'))));
end
function testEquivalenciaComReferenciaSeisJuntas(tc)
p=braco.modelo_ur5_cb3(); h=hipoteses_construcao();
h.altura_ombro_sobre_piso_m=p.d(1);
g=braco.modelo_geometrico_4r(-p.a(2),-p.a(3),h);
posturas=[-0.7 0.4 -0.3 0.8; -pi/2 0 -pi/2 0;0 0 0 0];
for i=1:size(posturas,1)
    q=posturas(i,:).'; r=braco.cinematica_4r(q,g);
    [T,flange]=braco.cinematica([0;q;0],p);
    verifyEqual(tc,r.T_flange,flange,'AbsTol',1e-12);
    for j=1:4
        verifyEqual(tc,r.origens(:,j),T{j+1}(1:3,4),'AbsTol',1e-12);
        verifyEqual(tc,r.eixos(:,j),T{j+1}(1:3,3),'AbsTol',1e-12);
    end
end
end
function testEixosEBaseFixa(tc)
g=braco.modelo_geometrico_4r(0.30,0.40);
q=[-0.8;0.9;-0.4;0.7]; r=braco.cinematica_4r(q,g);
verifyEqual(tc,r.origens(:,1),[0;0;0.30],'AbsTol',1e-12);
verifyEqual(tc,r.eixos(:,1),[0;-1;0],'AbsTol',1e-12);
verifyEqual(tc,r.eixos(:,1),r.eixos(:,2),'AbsTol',1e-12);
verifyEqual(tc,r.eixos(:,2),r.eixos(:,3),'AbsTol',1e-12);
verifyEqual(tc,dot(r.eixos(:,3),r.eixos(:,4)),0,'AbsTol',1e-12);
q(1)=q(1)+0.5; s=braco.cinematica_4r(q,g);
verifyEqual(tc,s.origens(:,1),r.origens(:,1),'AbsTol',1e-12);
verifyEqual(tc,s.eixos(:,1),r.eixos(:,1),'AbsTol',1e-12);
end
function testAlturaAbsolutaSemContarDuasVezes(tc)
h=hipoteses_construcao(); g=braco.modelo_geometrico_4r(0.30,0.40,h);
r=braco.cinematica_4r(g.q_inicial,g);
h.altura_ombro_sobre_piso_m=0.80;
g2=braco.modelo_geometrico_4r(0.30,0.40,h); s=braco.cinematica_4r(g2.q_inicial,g2);
verifyEqual(tc,s.centro_esfera-r.centro_esfera,[0;0;0.50],'AbsTol',1e-12);
verifyEqual(tc,s.T_flange(1:3,1:3),r.T_flange(1:3,1:3),'AbsTol',1e-12);
end
function testComprimentosEFerramenta(tc)
g=braco.modelo_geometrico_4r(0.25,0.45); r=braco.cinematica_4r(g.q_inicial,g);
verifyEqual(tc,norm(r.origens(:,2)-r.origens(:,1)),0.25,'AbsTol',1e-12);
verifyEqual(tc,norm(r.origens(:,3)-r.origens(:,2)),0.45,'AbsTol',1e-12);
verifyEqual(tc,norm(r.centro_esfera-r.flange),0.15,'AbsTol',1e-12);
verifyEqual(tc,norm(r.centro_garra-r.flange),0.05,'AbsTol',1e-12);
g2=braco.modelo_geometrico_4r(0.35,0.45); s=braco.cinematica_4r(g.q_inicial,g2);
verifyEqual(tc,norm(s.centro_esfera-r.centro_esfera),0.10,'AbsTol',1e-12);
end
function testRejeitaLimitesEGeometriaInvalida(tc)
g=braco.modelo_geometrico_4r(0.30,0.30);
verifyError(tc,@()braco.cinematica_4r([2*pi;0;0;0],g),'braco:ForaDosLimites');
h=hipoteses_construcao(); h.espessura_m=h.lado_externo_m;
verifyError(tc,@()braco.modelo_geometrico_4r(0.30,0.30,h),'braco:SecaoInvalida');
verifyError(tc,@()visualizar_braco(0.10,0.30,'off'),'braco:ComprimentoForaDaFaixa');
end
function testControlesDaJanela(tc)
f=visualizar_braco(0.30,0.30,'off'); limpar=onCleanup(@()close(f)); %#ok<NASGU>
inicio=f.UserData.cinematica.centro_esfera;
controle=findobj(f,'Tag','parametro_1'); controle.Value=-45;
callback=controle.Callback; callback(controle,[]);
verifyGreaterThan(tc,norm(f.UserData.cinematica.centro_esfera-inicio),0.01);
verifyEqual(tc,f.UserData.q(1),-pi/4,'AbsTol',1e-12);
controle=findobj(f,'Tag','parametro_5'); controle.Value=0.50;
callback=controle.Callback; callback(controle,[]);
verifyEqual(tc,f.UserData.modelo.comprimentos_m,[0.50 0.30],'AbsTol',1e-12);
verifyEqual(tc,f.UserData.cinematica.origens(:,1),[0;0;0.30],'AbsTol',1e-12);
end

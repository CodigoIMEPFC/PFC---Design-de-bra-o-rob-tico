function tests=test_projeto_integrado
tests=functiontests(localfunctions);
end
function setupOnce(t)
t.TestData.raiz=fileparts(fileparts(mfilename('fullpath'))); addpath(t.TestData.raiz);
end
function testNaoQualificaSemControleOuSemMargem(t)
tab=fixture();
tab.mpc_executado=[false;true;true;true;true;true];
tab.mpc_concluido=[false;false;true;true;true;true];
tab.atende_mpc=[false;true;false;true;true;true];
tab.atende_dinamica(5)=false; tab.atende_estatica(6)=false;
r=braco.qualificar_projeto(tab);
verifyEqual(t,r.qualificado,[false;false;false;true;false;false]);
verifyEqual(t,r.resultado(1),"Pendente de controle");
verifyEqual(t,r.resultado(2),"Inconclusivo: MPC interrompido");
verifyEqual(t,r.resultado(3),"Reprovado no acompanhamento MPC");
end
function testSelecaoPrioridadesEGeometriasDistintas(t)
tab=fixture(); tab.geometria=[1;1;2;3;4;5];
tab.area_coleta_m2=[.6;.6;.5;.7;.9;.6];
tab.tempo_ida_s=[4;2;2;8;2;2];
tab.utilizacao_dinamica=[.8;.9;.5;.9;.5;.7];
tab.atende_dinamica(5)=false;
[ids,r]=braco.selecionar_candidatos_projeto(tab,3);
verifyEqual(t,ids,[4;6;2]); verifyFalse(t,any(r.id_candidato==5));
ids=braco.selecionar_candidatos_projeto(tab,0); verifyEmpty(t,ids);
end
function testEntradasForaDoEscopo(t)
e=entrada_projeto(); cfg=configuracao_estudo(); e.tarefa.carga_kg=6;
verifyError(t,@()braco.validar_entrada_projeto(e,cfg),'braco:CargaProjeto');
e=entrada_projeto(); e.nome_inventado=true;
verifyError(t,@()braco.validar_entrada_projeto(e,cfg),'braco:EntradaProjeto');
e=entrada_projeto(); e.passo_orientacao_graus=17;
verifyError(t,@()braco.validar_entrada_projeto(e,cfg),'braco:PassoAngularInvalido');
end
function testFluxoSemControlePreservaPendenciasETarefa(t)
e=entrada_projeto(); e.comprimentos_1_m=.30; e.comprimentos_2_m=.45;
e.passo_coleta_m=.08; e.passo_orientacao_graus=30; e.comparar_resolucao_coleta=false;
e.max_geometrias_controle=0; e.tarefa.tempos_ida_s=[2 4];
e.tarefa.coleta_m=[-.35 -.18 .1]; e.tarefa.deposito_m=[-.22 -.05 .1];
e.pasta_resultados=fullfile(t.TestData.raiz,'resultados','testes_integracao');
p=projetar_braco(e);
verifyTrue(t,p.concluido); verifyEqual(t,height(p.candidatos),6);
verifyEqual(t,unique(p.candidatos.tempo_ida_s),[2;4]);
verifyEmpty(t,p.qualificados); verifyEmpty(t,p.controles);
verifyFalse(t,any(p.candidatos.mpc_executado));
verifyGreaterThan(t,sum(p.candidatos.atende_dinamica),0);
verifyEqual(t,sum(p.candidatos.resultado=="Pendente de controle"),sum(p.candidatos.atende_dinamica));
verifyEqual(t,p.hipoteses_transporte.coleta_m,e.tarefa.coleta_m);
verifyEqual(t,p.hipoteses_transporte.deposito_m,e.tarefa.deposito_m);
q=p.candidatos(find(p.candidatos.atende_dinamica,1),:); g=p.busca.mapas{q.geometria}.geometria;
tr=braco.trajetoria_transporte_4r(g,p.hipoteses_transporte,[q.soma_angulos_rad q.sinal_punho q.sinal_cotovelo]);
cin=braco.cinematica_4r(tr.fases{1}.Q(:,1),g);
verifyEqual(t,cin.centro_esfera,e.tarefa.coleta_m.','AbsTol',1e-10);
verifyTrue(t,isfile(fullfile(p.pasta_saida,'projeto.mat')));
s=jsondecode(fileread(fullfile(p.pasta_saida,'status.json'))); verifyEqual(t,s.qualificados,0);
end
function testTarefaInalcancavelGeraMotivoSemAprovacao(t)
e=entrada_projeto(); e.comprimentos_1_m=.30; e.comprimentos_2_m=.45;
e.passo_coleta_m=.08; e.passo_orientacao_graus=30; e.comparar_resolucao_coleta=false;
e.tarefa.tempos_ida_s=2; e.tarefa.coleta_m=[10 10 .1];
e.pasta_resultados=fullfile(t.TestData.raiz,'resultados','testes_integracao');
p=projetar_braco(e);
verifyEmpty(t,p.qualificados); verifyEmpty(t,p.controles);
verifyFalse(t,any(p.candidatos.trajetoria_encontrada));
verifyTrue(t,all(p.candidatos.resultado=="Nenhum ramo continuo encontrado na busca da tarefa"));
end
function t=fixture()
t=table((1:6).','VariableNames',{'id_candidato'});
t.geometria=(1:6).'; t.area_coleta_m2=ones(6,1); t.tempo_ida_s=2*ones(6,1);
t.utilizacao_dinamica=.8*ones(6,1); t.massa_movel_kg=10*ones(6,1);
for f=["atende_area","trajetoria_encontrada","atende_estatica","atende_dinamica"]
    t.(f)=true(6,1);
end
for f=["mpc_executado","mpc_concluido","atende_mpc","qualificado"]
    t.(f)=false(6,1);
end
t.resultado=repmat("Falha na triagem",6,1);
end


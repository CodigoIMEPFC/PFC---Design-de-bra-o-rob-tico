function tests=test_mpc
tests=functiontests(localfunctions);
end
function setupOnce(t)
addpath(fileparts(fileparts(mfilename('fullpath'))));
end
function testQPContraEnumeracaoIndependente(t)
% Enumera as 3^4 combinacoes de restricoes ativas, sem usar outro otimizador.
for seed=1:5
    rng(seed); V=randn(4); H=V.'*V+.2*eye(4); f=5*randn(4,1);
    best=Inf; esperado=[];
    for codigo=0:80
        a=mod(floor(codigo./(3.^(0:3))),3).'-1;
        fixos=a~=0; livres=~fixos; x=a;
        x(livres)=-H(livres,livres)\(f(livres)+H(livres,fixos)*x(fixos));
        if all(abs(x)<=1+1e-10)
            custo=.5*x.'*H*x+f.'*x;
            if custo<best, best=custo; esperado=x; end
        end
    end
    [z,r]=braco.qp_caixa(H,f,-ones(4,1),ones(4,1),[],1e-10,500);
    verifyTrue(t,r.convergiu); verifyEqual(t,r.custo,best,'AbsTol',1e-8);
    verifyEqual(t,z,esperado,'AbsTol',1e-7); verifyLessThanOrEqual(t,max(abs(z)),1);
end
end
function testLimiteDeIteracoesNaoOculto(t)
[~,r]=braco.qp_caixa([2 1;1 2],[-10;2],[-1;-1],[1;1],[0;0],1e-14,1);
verifyFalse(t,r.convergiu);
end
function testQPMuitasRestricoesComSolucaoConhecida(t)
rng(82); n=40; V=randn(n); H=V.'*V+eye(n);
zstar=linspace(-1,1,n).'; zstar(1:10)=-1; zstar(end-9:end)=1;
grad=zeros(n,1); grad(1:10)=10; grad(end-9:end)=-10;
f=grad-H*zstar;
[z,r]=braco.qp_caixa(H,f,-ones(n,1),ones(n,1),ones(n,1),1e-11,500);
verifyTrue(t,r.convergiu); verifyEqual(t,z,zstar,'AbsTol',1e-7);
end
function testMPCUsaPrevisaoFuturaERespeitaTorque(t)
h=hipoteses_mpc(); h.horizonte_passos=3;
pr.limite=ones(4,1); pr.modelos=cell(1,3); pr.refs=cell(1,4);
for i=1:4, pr.refs{i}=struct('x',zeros(8,1)); end
for i=1:3
    pr.modelos{i}=struct('A',[eye(4),.1*eye(4);zeros(4),eye(4)], ...
        'B',[.005*eye(4);.1*eye(4)],'c',zeros(8,1),'u_ref',zeros(4,1));
end
[u0,r0]=braco.comando_mpc(zeros(8,1),1,pr,zeros(4,1),[],h);
pr.refs{4}.x(1)=1;
[u,r]=braco.comando_mpc(zeros(8,1),1,pr,zeros(4,1),[],h);
verifyTrue(t,r0.convergiu && r.convergiu);
verifyEqual(t,u0,zeros(4,1),'AbsTol',1e-12); verifyGreaterThan(t,u(1),.5);
verifyLessThanOrEqual(t,max(abs(r.z)),1);
end
function testLinearizacaoContraDinamicaNaoLinear(t)
g=braco.modelo_geometrico_4r(.3,.45); p=braco.modelo_dinamico_4r(g,1.5*ones(4,1),ones(4,1),5);
N=[100;100;80;80]; eta=.75*ones(4,1); J=2.91e-5*ones(4,1);
x=[-.3;1.5;.5;-.8;zeros(4,1)]; [~,b]=braco.termos_controle(x(1:4),x(5:8),p,N,eta,J);
u=b./(eta.*N); dt=.001; d=braco.modelo_local_mpc(x,u,p,N,eta,J,dt);
verifyEqual(t,d.A*x+d.B*u+d.c,x,'AbsTol',1e-11);
xp=x+1e-5*(1:8).'; up=u+1e-4*ones(4,1);
fun=@(y)braco.planta_mpc(y,up,p,N,eta,J);
a=fun(xp); bb=fun(xp+dt*a/2); c=fun(xp+dt*bb/2); dd=fun(xp+dt*c);
real=xp+dt*(a+2*bb+2*c+dd)/6;
verifyEqual(t,d.A*xp+d.B*up+d.c,real,'AbsTol',1e-8);
end
function testReferenciaFronteiras(t)
q=[1;2;3;4]; c.fases=cell(1,2);
for i=1:2
    c.fases{i}=struct('t_s',[i-1 i],'Q',[q q],'dq',zeros(4,2),'ddq',zeros(4,2),'carga_kg',5*(i==1));
end
r=braco.referencia_mpc(c,1); verifyEqual(t,r.modo,2);
r=braco.referencia_mpc(c,3); verifyEqual(t,r.q,q); verifyEqual(t,r.dq,zeros(4,1));
end

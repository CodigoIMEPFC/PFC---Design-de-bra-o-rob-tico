function tests=test_busca_coleta
tests=functiontests(localfunctions);
end
function setupOnce(tc)
addpath(fileparts(fileparts(mfilename('fullpath'))));
end
function testIKRecuperaPosturaConhecida(tc)
h=hipoteses_construcao(); q=[0.7;-0.4;-0.3;0.9];
g=braco.modelo_geometrico_4r(0.30,0.40,h); r=braco.cinematica_4r(q,g);
h.altura_ombro_sobre_piso_m=h.altura_ombro_sobre_piso_m+h.raio_esfera_m-r.centro_esfera(3);
g=braco.modelo_geometrico_4r(0.30,0.40,h); r=braco.cinematica_4r(q,g);
[Q,idx]=braco.posturas_coleta_4r(g,r.centro_esfera(1:2).',30);
verifyNotEmpty(tc,Q); verifyTrue(tc,all(idx==1));
erro=mod(Q-q.'+pi,2*pi)-pi;
verifyLessThan(tc,min(vecnorm(erro,2,2)),1e-10);
end
function testPosturasNoPisoEAlvoImpossivel(tc)
g=braco.modelo_geometrico_4r(0.25,0.45);
[X,Y]=ndgrid(-0.6:0.15:0.6,-0.3:0.1:0.1); xy=[X(:) Y(:)];
[Q,idx]=braco.posturas_coleta_4r(g,xy,30);
verifyNotEmpty(tc,Q);
amostra=unique(round(linspace(1,size(Q,1),60)));
for i=amostra
    r=braco.cinematica_4r(Q(i,:).',g);
    verifyEqual(tc,r.centro_esfera,[xy(idx(i),:).';g.hipoteses.raio_esfera_m],'AbsTol',1e-10);
end
[vazio,indices]=braco.posturas_coleta_4r(g,[0 10],30);
verifyEmpty(tc,vazio); verifyEmpty(tc,indices);
end
function testLoteContraCalculoPorComponentes(tc)
g=braco.modelo_geometrico_4r(0.25,0.45);
Q=deg2rad([-180 -60 30 70;-60 45 -45 30;0 0 0 0;30 75 -20 -90;170 -145 33 180]);
mot=[1.1;1.3;0.8;0.5]; red=[1;0.7;0.3;0.2];
tau=braco.torques_estaticos_lote_4r(g,Q,mot,red,5);
for i=1:size(Q,1)
    r=braco.torques_estaticos_4r(g,Q(i,:).',mot,red,5);
    verifyEqual(tc,tau(i,:).',r.torque_juntas_Nm,'AbsTol',1e-10);
end
end
function testMapasGuardamPosturaQueAtendeTodasJuntas(tc)
cfg=configuracao_estudo(); h=cfg.construcao; h.massas_redutores_kg=ones(1,4);
g=braco.modelo_geometrico_4r(0.30,0.30,h);
m=table("TESTE",1.5,10000,4,'VariableNames',{'id','massa_kg','torque_continuo_Nm','quantidade'});
xy=[-0.3 -0.2;0.3 -0.2;-0.4 0;0.4 0;0 0.5];
mapa=braco.mapear_coleta_4r(g,xy,30,m,ones(1,4),cfg);
verifyGreaterThan(tc,sum(mapa.geometrico),0);
for a=1:3
    c=mapa.casos{a}; verifyEqual(tc,c.celulas_aceitas,find(mapa.geometrico));
    for j=1:numel(c.celulas_aceitas)
        r=braco.comparar_estatica_4r(g,c.posturas_rad(j,:).',m,ones(1,4),cfg);
        verifyTrue(tc,r.resumo.atende_torque(a));
        verifyEqual(tc,r.estatica{1}.cinematica.centro_esfera,[xy(c.celulas_aceitas(j),:).';0.1],'AbsTol',1e-10);
    end
end
m.torque_continuo_Nm=1e-8;
fraco=braco.mapear_coleta_4r(g,xy,30,m,ones(1,4),cfg);
verifyEmpty(tc,fraco.casos{1}.celulas_aceitas);
end
function testAtribuicoesRespeitamEstoqueELimite(tc)
m=table([3;1],'VariableNames',{'quantidade'});
a=braco.atribuicoes_motores(m);
verifySize(tc,a,[4 4]); verifyTrue(tc,all(sum(a==2,2)==1));
verifyEqual(tc,size(unique(a,'rows'),1),4);
m.quantidade=[4;4];
verifyError(tc,@()braco.atribuicoes_motores(m,5),'braco:MuitasAtribuicoes');
m.quantidade=[1;1];
verifyError(tc,@()braco.atribuicoes_motores(m),'braco:EstoqueInsuficiente');
end

function tests=test_transporte
tests=functiontests(localfunctions);
end
function setupOnce(t)
addpath(fileparts(fileparts(mfilename('fullpath'))));
t.TestData.g=braco.modelo_geometrico_4r(.30,.45);
t.TestData.ht=hipoteses_transporte();
end
function testGravidadeIgualModeloComponentes(t)
g=t.TestData.g; mm=[1.2 1.5 1.7 1.1]; mr=[.5 1 1.5 .8];
for carga=[0 5]
    p=braco.modelo_dinamico_4r(g,mm,mr,carga);
    for q=[zeros(4,1) [-.7;.8;-.4;1.2] [1;-.3;.9;-.5]]
        r=braco.torques_estaticos_4r(g,q,mm,mr,carga);
        verifyEqual(t,braco.gravidade(q,p),r.torque_juntas_Nm,'AbsTol',1e-10);
        verifyEqual(t,sum(p.m),r.massa_movel_modelada_kg,'AbsTol',1e-12);
    end
end
end
function testDinamicaContraNewtonEuler(t)
p=braco.modelo_dinamico_4r(t.TestData.g,1.5*ones(4,1),ones(4,1),5);
robot=rigidBodyTree('DataFormat','column'); robot.Gravity=p.gravity.'; pai=robot.BaseName;
for j=1:4
    body=rigidBody(sprintf('elo%d',j)); joint=rigidBodyJoint(sprintf('j%d',j),'revolute');
    setFixedTransform(joint,[p.a(j) p.alpha(j) p.d(j) 0],'dh'); body.Joint=joint;
    body.Mass=p.m(j); c=p.pc(:,j); body.CenterOfMass=c.';
    I=p.Icm(:,:,j)+p.m(j)*((c.'*c)*eye(3)-c*c.');
    body.Inertia=[I(1,1) I(2,2) I(3,3) I(2,3) I(1,3) I(1,2)];
    addBody(robot,body,pai); pai=body.Name;
end
q=[-.8;.7;-.3;1.1]; dq=[.8;-.3;.6;-.4]; ddq=[1.3;-.8;.5;.2];
verifyEqual(t,braco.dinamica(q,dq,ddq,p),inverseDynamics(robot,q,dq,ddq),'AbsTol',2e-6);
verifyGreaterThan(t,min(eig(braco.massa(q,p))),0);
end
function testInerciaEsferaEComponenteFixo(t)
g=t.TestData.g; ht=t.TestData.ht; mm=1.5*ones(1,4); mr=ones(1,4);
p=braco.modelo_dinamico_4r(g,mm,mr,5,ht);
mm(1)=100; mr(1)=100;
p2=braco.modelo_dinamico_4r(g,mm,mr,5,ht);
verifyEqual(t,p2.m,p.m); verifyEqual(t,p2.Icm,p.Icm,'AbsTol',1e-12);
% Raio afeta inercia propria, mas nao COM quando distancia flange e fixa.
g.hipoteses.raio_esfera_m=.2;
p3=braco.modelo_dinamico_4r(g,mm,mr,5,ht);
verifyEqual(t,p3.pc,p.pc,'AbsTol',1e-12);
verifyEqual(t,p3.Icm(:,:,4)-p.Icm(:,:,4),.4*5*(.2^2-.1^2)*eye(3),'AbsTol',1e-12);
end
function testTrajetoriaCartesianaContinua(t)
g=t.TestData.g; ht=t.TestData.ht;
tr=braco.escolher_trajetoria_4r(g,ht,1.5*ones(1,4),ones(1,4),5,[95.25 95.25 76.2 76.2]);
verifyTrue(t,tr.valida);
for f=1:3
    seg=tr.fases{f}; verifyEqual(t,seg.dQ_du(:,[1 end]),zeros(4,2));
    verifyEqual(t,seg.ddQ_du2(:,[1 end]),zeros(4,2));
    for k=1:10:numel(seg.u)
        r=braco.cinematica_4r(seg.Q(:,k),g);
        verifyEqual(t,r.centro_esfera,seg.xyz_m(k,:).','AbsTol',1e-10);
        J=zeros(3,4);
        for j=1:4, J(:,j)=cross(r.eixos(:,j),r.centro_esfera-r.origens(:,j)); end
        u=seg.u(k); v=(30*u^2-60*u^3+30*u^4)*(tr.pontos_m(f+1,:)-tr.pontos_m(f,:)).';
        verifyEqual(t,J*seg.dQ_du(:,k),v,'AbsTol',2e-8);
    end
end
ht.coleta_m=[10 10 10];
bad=braco.trajetoria_transporte_4r(g,ht,[0 1 1]); verifyFalse(t,bad.valida);
end
function testRotorELimiteEstatico(t)
tau=ones(4,3)*12; zero=zeros(4,3); N=[50 80 100 60]; J=ones(4,1)*3e-5;
r=braco.requisitos_motor(tau,zero,zero,N,.75*ones(4,1),J);
verifyEqual(t,r.envelope_motor_Nm,tau./(.75*N(:)),'AbsTol',eps);
r=braco.requisitos_motor(zero,ones(4,3),ones(4,3),N,.75*ones(4,1),J);
verifyEqual(t,r.envelope_motor_Nm,repmat(J.*N(:),1,3),'AbsTol',eps);
verifyEqual(t,r.inercia_rotor_refletida_kgm2,J.*N(:).^2,'AbsTol',eps);
verifyEqual(t,r.rpm_motor,repmat(N(:)*60/(2*pi),1,3),'AbsTol',1e-12);
% Modulos se somam; nao cancela rotor contra torque gravitacional.
r=braco.requisitos_motor(-tau,zero,ones(4,3),N,.75*ones(4,1),J);
verifyEqual(t,r.envelope_motor_Nm,abs(tau./(.75*N(:)))+J.*N(:),'AbsTol',1e-12);
end
function testAceleracaoDaTrajetoria(t)
g=t.TestData.g; ht=t.TestData.ht;
tr=braco.escolher_trajetoria_4r(g,ht,1.5*ones(1,4),ones(1,4),5,[95.25 95.25 76.2 76.2]);
for f=1:3
    seg=tr.fases{f}; k=round(.3*(numel(seg.u)-1))+1;
    q=seg.Q(:,k); dq=seg.dQ_du(:,k); ddq=seg.ddQ_du2(:,k);
    r=braco.cinematica_4r(q,g); J=zeros(3,4);
    for j=1:4, J(:,j)=cross(r.eixos(:,j),r.centro_esfera-r.origens(:,j)); end
    delta=1e-4; plus=braco.cinematica_4r(q+delta*dq,g); minus=braco.cinematica_4r(q-delta*dq,g);
    acc=J*ddq+(plus.centro_esfera-2*r.centro_esfera+minus.centro_esfera)/delta^2;
    u=seg.u(k); expected=(60*u-180*u^2+120*u^3)*(tr.pontos_m(f+1,:)-tr.pontos_m(f,:)).';
    verifyEqual(t,acc,expected,'AbsTol',2e-6);
end
end
function testEscalaTempoRMSParadasERetorno(t)
g=t.TestData.g; ht=t.TestData.ht; ht.amostras_por_movimento=21;
tr=braco.escolher_trajetoria_4r(g,ht,1.5*ones(1,4),ones(1,4),5,[95.25 95.25 76.2 76.2]);
base=braco.base_dinamica_transporte(g,tr,1.5*ones(1,4),ones(1,4),5,ht);
N=[100 100 80 80]; eta=.75*ones(1,4); J=2.91e-5*ones(1,4); Tc=1.27*ones(1,4);
r=braco.avaliar_ciclo_transporte(tr,base,2,N,eta,J,Tc,ht);
r2=braco.avaliar_ciclo_transporte(tr,base,4,N,eta,J,Tc,ht);
verifyEqual(t,r.tempo_ciclo_s,5,'AbsTol',1e-12);
verifyEqual(t,r2.tempo_ciclo_s,9,'AbsTol',1e-12);
verifyEqual(t,r2.rpm_motor_pico,r.rpm_motor_pico/2,'AbsTol',1e-12);
verifyEqual(t,r2.fases{2}.ddq,r.fases{2}.ddq/4,'AbsTol',1e-12);
verifyEqual(t,r.fases{2}.Q,fliplr(r.fases{8}.Q));
verifyEqual(t,r.fases{8}.carga_kg,0); verifyEqual(t,r.fases{4}.carga_kg,5);
total=zeros(4,1);
for k=1:8
    f=r.fases{k}; total=total+trapz(f.t_s,f.motor.envelope_motor_Nm.^2,2);
    if k>1, verifyEqual(t,f.Q(:,1),r.fases{k-1}.Q(:,end),'AbsTol',1e-10); end
end
verifyEqual(t,r.torque_motor_envelope_rms_Nm,sqrt(total/r.tempo_ciclo_s),'AbsTol',1e-12);
verifyEqual(t,r.fases{1}.dq,zeros(4,2));
end

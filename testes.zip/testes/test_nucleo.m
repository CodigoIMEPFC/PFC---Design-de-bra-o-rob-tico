function tests=test_nucleo
tests=functiontests(localfunctions);
end

function setupOnce(testCase)
testCase.TestData.raiz=fileparts(fileparts(mfilename('fullpath')));
addpath(testCase.TestData.raiz);
testCase.TestData.p=braco.modelo_ur5_cb3();
end

function testCopiaOriginalIntacta(testCase)
pasta=fullfile(testCase.TestData.raiz,'referencia');
fid=fopen(fullfile(pasta,'Dimensionamento_Motores_4_Juntas_Livres_Claude.m'),'rb');
c=onCleanup(@()fclose(fid)); bytes=fread(fid,Inf,'*uint8');
% Digest verificado tambem contra o arquivo de origem ao importar.
md=System.Security.Cryptography.SHA256.Create();
digest=uint8(md.ComputeHash(bytes));
hex=lower(reshape(dec2hex(digest,2).',1,[]));
verifyEqual(testCase,hex,'43a18dedfdc1de47b515fa3343f273b83eac5474b16a27c015a01b2d5c3979a4');
end

function testPreservaFuncoesOriginais(testCase)
p=testCase.TestData.p; q=[0.2;-1.1;0.4;-0.7;0.3;0.1];
dq=[0.1;-0.2;0.15;0.03;-0.05;0]; ddq=[0.2;0.1;-0.1;0.4;0;0];
[M,h,G]=referencia_original('dinamica',q,dq,p);
[tau,r]=braco.dinamica(q,dq,ddq,p);
verifyEqual(testCase,r.M,M,'AbsTol',1e-11);
verifyEqual(testCase,r.G,G,'AbsTol',1e-11);
verifyEqual(testCase,r.h,h,'AbsTol',2e-8);
verifyEqual(testCase,tau,M*ddq+h+G,'AbsTol',2e-8);
[Mp,hp,Gp]=referencia_original('carga',q,dq,p,5);
tauCarga=braco.dinamica(q,dq,ddq,p,braco.carga_pontual(5));
verifyEqual(testCase,tauCarga-tau,Mp*ddq+hp+Gp,'AbsTol',2e-7);
end

function testQuinticaOriginalEExtremos(testCase)
t=linspace(0,2,31); qi=[0;0.5;-0.2;1]; qf=[1;-0.4;0.3;0];
[Q,dQ,ddQ]=braco.quintica(qi,qf,t,2);
[Q0,dQ0,ddQ0]=referencia_original('quintica',qi,qf,t,2);
verifyEqual(testCase,Q,Q0,'AbsTol',1e-13);
verifyEqual(testCase,dQ,dQ0,'AbsTol',1e-13);
verifyEqual(testCase,ddQ,ddQ0,'AbsTol',1e-13);
verifyEqual(testCase,Q(:,[1 end]),[qi qf],'AbsTol',1e-13);
verifyEqual(testCase,dQ(:,[1 end]),zeros(4,2),'AbsTol',1e-13);
verifyEqual(testCase,ddQ(:,[1 end]),zeros(4,2),'AbsTol',1e-13);
[Q2,dQ2,ddQ2]=braco.quintica(qi,qf,2*t,4);
verifyEqual(testCase,Q2,Q,'AbsTol',1e-13);
verifyEqual(testCase,dQ2,dQ/2,'AbsTol',1e-13);
verifyEqual(testCase,ddQ2,ddQ/4,'AbsTol',1e-13);
end

function testJacobianaNumeroVariavelJuntas(testCase)
modelos={modelo2R(),testCase.TestData.p};
for i=1:numel(modelos)
    p=modelos{i}; q=0.2*(1:p.n).';
    J=braco.jacobiana(q,p); Jnum=zeros(3,p.n);
    for j=1:p.n
        d=zeros(p.n,1); d(j)=1e-6;
        [~,Tp]=braco.cinematica(q+d,p); [~,Tm]=braco.cinematica(q-d,p);
        Jnum(:,j)=(Tp(1:3,4)-Tm(1:3,4))/2e-6;
    end
    verifyEqual(testCase,J,Jnum,'AbsTol',1e-8);
end
end

function testGravidadeCalculoManual(testCase)
p=modelo2R(); L1=p.a(1); L2=p.a(2); mp=5;
esperado=9.81*[p.m(1)*L1/2+p.m(2)*(L1+L2/2)+mp*(L1+L2); ...
    p.m(2)*L2/2+mp*L2];
G=braco.gravidade([0;0],p,braco.carga_pontual(mp));
verifyEqual(testCase,G,esperado,'AbsTol',1e-11);
% Girar a gravidade para fora do plano elimina torque gravitacional.
p.gravity=[0;0;-9.81];
verifyEqual(testCase,braco.gravidade([0;0],p),zeros(2,1),'AbsTol',1e-12);
end

function testMassaCalculoAnalitico(testCase)
p=modelo2R(); q=[0.3;-0.7]; L1=p.a(1); L2=p.a(2); c=cos(q(2));
m1=p.m(1); m2=p.m(2); r1=L1/2; r2=L2/2; mp=5;
I1=p.Icm(3,3,1); I2=p.Icm(3,3,2);
A=I1+I2+m1*r1^2+m2*(L1^2+r2^2+2*L1*r2*c)+mp*(L1^2+L2^2+2*L1*L2*c);
B=I2+m2*(r2^2+L1*r2*c)+mp*(L2^2+L1*L2*c);
D=I2+m2*r2^2+mp*L2^2;
verifyEqual(testCase,braco.massa(q,p,braco.carga_pontual(mp)),[A B;B D],'AbsTol',1e-11);
end

function testDinamicaIndependenteRoboticsToolbox(testCase)
% Newton-Euler do toolbox contra a implementacao por Jacobianas/Christoffel.
modelos={modelo2R(),testCase.TestData.p};
for i=1:numel(modelos)
    p=modelos{i}; q=linspace(-0.7,0.5,p.n).';
    dq=linspace(-0.2,0.3,p.n).'; ddq=linspace(0.1,-0.4,p.n).';
    robot=arvoreToolbox(p);
    esperado=inverseDynamics(robot,q,dq,ddq);
    verifyEqual(testCase,braco.dinamica(q,dq,ddq,p),esperado,'AbsTol',2e-6);
    carga=braco.carga_pontual(5,[0.03;0.02;-0.01]);
    corpo=rigidBody('carga'); corpo.Mass=carga.mass;
    corpo.CenterOfMass=carga.com.';
    corpo.Inertia=inerciaNoReferencialDoCorpo(zeros(3),carga.mass,carga.com);
    addBody(robot,corpo,robot.BodyNames{end});
    esperado=inverseDynamics(robot,q,dq,ddq);
    verifyEqual(testCase,braco.dinamica(q,dq,ddq,p,carga),esperado,'AbsTol',2e-6);
end
end

function testIKPreservaJuntasFixas(testCase)
p=testCase.TestData.p;
r=braco.resolver_posicao(p,[0.2;-0.1;0.3],p.q0,p.free_idx);
verifyTrue(testCase,r.atingido);
verifyEqual(testCase,r.q([1 6]),p.q0([1 6]));
verifyFalse(testCase,r.orientacao_verificada);
verifyFalse(testCase,r.limites_posicionais_verificados);
end

function testAlvoInalcancavelNaoGeraSimulacao(testCase)
p=modelo2R();
r=braco.resolver_posicao(p,[10;10;10],[0.1;0.1],[1 2]);
verifyFalse(testCase,r.atingido);
pasta=tempname;
verifyError(testCase,@()executar_referencia([10;10;10],pasta),'braco:AlvoInalcancavel');
verifyFalse(testCase,isfolder(pasta));
end

function testLimitesPosicionais(testCase)
p=modelo2R(); p.q_limits=[-0.1 0.1;-0.1 0.1];
r=braco.resolver_posicao(p,[0;0.8;0],[0;0],[1 2]);
verifyFalse(testCase,r.atingido);
verifyTrue(testCase,r.limites_posicionais_verificados);
verifyLessThanOrEqual(testCase,max(abs(r.q)),0.1+eps);
end

function testSustentacaoEntraNoRMS(testCase)
r=braco.metricas([0 1 2 6],zeros(1,4),5*ones(1,4));
verifyEqual(testCase,r.torque_rms_Nm,5,'AbsTol',eps);
verifyEqual(testCase,r.torque_pico_Nm,5);
verifyEqual(testCase,r.potencia_pico_W,0);
verifyEqual(testCase,r.energia_motora_J,0);
end

function testPotenciaRegenerativaSeparada(testCase)
r=braco.metricas([0 1 2],[2 0 -2],[3 3 3]);
verifyEqual(testCase,r.energia_motora_J,3);
verifyEqual(testCase,r.energia_regenerativa_mecanica_J,3);
end

function testEntradasInvalidasNaoPassam(testCase)
p=modelo2R(); p.m(1)=-1;
verifyError(testCase,@()braco.validar_modelo(p),'braco:MassaInvalida');
p=modelo2R(); p.Icm(:,:,1)=diag([1 1 5]);
verifyError(testCase,@()braco.validar_modelo(p),'braco:InerciaInvalida');
verifyError(testCase,@()braco.metricas([0 0],[0 0],[1 1]),'braco:TempoInvalido');
end

function p=modelo2R()
% Modelo sintetico ANALITICO de teste; nao representa produto comercial.
p.n=2; p.a=[0.5 0.35]; p.d=[0 0]; p.alpha=[0 0]; p.m=[2 1];
p.pc=[-0.25 -0.175;0 0;0 0];
p.Icm=cat(3,diag([0.001 0.045 0.045]),diag([0.001 0.011 0.011]));
p.gravity=[0;-9.81;0]; p.q_limits=[-pi pi;-pi pi];
end

function robot=arvoreToolbox(p)
robot=rigidBodyTree('DataFormat','column');
robot.Gravity=p.gravity.';
pai=robot.BaseName;
for i=1:p.n
    nome=sprintf('elo%d',i); body=rigidBody(nome);
    joint=rigidBodyJoint(sprintf('junta%d',i),'revolute');
    setFixedTransform(joint,[p.a(i) p.alpha(i) p.d(i) 0],'dh');
    body.Joint=joint; body.Mass=p.m(i); body.CenterOfMass=p.pc(:,i).';
    body.Inertia=inerciaNoReferencialDoCorpo(p.Icm(:,:,i),p.m(i),p.pc(:,i));
    addBody(robot,body,pai); pai=nome;
end
end

function vetor=inerciaNoReferencialDoCorpo(Icm,m,c)
% rigidBody.Inertia usa a origem do body frame; p.Icm usa o centro de massa.
% Transporte pelo teorema dos eixos paralelos, mantendo a orientacao dos eixos.
c=c(:); I=Icm+m*((c.'*c)*eye(3)-c*c.');
vetor=[I(1,1) I(2,2) I(3,3) I(2,3) I(1,3) I(1,2)];
end

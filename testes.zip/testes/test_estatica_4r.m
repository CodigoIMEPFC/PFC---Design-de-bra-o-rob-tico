function tests=test_estatica_4r
tests=functiontests(localfunctions);
end
function setupOnce(tc)
addpath(fileparts(fileparts(mfilename('fullpath'))));
end
function testBracoHorizontalContraCalculoManual(tc)
h=hipoteses_construcao(); L1=0.30; L2=0.40;
g=braco.modelo_geometrico_4r(L1,L2,h);
r=braco.torques_estaticos_4r(g,zeros(4,1),1.5*ones(4,1),ones(4,1),5);
linear=h.densidade_kgm3*(h.lado_externo_m^2-(h.lado_externo_m-2*h.espessura_m)^2);
m1=linear*L1; m2=linear*L2;
mDistal=linear*sum(h.afastamentos_punhos_m)+5+h.massa_garra_kg+2*(1.5+1+h.massa_suporte_por_junta_kg);
mCotovelo=1.5+1+h.massa_suporte_por_junta_kg;
esperado=-9.81*[m1*L1/2+m2*(L1+L2/2)+mDistal*(L1+L2)+mCotovelo*L1; ...
    m2*L2/2+mDistal*L2;0;0];
verifyEqual(tc,r.torque_juntas_Nm,esperado,'AbsTol',1e-10);
end
function testGradienteDaEnergiaPotencial(tc)
g=braco.modelo_geometrico_4r(0.25,0.45); q=[-0.8;0.3;-0.6;0.9];
m=[1;1.3;0.8;0.6]; red=[1.1;0.9;0.5;0.4]; grav=[0.2;-0.3;-9.81];
r=braco.torques_estaticos_4r(g,q,m,red,5,grav); grad=zeros(4,1); passo=1e-6;
for j=1:4
    delta=zeros(4,1); delta(j)=passo;
    a=braco.torques_estaticos_4r(g,q+delta,m,red,5,grav);
    b=braco.torques_estaticos_4r(g,q-delta,m,red,5,grav);
    grad(j)=(a.energia_potencial_J-b.energia_potencial_J)/(2*passo);
end
verifyEqual(tc,r.torque_juntas_Nm,grad,'AbsTol',1e-7);
end
function testMassaNaBaseNaoCarregaJuntas(tc)
g=braco.modelo_geometrico_4r(0.30,0.30);
a=braco.torques_estaticos_4r(g,g.q_inicial,ones(4,1),ones(4,1),5);
b=braco.torques_estaticos_4r(g,g.q_inicial,[101;1;1;1],ones(4,1),5);
verifyEqual(tc,a.torque_juntas_Nm,b.torque_juntas_Nm,'AbsTol',1e-12);
verifyEqual(tc,b.massa_modelada_total_kg-a.massa_modelada_total_kg,100,'AbsTol',1e-10);
verifyEqual(tc,b.massa_movel_modelada_kg,a.massa_movel_modelada_kg,'AbsTol',1e-10);
end
function testGravidadeNulaEInversao(tc)
g=braco.modelo_geometrico_4r(0.30,0.30);
a=braco.torques_estaticos_4r(g,g.q_inicial,ones(4,1),ones(4,1),5,[0;0;0]);
b=braco.torques_estaticos_4r(g,g.q_inicial,ones(4,1),ones(4,1),5,[0;0;-9.81]);
c=braco.torques_estaticos_4r(g,g.q_inicial,ones(4,1),ones(4,1),5,[0;0;9.81]);
verifyEqual(tc,a.torque_juntas_Nm,zeros(4,1),'AbsTol',1e-12);
verifyEqual(tc,b.torque_juntas_Nm,-c.torque_juntas_Nm,'AbsTol',1e-12);
end
function testReducaoMargemECenarios(tc)
cfg=configuracao_estudo(); g=braco.modelo_geometrico_4r(0.30,0.30,cfg.construcao);
m=catalogo(); r=braco.comparar_estatica_4r(g,zeros(4,1),m,ones(4,1),cfg);
verifyEqual(tc,height(r.resumo),9); verifyEqual(tc,height(r.detalhes),36);
linhas=r.detalhes.cenario_massa==2 & r.detalhes.junta==1;
d=r.detalhes(linhas,:);
verifyEqual(tc,d.capacidade_junta_Nm,1.27*0.75*[50;80;100],'AbsTol',1e-12);
verifyEqual(tc,d.torque_junta_com_margem_Nm,1.5*abs(d.torque_estatico_junta_Nm),'AbsTol',1e-12);
verifyGreaterThan(tc,abs(r.estatica{3}.torque_juntas_Nm(1)),abs(r.estatica{1}.torque_juntas_Nm(1)));
verifyEqual(tc,sum(r.estatica{2}.contribuicoes_Nm,2),r.estatica{2}.torque_juntas_Nm,'AbsTol',1e-12);
verifyEqual(tc,height(r.estatica{2}.componentes),19);
end
function testFronteiraDeAceitacao(tc)
cfg=configuracao_estudo(); h=cfg.construcao; h.massas_redutores_kg=ones(1,4);
g=braco.modelo_geometrico_4r(0.30,0.30,h); cfg.reducoes=50*ones(1,4);
e=braco.torques_estaticos_4r(g,g.q_inicial,1.5*ones(4,1),ones(4,1),5);
m=repmat(catalogo(),4,1); m.id=["A";"B";"C";"D"]; m.quantidade=ones(4,1);
m.torque_continuo_Nm=max(1e-6,1.5*abs(e.torque_juntas_Nm)/(0.75*50));
r=braco.comparar_estatica_4r(g,g.q_inicial,m,1:4,cfg);
verifyTrue(tc,r.resumo.atende_torque);
m.torque_continuo_Nm(1)=m.torque_continuo_Nm(1)*0.99;
s=braco.comparar_estatica_4r(g,g.q_inicial,m,1:4,cfg);
verifyFalse(tc,s.resumo.atende_torque);
end
function testEstoqueEExclusaoDeColisoes(tc)
cfg=configuracao_estudo(); g=braco.modelo_geometrico_4r(0.30,0.30,cfg.construcao);
m=catalogo(); m.quantidade=3;
verifyError(tc,@()braco.comparar_estatica_4r(g,g.q_inicial,m,ones(4,1),cfg),'braco:EstoqueInsuficiente');
m.quantidade=4; cfg.verificar_colisoes=true;
verifyError(tc,@()braco.comparar_estatica_4r(g,g.q_inicial,m,ones(4,1),cfg),'braco:ColisoesNaoImplementadas');
end
function m=catalogo()
m=table("EXEMPLO_TESTE",1.5,1.27,4, ...
    'VariableNames',{'id','massa_kg','torque_continuo_Nm','quantidade'});
end

﻿function varargout=referencia_original(operacao,varargin)
% Adaptador de testes. Funcoes abaixo extraidas literalmente do arquivo recebido.
% SHA256 da fonte: 43a18dedfdc1de47b515fa3343f273b83eac5474b16a27c015a01b2d5c3979a4
switch operacao
    case 'dinamica'
        q=varargin{1}; dq=varargin{2}; p=varargin{3};
        varargout={mass_matrix_numeric(q,p),coriolis_vector_numeric(q,dq,p), ...
            gravity_torque_required_numeric(q,p,9.81)};
    case 'carga'
        [varargout{1:nargout}]=payload_terms(varargin{1},varargin{2},varargin{3},varargin{4},9.81);
    case 'quintica'
        [varargout{1:nargout}]=traj_quintica(varargin{:});
    otherwise
        error('Operacao de referencia desconhecida.');
end
end
function [Mp, hp, Gp] = payload_terms(q, dq, params, m_pay, gval)
% Carga pontual m_pay no TCP decomposta em inercia (Mp),
% Coriolis/centrifuga (hp) e gravidade (Gp), evitando dupla
% contabilizacao (ver arquivo original):
%   tau_payload = Mp*ddq + hp + Gp = Jv'*m*(a_tcp - grav0)

    n = params.n;
    Mp = zeros(n,n);  hp = zeros(n,1);  Gp = zeros(n,1);
    if m_pay <= 0, return; end

    [T0, ~] = fkine_ur5e(q, params);
    Jv = jacobiana_posicao(T0);

    if norm(dq) > 0
        delta = 1e-6;
        [T0p, ~] = fkine_ur5e(q + delta*dq, params);
        [T0m, ~] = fkine_ur5e(q - delta*dq, params);
        Jdot = (jacobiana_posicao(T0p) - jacobiana_posicao(T0m))/(2*delta);
        Jdot_dq = Jdot*dq;
    else
        Jdot_dq = zeros(3,1);
    end

    Mp = m_pay*(Jv.'*Jv);
    hp = m_pay*(Jv.'*Jdot_dq);
    Gp = Jv.'*[0; 0; m_pay*gval];
end

function [q_goal, info] = ik_reduzida(q0, p_des, free_idx, params)
% Cinematica inversa por DLS nas 4 juntas livres, com resolucao de
% redundancia no espaco nulo puxando para q0 (identica ao original).

    maxIter = 1000;  tol_abs = 1e-5;  lambda = 1e-2;
    ganho = 0.8;  maxStep = 0.08;
    usar_espaco_nulo = true;  k_null = 0.05;

    fixed_idx = setdiff(1:params.n, free_idx);
    nJ = numel(free_idx);
    q = q0;

    for k = 1:maxIter
        q(fixed_idx) = q0(fixed_idx);
        [T0, T_ee] = fkine_ur5e(q, params);
        erro = p_des - T_ee(1:3,4);
        if norm(erro) < tol_abs, break; end

        Jv = jacobiana_posicao(T0);
        J_free = Jv(:,free_idx);
        A_dls = J_free.'*J_free + lambda^2*eye(nJ);
        dq_free = ganho*(A_dls \ (J_free.'*erro));

        if usar_espaco_nulo
            J_pinv_dls = A_dls \ J_free.';
            Nproj = eye(nJ) - J_pinv_dls*J_free;
            dq_free = dq_free + Nproj*(k_null*(q0(free_idx) - q(free_idx)));
        end
        if norm(dq_free) > maxStep
            dq_free = maxStep*dq_free/norm(dq_free);
        end
        q(free_idx) = q(free_idx) + dq_free;
        q = wrapToPi_local(q);
    end

    q_goal = q;  q_goal(fixed_idx) = q0(fixed_idx);
    [~, T_goal] = fkine_ur5e(q_goal, params);
    info.p_final  = T_goal(1:3,4);
    info.erro_abs = norm(p_des - info.p_final);
    info.iters    = k;
end

function [Q, Qdot, Qddot] = traj_quintica(qi, qf, t_local, Tf)
% Polinomio quintico com velocidade e aceleracao nulas nos extremos.
    tau = t_local/Tf;
    s   = 10*tau.^3 - 15*tau.^4 + 6*tau.^5;
    ds  = 30*tau.^2 - 60*tau.^3 + 30*tau.^4;
    dds = 60*tau - 180*tau.^2 + 120*tau.^3;

    n = length(qi);  N = length(t_local);
    Q = zeros(n,N);  Qdot = zeros(n,N);  Qddot = zeros(n,N);
    delta_q = qf - qi;
    for i = 1:N
        Q(:,i)     = qi + s(i)*delta_q;
        Qdot(:,i)  = (ds(i)/Tf)*delta_q;
        Qddot(:,i) = (dds(i)/Tf^2)*delta_q;
    end
end

function [T0, T_ee] = fkine_ur5e(q, params)
    n = params.n;
    T0 = cell(n+1,1);  T0{1} = eye(4);
    for i = 1:n
        T0{i+1} = T0{i} * dh_standard_num(params.a(i), params.alpha(i), ...
                                          params.d(i), q(i));
    end
    T_ee = T0{n+1};
end

function A = dh_standard_num(a, alpha, d, theta)
    A = [ cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta);
          sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta);
          0,           sin(alpha),             cos(alpha),            d;
          0,           0,                      0,                     1 ];
end

function Jv = jacobiana_posicao(T0)
    n = 6;
    p_ee = T0{n+1}(1:3,4);
    Jv = zeros(3,n);
    for j = 1:n
        z = T0{j}(1:3,3);  o = T0{j}(1:3,4);
        Jv(:,j) = cross(z, p_ee - o);
    end
end

function M = mass_matrix_numeric(q, params)
    n = params.n;
    [T0, ~] = fkine_ur5e(q, params);
    M = zeros(n,n);
    for i = 1:n
        Ti = T0{i+1};  Ri = Ti(1:3,1:3);
        pc_h = Ti*[params.pc(:,i); 1];  pc0 = pc_h(1:3);
        Jv = zeros(3,n);  Jw = zeros(3,n);
        for j = 1:i
            z = T0{j}(1:3,3);  o = T0{j}(1:3,4);
            Jv(:,j) = cross(z, pc0 - o);
            Jw(:,j) = z;
        end
        M = M + params.m(i)*(Jv.'*Jv) + Jw.'*Ri*params.Icm(:,:,i)*Ri.'*Jw;
    end
end

function G = gravity_torque_required_numeric(q, params, gval)
% Torque necessario para SUSTENTAR os elos (tau = M*ddq + h + G).
    n = params.n;
    [T0, ~] = fkine_ur5e(q, params);
    G = zeros(n,1);
    for i = 1:n
        Ti = T0{i+1};
        pc_h = Ti*[params.pc(:,i); 1];  pc0 = pc_h(1:3);
        Jv = zeros(3,n);
        for j = 1:i
            z = T0{j}(1:3,3);  o = T0{j}(1:3,4);
            Jv(:,j) = cross(z, pc0 - o);
        end
        G = G + Jv.'*[0; 0; params.m(i)*gval];
    end
end

function h = coriolis_vector_numeric(q, dq, params)
% Simbolos de Christoffel por diferencas centrais sobre M(q).
    n = params.n;  hstep = 1e-6;
    dM = zeros(n,n,n);
    for r = 1:n
        qp = q;  qm = q;
        qp(r) = qp(r) + hstep;  qm(r) = qm(r) - hstep;
        dM(:,:,r) = (mass_matrix_numeric(qp, params) - ...
                     mass_matrix_numeric(qm, params))/(2*hstep);
    end
    h = zeros(n,1);
    for k = 1:n
        soma = 0;
        for s = 1:n
            for r = 1:n
                gamma = 0.5*(dM(k,s,r) + dM(k,r,s) - dM(r,s,k));
                soma = soma + gamma*dq(s)*dq(r);
            end
        end
        h(k) = soma;
    end
end

function q = wrapToPi_local(q)
    q = mod(q + pi, 2*pi) - pi;
end



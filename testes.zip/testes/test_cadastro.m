function tests=test_cadastro
tests=functiontests(localfunctions);
end
function setupOnce(tc)
tc.TestData.raiz=fileparts(fileparts(mfilename('fullpath')));
addpath(tc.TestData.raiz);
tc.TestData.arquivo=fullfile(tc.TestData.raiz,'dados','cadastro_motores_simplificado.xlsx');
end
function testPlanilhaEntregue(tc)
m=braco.ler_motores(tc.TestData.arquivo);
verifyEqual(tc,height(m),1);
verifyEqual(tc,m.id,"OM_NXM640A");
verifyEqual(tc,[m.torque_continuo_Nm m.massa_kg m.inercia_rotor_kgm2 m.quantidade], ...
    [1.27 1.5 0.0000291 4],'AbsTol',1e-14);
end
function testDadosAusentesOuInvalidos(tc)
c=readcell(tc.TestData.arquivo,'Sheet','Motores','UseExcel',false);
c=c(1:6,1:8);
casos={3,[], 'braco:NumeroInvalido'; 3,0,'braco:ValorNaoPositivo'; ...
    4,-1,'braco:ValorNaoPositivo'; 5,'Inf','braco:NumeroInvalido'; ...
    5,'29 g cm2','braco:NumeroInvalido'; 6,1.5,'braco:QuantidadeInvalida'; ...
    6,[],'braco:NumeroInvalido'; 7,[],'braco:CampoAusente'};
for k=1:size(casos,1)
    d=c; d{6,casos{k,1}}=casos{k,2}; checarErro(tc,d,casos{k,3});
end
end
function testDuplicadoECabecalho(tc)
c=readcell(tc.TestData.arquivo,'Sheet','Motores','UseExcel',false);
c=c(1:6,1:8); c(7,:)=c(6,:); c{7,1}=' om_nxm640a ';
checarErro(tc,c,'braco:IdDuplicado');
c=c(1:6,:); c{5,5}='Inercia (g cm2)'; checarErro(tc,c,'braco:Cabecalho');
end
function testVirgulaDecimalELinhaVazia(tc)
c=readcell(tc.TestData.arquivo,'Sheet','Motores','UseExcel',false);
c=c(1:6,1:8); c(8,:)=c(6,:); c{8,1}='SEGUNDO_TESTE';
c{8,3}='1,27'; c{8,4}='1,5'; c{8,5}='2,91e-5'; c{8,6}=0;
[arq,limpar]=temporario(c); %#ok<ASGLU>
m=braco.ler_motores(arq);
verifyEqual(tc,height(m),2);
verifyEqual(tc,m.inercia_rotor_kgm2,[2.91e-5;2.91e-5],'AbsTol',1e-14);
verifyEqual(tc,m.quantidade,[4;0]);
end
function testCadastroVazio(tc)
c=readcell(tc.TestData.arquivo,'Sheet','Motores','UseExcel',false);
checarErro(tc,c(1:5,1:8),'braco:CadastroVazio');
end
function testIntegracaoEHipoteses(tc)
e=preparar_estudo(tc.TestData.arquivo);
verifyEqual(tc,e.config.reducoes,[50 50 50 50;80 80 60 60;100 100 80 80]);
verifyEqual(tc,e.config.rendimento,0.75*ones(1,4));
verifyEqual(tc,e.config.carga_util_kg,5);
verifyNotEmpty(tc,e.config.pendencias);
end
function checarErro(tc,c,id)
[arq,limpar]=temporario(c); %#ok<ASGLU>
verifyError(tc,@()braco.ler_motores(arq),id);
end
function [arq,limpar]=temporario(c)
arq=string(tempname)+".xlsx";
% readcell representa celulas vazias por missing; writecell exige vazio numerico.
for k=1:numel(c)
    if isa(c{k},'missing'), c{k}=[]; end
end
writecell(c,arq,'Sheet','Motores','UseExcel',false);
limpar=onCleanup(@()delete(arq));
end


function tests=test_controle
tests=functiontests(localfunctions);
end
function setupOnce(t)
addpath(fileparts(fileparts(mfilename('fullpath'))));
t.TestData.g=braco.modelo_geometrico_4r(.30,.45); t.TestData.h=hipoteses_controle();
t.TestData.p=braco.modelo_dinamico_4r(t.TestData.g,1.5*ones(4,1),ones(4,1),5);
t.TestData.N=[100;100;80;80]; t.TestData.eta=.75*ones(4,1); t.TestData.J=2.91e-5*ones(4,1);
end
function testInterpolacaoEDerivadasCoerentes(t)
ts=linspace(0,2,11); [Q,dq,ddq]=braco.quintica([0;1;2;3],[1;-1;.5;2],ts,2);
pp=braco.interpolante_controle(struct('t_s',ts,'Q',Q,'dq',dq,'ddq',ddq));
fine=linspace(0,2,47); [q,v,a]=braco.quintica([0;1;2;3],[1;-1;.5;2],fine,2);
verifyEqual(t,ppval(pp.q,fine),q,'AbsTol',1e-12);
verifyEqual(t,ppval(pp.dq,fine),v,'AbsTol',1e-11);
verifyEqual(t,ppval(pp.ddq,fine),a,'AbsTol',1e-9);
end
function testTorqueCalculadoRecuperaAceleracao(t)
d=t.TestData; q=[-.3;1.5;.5;-.8]; vel=[.1;-.2;.3;-.1]; acc=[1;-.5;.7;.2];
pp.q=mkpp([0 1],q,4); pp.dq=mkpp([0 1],vel,4); pp.ddq=mkpp([0 1],acc,4);
[dx,s]=braco.passo_controle(0,[q;vel],pp,d.p,[],d.N,d.eta,d.J,100*ones(4,1),d.h);
verifyEqual(t,dx(5:8),acc,'AbsTol',1e-12); verifyFalse(t,any(s.saturado));
verifyEqual(t,s.torque_pedido_Nm,s.torque_aplicado_Nm);
end
function testSaturacaoAfetaPlanta(t)
d=t.TestData; q=[0;.2;.3;.5]; z=zeros(4,1);
pp.q=mkpp([0 1],q,4); pp.dq=mkpp([0 1],z,4); pp.ddq=pp.dq;
[dx,s]=braco.passo_controle(0,[q;z],pp,d.p,[],d.N,d.eta,d.J,.01*ones(4,1),d.h);
verifyTrue(t,any(s.saturado)); verifyLessThanOrEqual(t,max(abs(s.torque_aplicado_Nm)),.01);
verifyGreaterThan(t,norm(dx(5:8)),1);
[A,b]=braco.termos_controle(q,z,d.p,d.N,d.eta,d.J);
verifyEqual(t,A*dx(5:8)+b,d.eta.*d.N.*s.torque_aplicado_Nm,'AbsTol',1e-10);
end
function testDinamicaDiretaIndependente(t)
d=t.TestData; q=[-.7;.9;.5;-.8]; v=[.4;-.3;.7;-.2];
[A,b]=braco.termos_controle(q,v,d.p,d.N,d.eta,d.J);
[Ar,br]=braco.termos_controle(q,v,braco.arvore_dinamica(d.p),d.N,d.eta,d.J);
verifyEqual(t,A,Ar,'AbsTol',1e-10); verifyEqual(t,b,br,'AbsTol',2e-7);
end
function testCorrecaoErroEContinuidadeDoEstado(t)
d=t.TestData; h=d.h; h.motor_dinamica="nucleo"; h.passo_integracao_s=.004;
q=[-.3;1.5;.5;-.8]; ciclo=struct('N',d.N,'eta',d.eta,'fases',{{}});
for f=1:8
    ciclo.fases{f}=struct('nome',"parado",'carga_kg',5,'t_s',[(f-1)*.04 f*.04], ...
        'Q',[q q],'dq',zeros(4,2),'ddq',zeros(4,2));
end
r=braco.integrar_controle(d.g,ciclo,1.5*ones(4,1),ones(4,1),d.J,100*ones(4,1),hipoteses_transporte(),h,1);
verifyTrue(t,r.completo); verifyEqual(t,r.fracao_tempo_saturado,0);
expected=deg2rad(h.erro_inicial_graus).*(1+h.frequencia_natural_rad_s*.32).*exp(-h.frequencia_natural_rad_s*.32);
verifyEqual(t,r.fases{8}.Q(:,end)-q,expected,'AbsTol',1e-8);
for f=2:8
    verifyEqual(t,r.fases{f}.Q(:,1),r.fases{f-1}.Q(:,end),'AbsTol',eps);
    verifyEqual(t,r.fases{f}.dq(:,1),r.fases{f-1}.dq(:,end),'AbsTol',eps);
end
end
